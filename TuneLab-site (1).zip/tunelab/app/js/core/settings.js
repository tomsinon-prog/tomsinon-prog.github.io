// Settings live in the kv table as "set.<name>" = JSON value, so Java (PlaybackService, WorkService) can read them too.
import { kvGet, kvSet } from './db.js';
import { call } from './bridge.js';

export const DEFAULTS = {
  theme: 'dark', // dark | light | system
  accent: 'mint', // see ACCENTS in ui/main.js
  qualityWifi: 'high', // high | normal | low
  qualityMobile: 'normal',
  downloadQuality: 'high',
  cacheSizeMb: 2048,
  prefetchWifi: 2,
  prefetchMobile: 1,
  crossfadeSec: 0,
  autoRadio: true,
  normalize: true,
  eqEnabled: false,
  eqBands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  eqPreamp: 0,
  eqPreset: 'Flat',
  bassBoost: 0,
  downloadWifiOnly: true,
  offlineMode: false,
  matchDelayMs: 1500,
  autoMatch: true,
  spotifyClientId: '',
  ytClients: 'VISIONOS,ANDROID_VR,TV,WEB_EMBEDDED,MWEB,WEB,IOS,ANDROID', // == DEFAULT_CLIENTS in yt/resolver.js
  poToken: 'auto', // auto | off
  radioFilterLibrary: true,
  radioLastfm: false,
  smartShuffleEvery: 4,
  lastfmEnabled: false,
  lastfmApiKey: '',
  lastfmSecret: '',
  backupTreeUri: '',
  backupTreeName: '',
  backupSchedule: 'off', // off | daily | weekly
  localTrees: [],
  localMediaStore: true,
  githubToken: '',
  githubRepo: 'tomsinon-prog/TuneLab',
  lyrics: true,
  likesOffline: false, // keep all liked songs downloaded
  mixEnabled: true, // Weekly Discovery
  mixOffline: false, // download Weekly Discovery itself (off: only songs you like get downloaded)
  releasesEnabled: true,
  genresEnabled: true, // genre filters (artist genres from MusicBrainz)
  carDevices: [], // [{address, name}] Bluetooth devices that start playback when they connect (CarConnect.java)
  carStart: 'resume', // resume | liked
  carLikeGesture: true, // play/pause pressed twice quickly (steering wheel, headphones) = like the song
  carHeart: true, // "♥ " before the title of liked songs on the car's screen (Bluetooth only)
  webShowVideo: false, // browser version: show YouTube's player box (off: it plays out of sight, sound only)
};

const cache = new Map();

export function get(name) {
  if (cache.has(name)) return cache.get(name);
  let v = DEFAULTS[name];
  try {
    const raw = kvGet('set.' + name);
    if (raw != null) v = JSON.parse(raw);
  } catch { /* keep default */ }
  cache.set(name, v);
  return v;
}

export function set(name, value) {
  cache.set(name, value);
  kvSet('set.' + name, JSON.stringify(value));
  try { call('settings.changed', { name }); } catch { /* tests */ }
}

export function invalidate() { cache.clear(); }
