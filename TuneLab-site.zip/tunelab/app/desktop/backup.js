// Same backup format as the phone (android/.../Backup.java), so libraries move both ways:
// phone -> laptop with "Move library" (code) or a backup file, laptop -> phone with "Back up now" + Restore there.

export const TABLES = ['track', 'track_source', 'likes', 'playlist', 'playlist_entry', 'user_album', 'user_album_entry', 'play_event', 'recording', 'smart_playlist', 'artist_follow', 'kv'];
const SECRET_KEYS = ['set.githubToken', 'set.lastfmSecret'];
const DEVICE_KEYS = ['set.backupTreeUri', 'set.backupTreeName', 'set.localTrees', 'set.carDevices', 'set.carAutoplay'];

/** The library as a backup object (the phone's "tunelab-backup" format, version 1). */
export function exportBackup(db, { app = 'desktop', reason = 'manual' } = {}) {
  const tables = {};
  const counts = {};
  for (const t of TABLES) {
    let sql = 'SELECT * FROM ' + t;
    if (t === 'track_source') sql += " WHERE kind!='DOWNLOADED'";
    if (t === 'kv') sql += " WHERE key LIKE 'set.%' OR key LIKE 'ui.%'";
    let rows = db.rows(sql);
    if (t === 'kv') rows = rows.filter((r) => !SECRET_KEYS.includes(r.key) && !DEVICE_KEYS.includes(r.key));
    tables[t] = rows;
    counts[t] = rows.length;
  }
  return { backup: { format: 'tunelab-backup', formatVersion: 1, schemaVersion: db.version(), app, exportedAt: Date.now(), reason, tables }, counts };
}

/**
 * Replaces the library with a backup (all-or-nothing). Columns are matched by name, so backups from older or newer
 * app versions work. This computer's own settings (DEVICE_KEYS) stay. The caller saves the current state first
 * ("pre-restore").
 */
export function restoreBackup(db, backup) {
  if (!backup || backup.format !== 'tunelab-backup' || !backup.tables) throw new Error('not a TuneLab backup');
  const counts = {};
  const ops = [];
  for (const table of TABLES) {
    const rows = backup.tables[table];
    if (!Array.isArray(rows)) continue;
    const cols = new Set(db.rows(`PRAGMA table_info(${table})`).map((c) => c.name));
    if (table === 'kv') {
      const keep = DEVICE_KEYS.map((k) => `'${k}'`).join(',');
      ops.push({ sql: `DELETE FROM kv WHERE (key LIKE 'set.%' OR key LIKE 'ui.%') AND key NOT IN (${keep})` });
    } else if (table === 'track_source') ops.push({ sql: "DELETE FROM track_source WHERE kind!='DOWNLOADED'" });
    else ops.push({ sql: 'DELETE FROM ' + table });
    let n = 0;
    for (const row of rows) {
      if (table === 'kv' && (SECRET_KEYS.includes(row.key) || DEVICE_KEYS.includes(row.key))) continue;
      if (table === 'track_source' && row.kind === 'DOWNLOADED') continue;
      const keys = Object.keys(row).filter((k) => cols.has(k));
      if (!keys.length) continue;
      ops.push({ sql: `INSERT OR REPLACE INTO ${table}(${keys.join(',')}) VALUES(${keys.map(() => '?').join(',')})`, args: keys.map((k) => (typeof row[k] === 'boolean' ? (row[k] ? 1 : 0) : row[k])) });
      n++;
    }
    counts[table] = n;
  }
  // Caches keyed by track id would point at the wrong songs now (they fill again by themselves); the saved queue too.
  ops.push({ sql: 'DELETE FROM match_candidate' }, { sql: 'DELETE FROM lyrics' }, { sql: 'DELETE FROM resolved_url' });
  ops.push({ sql: "DELETE FROM kv WHERE key='player.queue'" });
  db.batch(ops);
  return { counts };
}
