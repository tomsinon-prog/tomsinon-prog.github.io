// window.TLNative for Windows (and, with options, the browser version in webapp/): what Bridge.java + the Android
// services do on the phone, done in the page and the local server (desktop/*.go). The UI and the engine (hidden
// iframe, web/engine.html) are the phone's unchanged code. The browser version has no server and no engine.
import { openDatabase } from './sqlite.js';
import { createPlayer } from './player.js';
import { exportBackup, restoreBackup } from './backup.js';

const VERSION = document.querySelector('meta[name="tunelab-version"]')?.content || 'dev';
const logLines = [];
let logQueue = [];

function log(level, tag, msg) {
  const d = new Date();
  const p = (n, w = 2) => String(n).padStart(w, '0');
  const line = `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)} ${String(level || 'I')[0]}/${tag}: ${msg}`;
  logLines.push(line);
  if (logLines.length > 3000) logLines.splice(0, 1000);
  if (logQueue) logQueue.push(line);
}
/**
 * options (browser version): platform 'web', store (IndexedDB), engine false, server false, media/resolve/srcFor for
 * the YouTube embedded player, fetchImpl for plain browser fetch.
 */
export async function boot({ platform = 'desktop', store, engine: withEngine = true, server = true, media = null, resolve = null, srcFor = null, fetchImpl = null } = {}) {
  if (server) {
    setInterval(() => {
      if (!logQueue.length) return;
      const body = logQueue.join('\n');
      logQueue = [];
      fetch('api/log', { method: 'POST', body }).catch(() => {});
    }, 3000);
  } else logQueue = null;
  const db = await openDatabase({ log, ...(store ? { store } : {}) });
  const results = new Map();
  const jobs = {};
  let engineWin = null, engineReady = null, engineSeq = 0;
  const enginePending = new Map();
  const picked = new Map(); // pick.file → File
  const ok = (v) => JSON.stringify({ ok: true, v: v === undefined ? null : v });
  const err = (e) => JSON.stringify({ ok: false, error: String((e && e.message) || e) });
  const uiEvent = (name, data) => setTimeout(() => globalThis.__tlEvent && globalThis.__tlEvent(name, data), 0);
  const setting = (name) => {
    const r = db.rows('SELECT value FROM kv WHERE key=?', ['set.' + name])[0];
    if (!r || r.value == null) return undefined;
    try { return JSON.parse(r.value); } catch { return undefined; }
  };

  // ---------------------------------------------------------------- engine (hidden iframe)
  const frame = document.createElement('iframe');
  frame.style.display = 'none';
  frame.src = 'engine.html';
  let readyResolve;
  engineReady = new Promise((r) => { readyResolve = r; });
  function engine(method, args = {}, timeoutMs = 45000) {
    if (!withEngine) return Promise.reject(new Error('Needs the app or TuneLab for Windows'));
    return engineReady.then(() => new Promise((resolve, reject) => {
      const id = 'e' + (++engineSeq);
      const timer = setTimeout(() => { enginePending.delete(id); reject(new Error(`${method} timed out`)); }, timeoutMs);
      enginePending.set(id, { resolve, reject, timer });
      engineWin.__tlEngine.handle(id, method, args);
    }));
  }

  const player = createPlayer({ db, engine, emit: uiEvent, log, setting, media, resolve, srcFor, hasEngine: withEngine });

  // ---------------------------------------------------------------- jobs (WorkService)
  function jobStatus(job, state, done = -1, total = -1, message = '') {
    jobs[job] = { state, done, total, message, at: Date.now() };
    uiEvent('job', { job, state, done, total, message });
  }
  const ENGINE_JOBS = { weeklyMix: 10 * 60e3, newReleases: 15 * 60e3, genres: 30 * 60e3, spotifySync: 3 * 3600e3 };
  async function startJob(job, args = {}) {
    if (!withEngine) return; // browser version: no YouTube jobs
    if (jobs[job]?.state === 'running') return;
    jobStatus(job, 'running', -1, -1, 'Starting…');
    try {
      if (ENGINE_JOBS[job]) {
        const r = await engine(job, args, ENGINE_JOBS[job]);
        jobStatus(job, 'done', r?.done ?? -1, r?.total ?? -1, r?.message || 'Done');
        uiEvent('library', { what: job });
      } else if (job === 'match') {
        await runMatch();
      } else {
        jobStatus(job, 'done', -1, -1, 'Not available on Windows');
      }
    } catch (e) {
      log('W', 'Work', `${job} failed: ${e.message}`);
      jobStatus(job, 'failed', -1, -1, String(e.message));
    }
  }
  async function runMatch() {
    const pending = "FROM track t WHERE t.match_state='NONE' AND NOT EXISTS (SELECT 1 FROM track_source s WHERE s.track_id=t.id)";
    const total = db.rows('SELECT COUNT(*) n ' + pending)[0].n;
    let done = 0, matched = 0, review = 0, failed = 0;
    while (jobs.match?.state === 'running') {
      const next = db.rows('SELECT t.id ' + pending + ' ORDER BY t.id LIMIT 1')[0];
      if (!next) break;
      try {
        const r = await engine('matchOne', { trackId: next.id }, 45000);
        if (r?.state === 'MATCHED') matched++; else if (r?.state === 'REVIEW') review++; else failed++;
      } catch (e) {
        failed++;
        db.run("UPDATE track SET match_state='FAILED', match_tried_at=? WHERE id=?", [Date.now(), next.id]);
      }
      done++;
      jobStatus('match', 'running', done, Math.max(total, done), `${matched} matched · ${review} to review · ${failed} not found`);
      await new Promise((r) => setTimeout(r, 1500 + Math.random() * 500));
    }
    jobStatus('match', 'done', done, Math.max(total, done), `${matched} matched · ${review} to review · ${failed} not found`);
    uiEvent('library', { what: 'match' });
  }

  // ---------------------------------------------------------------- files (backup import, CSV)
  function pickFile(accept) {
    return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file';
      if (accept) inp.accept = accept;
      inp.onchange = () => {
        const f = inp.files[0];
        if (!f) return resolve(null);
        const uri = 'file:' + Math.random().toString(36).slice(2);
        picked.set(uri, f);
        resolve({ uri, name: f.name, size: f.size });
      };
      inp.addEventListener('cancel', () => resolve(null));
      inp.click();
    });
  }
  function download(name, text, type = 'application/json') {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name;
    document.body.append(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  }
  async function restoreFrom(backup) {
    await db.save('pre-restore');
    player.command({ cmd: 'resetQueue' });
    const r = restoreBackup(db, backup);
    await db.save();
    log('I', 'Backup', 'restored ' + JSON.stringify(r.counts));
    return { counts: r.counts, safetyBackup: 'TuneLab-data/backups' };
  }

  // ---------------------------------------------------------------- sync methods
  function callSync(m, a, role) {
    switch (m) {
      case 'db.query': return db.rows(a.sql, a.args);
      case 'db.exec': return db.run(a.sql, a.args);
      case 'db.batch': return db.batch(a.ops);
      case 'kv.get': return db.rows('SELECT value FROM kv WHERE key=?', [a.key])[0]?.value ?? null;
      case 'kv.set': db.run('INSERT OR REPLACE INTO kv(key,value) VALUES(?,?)', [a.key, a.value == null ? null : String(a.value)]); return null;
      case 'log': log(a.level, a.tag, a.msg); return null;
      case 'log.dump': return logLines.slice(-(a.lines || 1500)).join('\n');
      case 'log.clear': logLines.length = 0; return null;
      case 'app.info': return { appName: 'TuneLab', version: VERSION, platform, sdk: 0, release: platform === 'web' ? 'Browser' : 'Windows', device: navigator.userAgentData?.platform || 'Windows', role, dbVersion: db.version() };
      case 'net.state': return { online: navigator.onLine, metered: false, wifi: true };
      case 'clipboard': navigator.clipboard?.writeText(a.text || '').catch(() => {}); return null;
      case 'share': navigator.clipboard?.writeText([a.text, a.url].filter(Boolean).join('\n')).catch(() => {}); return { copied: true };
      case 'openUrl': window.open(a.url, '_blank', 'noopener'); return null;
      case 'player': return player.command(a);
      case 'player.state': return player.state();
      case 'engine.status': return { ready: !!engineWin, platform };
      case 'engine.ready': readyResolve(); return null;
      case 'engine.reply': {
        const p = enginePending.get(a.id);
        if (p) { enginePending.delete(a.id); clearTimeout(p.timer); a.ok ? p.resolve(a.v) : p.reject(new Error(a.error)); }
        return null;
      }
      case 'engine.emit': uiEvent(a.name, a.data); return null;
      case 'ui.ready': case 'back.state': case 'theme': case 'settings.changed': case 'backup.schedule': return null;
      case 'cache.stats': return { cacheBytes: 0, cacheFiles: 0, limitBytes: 0, downloadsBytes: 0, downloadsCount: 0, freeBytes: 0 };
      case 'cache.clear': return callSync('cache.stats', {}, role);
      case 'jobs.start': startJob(a.job, a.args || {}); return null;
      case 'jobs.cancel': if (jobs[a.job]) jobs[a.job].state = 'cancelled'; return null;
      case 'jobs.status': return jobs;
      case 'downloads.enqueue': return { queued: 0 };
      case 'downloads.delete': return { deleted: 0 };
      case 'downloads.retry': return { ok: true };
      case 'permission.has': return false;
      case 'scrobble.status': return { enabled: false, user: null, queued: 0 };
      case 'time': return Date.now();
      case 'transfer.stop': return null;
      case 'transfer.status': return { state: 'idle' };
      case 'player.likeCurrent': player.toggleLikeCurrent(); return null;
      default: throw new Error('Not available on Windows');
    }
  }

  // ---------------------------------------------------------------- async methods
  async function callAsync(m, a) {
    switch (m) {
      case 'fetch': {
        if (fetchImpl) return fetchImpl(a);
        const res = await fetch('api/fetch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(a) });
        const j = await res.json();
        if (!res.ok) throw new Error(j.error || 'HTTP ' + res.status);
        return j;
      }
      case 'engine.call': return engine(a.method, a.args ?? {}, a.timeoutMs || 45000);
      case 'permission.request': return false;
      case 'pick.file': {
        const types = (a.mimes || (a.mime ? [a.mime] : [])).filter((m) => m && m !== '*/*');
        return pickFile(types.includes('application/json') ? '.json,application/json' : types.includes('text/csv') ? '.csv,text/csv,text/plain' : types.includes('application/zip') ? '.zip' : '');
      }
      case 'file.readText': {
        const f = picked.get(a.uri);
        if (!f) throw new Error('file is gone, pick it again');
        return f.text();
      }
      case 'backup.run': {
        const { backup, counts } = exportBackup(db, { app: VERSION });
        const stamp = new Date().toISOString().slice(0, 16).replace('T', '_').replace(':', '');
        const name = `TuneLab-backup-${stamp}.json`;
        download(name, JSON.stringify(backup));
        const res = { file: 'Downloads/' + name, counts, playlists: 0, at: Date.now(), reason: 'manual' };
        db.run("INSERT OR REPLACE INTO kv(key,value) VALUES('backup.last',?)", [JSON.stringify(res)]);
        return res;
      }
      case 'backup.restore': {
        const f = picked.get(a.uri);
        if (!f) throw new Error('file is gone, pick it again');
        return restoreFrom(JSON.parse(await f.text()));
      }
      case 'transfer.receive': {
        if (!server) throw new Error('Not available in the browser');
        uiEvent('transfer', { state: 'receiving', side: 'receive' });
        const res = await fetch('api/transfer', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ address: a.address || '', code: a.code || '' }) });
        if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Something went wrong');
        const backup = await res.json();
        uiEvent('transfer', { state: 'restoring', side: 'receive' });
        return restoreFrom(backup);
      }
      case 'diag.stream': {
        const t0 = performance.now();
        const res = await fetch('api/fetch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: a.url, headers: { ...(a.headers || {}), Range: 'bytes=0-524287' }, timeoutMs: 20000 }) });
        const j = await res.json();
        const ms = Math.round(performance.now() - t0);
        const bytes = j.bodyB64 ? Math.floor(j.bodyB64.length * 3 / 4) : 0;
        return { ok: j.status === 206 || j.status === 200, status: j.status, ttfbMs: ms, ms, bytes, kbps: Math.round(bytes * 8 / Math.max(1, ms)) };
      }
      default: return callSync(m, a, 'ui');
    }
  }

  function makeNative(role) {
    return {
      call(method, argsJson) {
        try { return ok(callSync(method, argsJson ? JSON.parse(argsJson) : {}, role)); } catch (e) { return err(e); }
      },
      callAsync(method, argsJson, cbId) {
        const win = role === 'engine' ? engineWin : window;
        Promise.resolve().then(() => callAsync(method, argsJson ? JSON.parse(argsJson) : {}))
          .then((v) => results.set(cbId, ok(v)), (e) => results.set(cbId, err(e)))
          .finally(() => { try { win.__tlDone(cbId); } catch { /* engine reloading */ } });
      },
      take(cbId) { const r = results.get(cbId); results.delete(cbId); return r; },
    };
  }

  // The engine page asks for its bridge before its modules load (see engine.html).
  globalThis.__tlDesktopNative = (role) => {
    engineWin = frame.contentWindow;
    return makeNative(role);
  };
  window.TLNative = makeNative('ui');
  if (withEngine) document.body.append(frame);

  // Heartbeat: the local server quits when the window is gone.
  const ping = () => (server ? fetch('api/ping', { cache: 'no-store' }).catch(() => {}) : null);
  ping();
  setInterval(ping, 5000);
  window.addEventListener('pagehide', () => { player.flush(); db.save(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') { player.flush(); db.save(); } });
  log('I', 'App', `start ${VERSION} (${platform === 'web' ? 'browser' : 'Windows'}) · ${navigator.userAgent}`);
  return { db, player, engine };
}
