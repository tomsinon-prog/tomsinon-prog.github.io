// The library on Windows and in the browser version: SQLite (sql.js) in memory, the same migrations as the phone.
// Saved through a store: Windows = TuneLab-data/library.sqlite via the local server (atomic, daily copies);
// browser = IndexedDB (webapp/web/app/native.js).
/* global initSqlJs */

const SAVE_DELAY_MS = 1500;

/** The Windows store: the local Go server. */
export const serverStore = {
  async load() {
    const res = await fetch('api/db', { cache: 'no-store' });
    return res.status === 200 ? new Uint8Array(await res.arrayBuffer()) : null;
  },
  async save(bytes, reason) {
    const r = await fetch('api/db' + (reason ? '?reason=' + encodeURIComponent(reason) : ''), { method: 'PUT', body: bytes });
    if (!r.ok) throw new Error('HTTP ' + r.status);
  },
};

export async function openDatabase({ log, store = serverStore }) {
  const SQL = await initSqlJs({ locateFile: (f) => 'sqljs/' + f });
  const saved = await store.load();
  const db = saved ? new SQL.Database(saved) : new SQL.Database();
  const files = await (await fetch('db/index.json', { cache: 'no-store' })).json();
  const have = Number(db.exec('PRAGMA user_version')[0]?.values[0][0] || 0);
  for (let i = have; i < files.length; i++) {
    const sql = await (await fetch('db/' + files[i], { cache: 'no-store' })).text();
    db.exec('BEGIN');
    try {
      for (const st of splitStatements(sql)) db.exec(st);
      db.exec(`PRAGMA user_version=${i + 1}`);
      db.exec('COMMIT');
    } catch (e) {
      db.exec('ROLLBACK');
      throw new Error(`migration ${files[i]} failed: ${e.message}`);
    }
    log('I', 'Db', `migrated to ${i + 1} (${files[i]})`);
  }

  let dirty = false, timer = null, saving = null;
  const bind = (args) => (args || []).map((v) => (typeof v === 'boolean' ? (v ? 1 : 0) : v === undefined ? null : v));
  const rows = (sql, args) => {
    const st = db.prepare(sql);
    try {
      st.bind(bind(args));
      const out = [];
      while (st.step()) out.push(st.getAsObject());
      return out;
    } finally { st.free(); }
  };
  let stmtCache = null; // during a batch: one prepared statement per SQL text (restores insert 100k rows)
  const run = (sql, args) => {
    if (stmtCache) {
      let st = stmtCache.get(sql);
      if (!st) { st = db.prepare(sql); stmtCache.set(sql, st); }
      st.run(bind(args));
    } else {
      const st = db.prepare(sql);
      try { st.run(bind(args)); } finally { st.free(); }
    }
    const head = sql.trim().slice(0, 7).toUpperCase();
    const changes = db.getRowsModified();
    markDirty();
    if (head.startsWith('INSERT') || head.startsWith('REPLACE')) {
      if (stmtCache) return { changes };
      return { lastId: Number(db.exec('SELECT last_insert_rowid()')[0].values[0][0]), changes };
    }
    return { changes };
  };
  const batch = (ops) => {
    db.exec('BEGIN');
    stmtCache = new Map();
    try {
      const out = ops.map((o) => (o.q ? rows(o.sql, o.args) : run(o.sql, o.args)));
      db.exec('COMMIT');
      return out;
    } catch (e) {
      db.exec('ROLLBACK');
      throw e;
    } finally {
      for (const st of stmtCache.values()) st.free();
      stmtCache = null;
    }
  };
  function markDirty() {
    dirty = true;
    if (!timer) timer = setTimeout(() => { timer = null; save(); }, SAVE_DELAY_MS);
  }
  async function save(reason = '') {
    if (saving) await saving;
    if (!dirty && !reason) return;
    dirty = false;
    const bytes = db.export();
    saving = Promise.resolve().then(() => store.save(bytes, reason))
      .catch((e) => { dirty = true; log('E', 'Db', 'save failed: ' + e.message); setTimeout(markDirty, 3000); })
      .finally(() => { saving = null; });
    return saving;
  }
  return { rows, run, batch, save, version: () => files.length, raw: db };
}

export function splitStatements(sql) {
  const out = [];
  let cur = '';
  for (const line of sql.split('\n')) {
    const t = line.trim();
    if (!t || t.startsWith('--')) continue;
    cur += line + '\n';
    if (t.endsWith(';')) { out.push(cur.trim()); cur = ''; }
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}
