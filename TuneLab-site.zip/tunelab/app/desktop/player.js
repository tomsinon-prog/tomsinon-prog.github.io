// The player on Windows: the queue logic of PlaybackService.java (the parts the UI uses) on an <audio> element.
// Same commands ("playTracks", "next", …) and the same state JSON, so the phone UI works unchanged.
// YouTube audio comes through the local server (/api/stream) with the InnerTube client's headers.

const REPEAT_OFF = 0, REPEAT_ALL = 1, REPEAT_ONE = 2;

/**
 * media: an <audio>-like element (the browser version passes a YouTube embedded player with the same interface);
 * resolve/srcFor: how a queue item becomes something `media` can play (default: engine resolve + /api/stream).
 */
export function createPlayer({ db, engine, emit, log, setting, media = null, resolve = null, srcFor = null, hasEngine = true }) {
  const audio = media || new Audio();
  audio.preload = 'auto';
  let queue = [], index = -1, unshuffled = null;
  let status = 'idle', playWhenReady = false, buffering = false;
  let repeat = REPEAT_OFF, shuffle = false, smart = false;
  let radio = null, contextInfo = null, undoQueue = null, radioLoading = false;
  let queueVersion = 0, errorMsg = null, notice = null, curSource = null;
  let sleepAt = 0, sleepEndOfTrack = false;
  let loadSeq = 0, retried = false, consecutiveErrors = 0, autoSkipTimer = null;
  let ev = null; // current play event {trackId, start, played, since}

  const L = (lvl, msg) => log(lvl, 'Playback', msg);

  // ---------------------------------------------------------------- items + state

  function loadItems(ids, recs) {
    if (!ids || !ids.length) return [];
    const rows = db.rows(`SELECT id,title,artists,album,artwork_url,duration_ms FROM track WHERE id IN (${ids.map(() => '?').join(',')})`, ids);
    const byId = new Map(rows.map((r) => [r.id, r]));
    const recSet = new Set(recs || []);
    const out = [];
    ids.forEach((id, i) => {
      const r = byId.get(Number(id));
      if (r) out.push({ trackId: r.id, title: r.title, artists: r.artists || '', album: r.album || '', artwork: r.artwork_url || null, durationMs: r.duration_ms || 0, rec: recSet.has(i) });
    });
    return out;
  }
  const current = () => (index >= 0 && index < queue.length ? queue[index] : null);
  const isLiked = (id) => db.rows('SELECT 1 x FROM likes WHERE track_id=?', [id]).length > 0;

  function state(withQueue) {
    const it = current();
    const o = {
      status, playWhenReady, buffering, index, posMs: Math.round((audio.currentTime || 0) * 1000), durMs: Math.round((audio.duration && isFinite(audio.duration) ? audio.duration : 0) * 1000) || (it ? it.durationMs : 0),
      at: Date.now(), repeat, shuffle, smart, canUndo: !!undoQueue, notice, radio: !!radio, context: contextInfo, queueVersion,
      sleepInMs: sleepAt ? sleepAt - Date.now() : 0, sleepEndOfTrack, error: errorMsg, source: curSource ? sourceJson(curSource) : null,
      current: it ? { ...it, liked: isLiked(it.trackId) } : null,
    };
    if (withQueue) o.queue = queue;
    return o;
  }
  const sourceJson = (s) => ({ kind: s.kind, cached: false, videoId: s.videoId, client: s.client, itag: s.itag, bitrate: s.bitrate, mime: s.mime });
  let emittedQv = -1;
  function emitState(force = false) {
    const withQueue = force || emittedQv !== queueVersion;
    emittedQv = queueVersion;
    emit('player', state(withQueue));
    updateMediaSession();
  }
  function queueChanged() { queueVersion++; saveState(); emitState(true); }
  function setStatus(s) { status = s; emitState(); }
  function postNotice(text) { notice = { id: (notice ? notice.id : 0) + 1, text }; emitState(); }

  function saveState() {
    try {
      db.run("INSERT OR REPLACE INTO kv(key,value) VALUES('player.queue',?)", [JSON.stringify({
        ids: queue.map((q) => q.trackId), recs: queue.map((q, i) => (q.rec ? i : -1)).filter((i) => i >= 0), index,
        pos: Math.round((audio.currentTime || 0) * 1000), repeat, shuffle, smart, radio, context: contextInfo,
      })]);
    } catch (e) { L('E', 'saveState ' + e.message); }
  }
  function restoreState() {
    try {
      const r = db.rows("SELECT value FROM kv WHERE key='player.queue'")[0];
      if (!r || !r.value) return;
      const o = JSON.parse(r.value);
      const items = loadItems(o.ids, o.recs);
      if (!items.length) return;
      queue = items;
      index = Math.max(0, Math.min(items.length - 1, o.index || 0));
      pendingSeekMs = o.pos || 0;
      repeat = o.repeat || 0; shuffle = !!o.shuffle; smart = !!o.smart; radio = o.radio || null; contextInfo = o.context || null;
      status = 'paused';
      queueVersion++;
      L('I', `restored queue of ${items.length} at ${index}`);
    } catch (e) { L('E', 'restoreState ' + e.message); }
  }
  let pendingSeekMs = 0;

  // ---------------------------------------------------------------- play events (history)

  function startEvent(it) {
    finishEvent(false);
    ev = { trackId: it.trackId, start: Date.now(), played: 0, since: playWhenReady ? performance.now() : -1, item: it };
  }
  function playingChanged(on) {
    if (!ev) return;
    const now = performance.now();
    if (on) { if (ev.since < 0) ev.since = now; } else if (ev.since >= 0) { ev.played += now - ev.since; ev.since = -1; }
  }
  function finishEvent(skipped) {
    if (!ev) return;
    if (ev.since >= 0) ev.played += performance.now() - ev.since;
    const e = ev;
    ev = null;
    const played = Math.round(e.played);
    if (played < 1000) return;
    try {
      db.run('INSERT OR IGNORE INTO play_event(track_id,ts,ms_played,skipped,origin,track_name,artist_name,album_name,dedupe_key) VALUES(?,?,?,?,?,?,?,?,?)',
        [e.trackId, e.start, played, skipped && played < 30000 ? 1 : 0, 'APP', e.item.title, e.item.artists, e.item.album, `app:${e.start}:${e.trackId}`]);
    } catch (err) { L('E', 'play event ' + err.message); }
  }

  // ---------------------------------------------------------------- sources

  function youtubeRef(trackId) {
    const r = db.rows("SELECT ref FROM track_source WHERE track_id=? AND kind='YOUTUBE' AND broken=0 ORDER BY chosen DESC, score DESC, id ASC LIMIT 1", [trackId])[0];
    return r ? r.ref : null;
  }
  const quality = () => setting('qualityWifi') || 'high';

  async function resolveSource(it, { avoid = null, fresh = false } = {}) {
    let videoId = youtubeRef(it.trackId);
    if (!videoId) {
      await engine('matchOne', { trackId: it.trackId, onDemand: true }, 40000).catch(() => null);
      videoId = youtubeRef(it.trackId);
      if (!videoId) throw new Error('No playable source found for this track. Choose another source.');
    }
    const q = quality();
    if (!avoid && !fresh) {
      const c = db.rows('SELECT * FROM resolved_url WHERE video_id=? AND quality=? AND expires_at>?', [videoId, q, Date.now() + 10 * 60000])[0];
      if (c) return { kind: 'YOUTUBE', trackId: it.trackId, videoId, url: c.url, headers: c.headers ? JSON.parse(c.headers) : {}, client: c.client, itag: c.itag, bitrate: c.bitrate, mime: c.mime, loudnessDb: c.loudness_db };
    }
    db.run('DELETE FROM resolved_url WHERE video_id=?', [videoId]);
    const r = await engine('resolve', { videoId, quality: q, avoid }, 45000);
    db.run('INSERT OR REPLACE INTO resolved_url(video_id,quality,url,itag,mime,content_length,bitrate,loudness_db,client,headers,expires_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
      [videoId, q, r.url, r.itag || 0, r.mime || '', r.contentLength || 0, r.bitrate || 0, r.loudnessDb ?? null, r.client || '', JSON.stringify(r.headers || {}), r.expiresAt || Date.now() + 3 * 3600e3, Date.now()]);
    if (typeof r.loudnessDb === 'number') db.run("UPDATE track_source SET loudness_db=? WHERE track_id=? AND kind='YOUTUBE' AND ref=?", [r.loudnessDb, it.trackId, videoId]);
    return { kind: 'YOUTUBE', trackId: it.trackId, videoId, url: r.url, headers: r.headers || {}, client: r.client, itag: r.itag, bitrate: r.bitrate, mime: r.mime, loudnessDb: r.loudnessDb };
  }

  function streamUrl(s) {
    const h = btoa(unescape(encodeURIComponent(JSON.stringify(s.headers || {})))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    return `api/stream?u=${encodeURIComponent(s.url)}&h=${h}`;
  }
  function applyVolume() {
    let v = 1;
    if (setting('normalize') !== false && curSource && typeof curSource.loudnessDb === 'number' && curSource.loudnessDb > 0) v = Math.pow(10, -curSource.loudnessDb / 20);
    audio.volume = Math.max(0.05, Math.min(1, v));
  }

  // ---------------------------------------------------------------- playback

  async function playIndex(i, play, startMs = 0, { avoid = null, fresh = false } = {}) {
    if (i < 0 || i >= queue.length) return;
    clearTimeout(autoSkipTimer);
    const seq = ++loadSeq;
    const changed = i !== index || !curSource;
    index = i;
    playWhenReady = play;
    errorMsg = null;
    const it = queue[i];
    const reload = avoid || fresh;
    const prevSource = curSource;
    if (changed || reload) { audio.pause(); audio.removeAttribute('src'); curSource = null; }
    if (changed && !reload) { retried = false; startEvent(it); }
    buffering = true;
    setStatus('loading');
    try {
      const s = await (resolve || resolveSource)(it, { avoid, fresh, db, current: prevSource });
      if (seq !== loadSeq) return;
      curSource = s;
      applyVolume();
      audio.src = (srcFor || streamUrl)(s);
      if (startMs > 0) {
        await new Promise((res) => { audio.addEventListener('loadedmetadata', res, { once: true }); setTimeout(res, 8000); });
        if (seq !== loadSeq) return;
        try { audio.currentTime = startMs / 1000; } catch { /* ignore */ }
      }
      if (playWhenReady) await audio.play().catch((e) => { if (seq === loadSeq && e.name !== 'AbortError') throw e; });
      else { buffering = false; setStatus('paused'); }
      saveState();
      maybeExtendRadio();
    } catch (e) {
      if (seq !== loadSeq) return;
      failed(it, String(e.message || e), startMs);
    }
  }

  function failed(it, msg, posMs) {
    L('W', `playback failed '${it.title}': ${msg}`);
    if (curSource && curSource.kind === 'YOUTUBE' && !retried && !/No playable source/.test(msg)) {
      retried = true;
      const avoid = curSource.client;
      L('I', `retrying with a fresh URL (avoiding ${avoid}) at ${posMs} ms`);
      playIndex(index, playWhenReady, posMs, { avoid });
      return;
    }
    consecutiveErrors++;
    buffering = false;
    const offline = !navigator.onLine;
    errorMsg = offline ? 'No connection to YouTube right now.' : /No playable source/.test(msg) ? 'No playable version found on YouTube.' : "YouTube didn't give a playable stream.";
    setStatus('error');
    if (consecutiveErrors < 4 && playWhenReady && !offline && index + 1 < queue.length) {
      postNotice(`Couldn't play ${it.title} · skipped`);
      autoSkipTimer = setTimeout(() => { finishEvent(false); playIndex(index + 1, true, 0); }, 1500);
    }
  }

  function play() {
    if (!queue.length) return;
    if (index < 0) index = 0;
    playWhenReady = true;
    if (!curSource || status === 'error' || status === 'ended') {
      const pos = status === 'ended' ? 0 : pendingSeekMs;
      pendingSeekMs = 0;
      if (status === 'ended' && index >= queue.length - 1) index = 0;
      playIndex(index, true, pos);
      return;
    }
    audio.play().catch((e) => L('W', 'play: ' + e.message));
  }
  function pause() { playWhenReady = false; audio.pause(); if (status !== 'error') setStatus(curSource ? 'paused' : status); saveState(); }
  function toggle() { if (playWhenReady && status !== 'error') pause(); else play(); }

  function nextIndex() {
    if (!queue.length) return -1;
    if (repeat === REPEAT_ONE) return index;
    if (index + 1 < queue.length) return index + 1;
    if (repeat === REPEAT_ALL) return 0;
    return -1;
  }
  function next(user) {
    if (user && repeat === REPEAT_ONE && index + 1 < queue.length) { finishEvent(true); playIndex(index + 1, true, 0); return; }
    const n = user ? (index + 1 < queue.length ? index + 1 : repeat === REPEAT_ALL ? 0 : -1) : nextIndex();
    if (n < 0) {
      if (hasEngine && (radio || setting('autoRadio') !== false)) { pendingAdvance = true; if (radio) extendRadio(); else autoRadio(); return; }
      finishEvent(false); playWhenReady = false; audio.pause(); setStatus('ended'); return;
    }
    finishEvent(!!user);
    playIndex(n, true, 0);
  }
  function prev() {
    if ((audio.currentTime || 0) > 3) { audio.currentTime = 0; emitState(); return; }
    if (index > 0) { finishEvent(true); playIndex(index - 1, true, 0); } else { audio.currentTime = 0; emitState(); }
  }
  function seek(ms) { if (curSource) { try { audio.currentTime = ms / 1000; } catch { /* */ } } else pendingSeekMs = ms; emitState(); }

  function setQueue(items, i) { queue = items; unshuffled = null; index = i; shuffle = false; smart = false; queueChanged(); }
  function setShuffle(on) {
    if (on === shuffle) return;
    const cur = current();
    if (on) {
      unshuffled = [...queue];
      const rest = queue.filter((_, i) => i !== index);
      for (let i = rest.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [rest[i], rest[j]] = [rest[j], rest[i]]; }
      queue = cur ? [cur, ...rest] : rest;
      index = cur ? 0 : -1;
    } else if (unshuffled) {
      queue = unshuffled.filter((x) => queue.includes(x)).concat(queue.filter((x) => !unshuffled.includes(x)));
      index = cur ? queue.indexOf(cur) : -1;
      unshuffled = null;
    }
    shuffle = on;
  }
  function insertItems(items, at) {
    if (!items.length) return;
    queue.splice(Math.max(0, Math.min(queue.length, at)), 0, ...items);
    if (index < 0) index = 0;
    queueChanged();
    if (status === 'idle') playIndex(index, false, 0);
  }
  function removeAt(i) {
    if (i < 0 || i >= queue.length) return;
    const [removed] = queue.splice(i, 1);
    if (unshuffled) unshuffled = unshuffled.filter((x) => x !== removed);
    if (i < index) index--;
    else if (i === index) {
      finishEvent(true);
      if (!queue.length) { index = -1; audio.pause(); audio.removeAttribute('src'); curSource = null; playWhenReady = false; status = 'idle'; queueChanged(); return; }
      index = Math.min(index, queue.length - 1);
      playIndex(index, playWhenReady, 0);
    }
    queueChanged();
  }
  function move(from, to) {
    if (from < 0 || to < 0 || from >= queue.length || to >= queue.length || from === to) return;
    const cur = current();
    const [x] = queue.splice(from, 1);
    queue.splice(to, 0, x);
    index = cur ? queue.indexOf(cur) : index;
    queueChanged();
  }
  function snapshot() { return { queue: [...queue], index, pos: Math.round((audio.currentTime || 0) * 1000), shuffle, radio, contextInfo }; }

  // ---------------------------------------------------------------- radio

  let pendingAdvance = false;
  async function startRadio(c) {
    setStatus('loading');
    try {
      const r = await engine('radioStart', { seedTrackId: c.seedTrackId || 0, mode: c.mode || 'track', playlistId: c.playlistId || 0, artist: c.artist || '', params: c.params || '', name: c.name || '' }, 60000);
      const items = loadItems(r.trackIds || []);
      if (!items.length) { errorMsg = 'Radio found nothing to play'; setStatus('error'); return; }
      const before = queue.length ? snapshot() : null;
      radio = r.radio || {};
      setQueue(items, 0);
      contextInfo = { type: 'radio', name: r.name || 'Radio' };
      undoQueue = before;
      finishEvent(true);
      playIndex(0, true, 0);
    } catch (e) { errorMsg = 'Could not start radio'; L('W', 'radio: ' + e.message); setStatus('error'); }
  }
  function maybeExtendRadio() { if (radio && queue.length - index - 1 < 5) extendRadio(); }
  async function extendRadio() {
    if (!radio || radioLoading) return;
    radioLoading = true;
    try {
      const r = await engine('radioMore', { radio, queueTrackIds: queue.slice(-300).map((q) => q.trackId), seedTrackId: current()?.trackId || 0 }, 60000);
      if (r.radio) radio = r.radio;
      const items = loadItems(r.trackIds || []);
      if (items.length) {
        queue.push(...items);
        queueChanged();
        if (pendingAdvance) { pendingAdvance = false; finishEvent(false); playIndex(index + 1, true, 0); }
      } else if (pendingAdvance) { pendingAdvance = false; setStatus('ended'); }
    } catch (e) { L('W', 'radio more: ' + e.message); if (pendingAdvance) { pendingAdvance = false; setStatus('ended'); } }
    finally { radioLoading = false; }
  }
  function autoRadio() {
    const it = current();
    if (!it) { setStatus('ended'); return; }
    pendingAdvance = false;
    startRadio({ seedTrackId: it.trackId, mode: 'track' });
  }

  // ---------------------------------------------------------------- audio element events

  audio.addEventListener('playing', () => { buffering = false; consecutiveErrors = 0; if (status !== 'playing') setStatus('playing'); playingChanged(true); });
  audio.addEventListener('pause', () => { playingChanged(false); if (status === 'playing') setStatus('paused'); });
  audio.addEventListener('waiting', () => { buffering = true; emitState(); });
  audio.addEventListener('durationchange', () => emitState());
  audio.addEventListener('ended', () => {
    playingChanged(false);
    if (sleepEndOfTrack) { sleepEndOfTrack = false; finishEvent(false); playWhenReady = false; setStatus('paused'); return; }
    if (repeat === REPEAT_ONE) { audio.currentTime = 0; audio.play(); return; }
    next(false);
  });
  audio.addEventListener('error', () => {
    const it = current();
    if (!it || !audio.getAttribute('src')) return;
    const code = audio.error ? audio.error.code : 0;
    failed(it, `media error ${code}${audio.error?.message ? ': ' + audio.error.message : ''}`, Math.round((audio.currentTime || 0) * 1000));
  });

  setInterval(() => {
    if (sleepAt && Date.now() >= sleepAt) { sleepAt = 0; L('I', 'sleep timer: pausing'); pause(); }
    if (playWhenReady && status === 'playing') {
      emitState();
      if (Math.floor(Date.now() / 1000) % 15 === 0) saveState();
    }
  }, 1000);

  // ---------------------------------------------------------------- media keys / Windows media overlay

  function updateMediaSession() {
    if (!('mediaSession' in navigator)) return;
    const it = current();
    try {
      if (it && (!navigator.mediaSession.metadata || navigator.mediaSession.metadata.title !== it.title)) {
        navigator.mediaSession.metadata = new MediaMetadata({ title: it.title, artist: it.artists, album: it.album, artwork: it.artwork ? [{ src: it.artwork, sizes: '512x512' }] : [] });
      }
      navigator.mediaSession.playbackState = status === 'playing' ? 'playing' : status === 'paused' ? 'paused' : 'none';
    } catch { /* ignore */ }
  }
  if ('mediaSession' in navigator) {
    const ms = navigator.mediaSession;
    ms.setActionHandler('play', () => play());
    ms.setActionHandler('pause', () => pause());
    ms.setActionHandler('nexttrack', () => next(true));
    ms.setActionHandler('previoustrack', () => prev());
    try { ms.setActionHandler('seekto', (d) => seek(d.seekTime * 1000)); } catch { /* older */ }
  }

  // ---------------------------------------------------------------- commands (PlaybackService.handle)

  function handle(c) {
    switch (c.cmd) {
      case 'playTracks': {
        const items = loadItems(c.trackIds, c.recs);
        if (!items.length) return;
        radio = c.radio || null;
        undoQueue = null;
        finishEvent(true);
        setQueue(items, Math.max(0, Math.min(items.length - 1, c.index || 0)));
        contextInfo = c.context || null;
        if (c.smart || c.shuffle) { setShuffle(true); smart = !!c.smart; queueChanged(); }
        playIndex(index, true, 0);
        break;
      }
      case 'enqueue': insertItems(loadItems(c.trackIds), queue.length); break;
      case 'playNext': insertItems(loadItems(c.trackIds), index + 1); break;
      case 'play': play(); break;
      case 'pause': pause(); break;
      case 'toggle': toggle(); break;
      case 'next': next(true); break;
      case 'prev': prev(); break;
      case 'seek': seek(c.ms || 0); break;
      case 'jump': if (c.index >= 0 && c.index < queue.length) { finishEvent(true); playIndex(c.index, true, 0); } break;
      case 'remove': removeAt(c.index ?? -1); break;
      case 'move': move(c.from ?? -1, c.to ?? -1); break;
      case 'clearQueue': queue = queue.slice(0, index + 1); unshuffled = null; radio = null; queueChanged(); break;
      case 'repeat': repeat = Math.max(0, Math.min(2, c.mode || 0)); queueChanged(); break;
      case 'shuffle': setShuffle(!!c.on); smart = false; queueChanged(); break;
      case 'shuffleMode': setShuffle((c.mode || 0) > 0); smart = c.mode === 2; queueChanged(); break;
      case 'restoreQueue':
        if (undoQueue) {
          const u = undoQueue; undoQueue = null;
          queue = u.queue; radio = u.radio; contextInfo = u.contextInfo; shuffle = u.shuffle;
          finishEvent(true); queueChanged(); playIndex(u.index, true, u.pos);
        }
        break;
      case 'radio': startRadio(c); break;
      case 'radioOff': radio = null; pendingAdvance = false; queueChanged(); break;
      case 'sleep':
        if (c.cancel) { sleepAt = 0; sleepEndOfTrack = false; }
        else if (c.endOfTrack) { sleepEndOfTrack = true; sleepAt = 0; }
        else { sleepAt = Date.now() + (c.minutes || 30) * 60000; sleepEndOfTrack = false; }
        emitState();
        break;
      case 'retry': case 'reloadSource': {
        const pos = Math.round((audio.currentTime || 0) * 1000);
        retried = false;
        if (current()) playIndex(index, true, c.cmd === 'retry' ? 0 : pos, { avoid: curSource?.client || null, fresh: true });
        break;
      }
      case 'refreshMeta': {
        const fresh = loadItems([c.trackId])[0];
        if (fresh) queue = queue.map((q) => (q.trackId === fresh.trackId ? { ...fresh, rec: q.rec } : q));
        emitState(true);
        break;
      }
      case 'dismissError': consecutiveErrors = 0; clearTimeout(autoSkipTimer); errorMsg = null; emitState(); break;
      case 'resetQueue':
        finishEvent(false); audio.pause(); audio.removeAttribute('src');
        queue = []; unshuffled = null; undoQueue = null; radio = null; contextInfo = null; index = -1; curSource = null; playWhenReady = false; status = 'idle';
        queueChanged();
        break;
      default: break;
    }
  }

  restoreState();
  return {
    command(c) { handle(c); return state(false); },
    state: () => state(true),
    toggleLikeCurrent() {
      const it = current();
      if (!it) return;
      if (isLiked(it.trackId)) db.run('DELETE FROM likes WHERE track_id=?', [it.trackId]);
      else db.run("INSERT OR IGNORE INTO likes(track_id,liked_at,origin) VALUES(?,?,'APP')", [it.trackId, Date.now()]);
      emitState();
      emit('library', { what: 'likes' });
    },
    flush() { finishEvent(false); saveState(); },
  };
}
