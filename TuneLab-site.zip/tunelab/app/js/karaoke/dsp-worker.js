// Karaoke DSP worker (bundled to web/vendor/dsp-worker.js and started from a Blob URL).
import * as k from '../lib/karaoke-dsp.js';

self.onmessage = (e) => {
  const { id, cmd } = e.data;
  const progress = (p) => self.postMessage({ id, progress: p });
  try {
    let result;
    const transfer = [];
    if (cmd === 'analyzeOriginal') {
      const { channels, sr } = e.data;
      const n = channels[0].length;
      const mid = new Float32Array(n);
      for (const c of channels) for (let i = 0; i < n; i++) mid[i] += c[i] / channels.length;
      const env = k.onsetEnvelope(mid, sr, 50);
      const ref = k.melodyContour(mid, sr, { onProgress: progress }); // full mix: predominant melody, not YIN
      result = { ref, env };
      transfer.push(ref.midi.buffer, env.buffer);
    } else if (cmd === 'envelope') {
      const { channels, sr } = e.data;
      const n = channels[0].length;
      const mono = new Float32Array(n);
      for (const c of channels) for (let i = 0; i < n; i++) mono[i] += c[i] / channels.length;
      result = { env: k.onsetEnvelope(mono, sr, 50) };
      transfer.push(result.env.buffer);
    } else if (cmd === 'align') {
      result = k.bestLag(e.data.a, e.data.b, e.data.maxLag);
    } else if (cmd === 'vocalFilter') {
      const { channels, sr } = e.data;
      const R = channels[1] || channels[0];
      result = { channels: k.vocalFilter(channels[0], R, sr) };
      result.channels.forEach((c) => transfer.push(c.buffer));
    } else if (cmd === 'pitchShift') {
      const { channels, sr, semitones } = e.data;
      result = { channels: k.pitchShift(channels, sr, semitones, { onProgress: progress }) };
      result.channels.forEach((c) => transfer.push(c.buffer));
    } else if (cmd === 'contour') {
      result = { contour: k.pitchContour(k.normalizeLevel(e.data.samples, e.data.sr), e.data.sr, { fmin: 80, fmax: 1100, threshold: 0.15, minRms: 0.01 }) };
      transfer.push(result.contour.midi.buffer);
    } else {
      throw new Error('unknown cmd ' + cmd);
    }
    self.postMessage({ id, result }, transfer);
  } catch (err) {
    self.postMessage({ id, error: String((err && err.message) || err) });
  }
};
