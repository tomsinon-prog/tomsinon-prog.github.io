// Voice effect presets for karaoke (like Smule's "Studio", "Pop", "Hall"…), built from plain WebAudio nodes
// so the same chain works live (hear myself), in the review player and in the OfflineAudioContext render.

export const VOICE_PRESETS = {
  natural: { name: 'Natural', hp: 80 },
  studio: { name: 'Studio', hp: 90, comp: 1, presence: 2, air: 2, reverb: 0.16, size: 1.4 },
  pop: { name: 'Pop', hp: 100, comp: 2, presence: 4, air: 4, reverb: 0.22, size: 1.8, double: 0.18 },
  warm: { name: 'Warm', hp: 70, comp: 1, warmth: 3, air: -2, reverb: 0.2, size: 1.6 },
  hall: { name: 'Concert hall', hp: 90, comp: 1, presence: 1, reverb: 0.5, size: 3.4, predelay: 0.03 },
  echo: { name: 'Echo', hp: 90, comp: 1, reverb: 0.14, size: 1.4, echo: 0.32, echoTime: 0.32, feedback: 0.38 },
  club: { name: 'Club', hp: 110, comp: 2, presence: 3, air: 3, double: 0.35, echo: 0.18, echoTime: 0.18, feedback: 0.25, reverb: 0.25, size: 2 },
  radio: { name: 'Radio', hp: 450, lp: 3400, comp: 2, presence: 6, reverb: 0.05, size: 0.6 },
};
export const PRESET_ORDER = ['natural', 'studio', 'pop', 'warm', 'hall', 'echo', 'club', 'radio'];

const impulses = new WeakMap(); // ctx -> Map(size -> AudioBuffer)

/** Exponentially decaying stereo noise: a cheap, smooth room. */
function impulse(ctx, sec) {
  let m = impulses.get(ctx);
  if (!m) { m = new Map(); impulses.set(ctx, m); }
  const key = sec.toFixed(2);
  if (m.has(key)) return m.get(key);
  const len = Math.max(1, Math.round(ctx.sampleRate * sec));
  const b = ctx.createBuffer(2, len, ctx.sampleRate);
  let seed = 12345;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;
  for (let c = 0; c < 2; c++) {
    const d = b.getChannelData(c);
    for (let i = 0; i < len; i++) d[i] = rnd() * Math.pow(1 - i / len, 3.2) * 0.5;
  }
  m.set(key, b);
  return b;
}

function biquad(ctx, type, freq, gain = 0, q = 0.8) {
  const f = ctx.createBiquadFilter();
  f.type = type;
  f.frequency.value = freq;
  f.Q.value = q;
  f.gain.value = gain;
  return f;
}

/**
 * input -> [filters, compressor] -> dry + reverb + echo + doubler -> out.
 * level: voice volume; amount: scales the wet effects (0 = dry, 1 = preset, up to 1.5).
 * Returns the oscillators it started (stop them when the sound stops).
 */
export function voiceChain(ctx, input, out, { preset = 'studio', level = 1, amount = 1 } = {}) {
  const p = VOICE_PRESETS[preset] || VOICE_PRESETS.studio;
  const sources = []; // oscillators the caller must stop() with the rest
  let node = input;
  const chain = (n) => { node.connect(n); node = n; };
  if (p.hp) chain(biquad(ctx, 'highpass', p.hp, 0, 0.7));
  if (p.lp) chain(biquad(ctx, 'lowpass', p.lp, 0, 0.7));
  if (p.warmth) chain(biquad(ctx, 'peaking', 220, p.warmth, 0.9));
  if (p.presence) chain(biquad(ctx, 'peaking', 3200, p.presence, 1));
  if (p.air) chain(biquad(ctx, 'highshelf', 9000, p.air));
  if (p.comp) {
    const c = ctx.createDynamicsCompressor();
    c.threshold.value = p.comp > 1 ? -26 : -20;
    c.ratio.value = p.comp > 1 ? 4 : 2.5;
    c.knee.value = 6;
    c.attack.value = 0.005;
    c.release.value = 0.12;
    chain(c);
    const makeup = ctx.createGain();
    makeup.gain.value = p.comp > 1 ? 1.6 : 1.3;
    chain(makeup);
  }
  const dry = ctx.createGain();
  dry.gain.value = level;
  node.connect(dry).connect(out);
  const wetLevel = (x) => x * amount * level;
  if (p.reverb && amount > 0) {
    let src = node;
    if (p.predelay) { const d = ctx.createDelay(0.2); d.delayTime.value = p.predelay; node.connect(d); src = d; }
    const conv = ctx.createConvolver();
    conv.buffer = impulse(ctx, p.size || 1.6);
    const wet = ctx.createGain();
    wet.gain.value = wetLevel(p.reverb);
    src.connect(conv).connect(wet).connect(out);
  }
  if (p.echo && amount > 0) {
    const d = ctx.createDelay(1.5);
    d.delayTime.value = p.echoTime || 0.3;
    const fb = ctx.createGain();
    fb.gain.value = p.feedback || 0.3;
    const tone = biquad(ctx, 'lowpass', 4500); // each repeat a little darker
    const wet = ctx.createGain();
    wet.gain.value = wetLevel(p.echo);
    node.connect(d);
    d.connect(tone).connect(fb).connect(d);
    d.connect(wet).connect(out);
  }
  if (p.double && amount > 0) {
    // two slightly detuned, slowly wobbling copies left and right: a fuller "doubled" vocal
    [[0.012, 0.6, -0.6], [0.019, 0.9, 0.6]].forEach(([base, rate, pan]) => {
      const d = ctx.createDelay(0.1);
      d.delayTime.value = base;
      const lfo = ctx.createOscillator();
      lfo.frequency.value = rate;
      const depth = ctx.createGain();
      depth.gain.value = 0.002;
      lfo.connect(depth).connect(d.delayTime);
      lfo.start();
      sources.push(lfo);
      const g = ctx.createGain();
      g.gain.value = wetLevel(p.double);
      const pn = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
      node.connect(d).connect(g);
      if (pn) { pn.pan.value = pan; g.connect(pn).connect(out); } else g.connect(out);
    });
  }
  return sources;
}
