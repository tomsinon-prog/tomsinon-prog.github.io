// Karaoke session: loads the original + a backing track, lyrics and a reference melody, records takes from
// the microphone in sync with the backing, scores them and renders/saves the final mix.
import * as bridge from '../core/bridge.js';
import * as db from '../core/db.js';
import { getLyrics } from '../lib/lyrics.js';
import { parseLrc } from '../lib/lrc.js';
import { yin, decimate, hzToMidi, scoreTake, placeSegments } from '../lib/karaoke-dsp.js';
import { bytesToB64 } from '../yt/fetch-shim.js';
import { voiceChain, VOICE_PRESETS } from './effects.js';
import { MixPlayer } from './mix-player.js';

const HOP = 0.02;
let workerCode = null, workletUrl = null;
// addModule() is per AudioContext: every karaoke session has its own context, so remember which ones have it.
const workletReady = new WeakSet();

async function blobUrl(rel, type = 'text/javascript') {
  const res = await fetch(new URL(rel, import.meta.url));
  if (!res.ok) throw new Error('cannot load ' + rel);
  return URL.createObjectURL(new Blob([await res.text()], { type }));
}

/** Runs one DSP command in a worker (Blob URL, so no extra network loads), with progress. */
export async function dsp(cmd, data, transfer = [], onProgress = () => {}) {
  if (!workerCode) workerCode = await blobUrl('../../vendor/dsp-worker.js');
  return new Promise((resolve, reject) => {
    const w = new Worker(workerCode);
    w.onmessage = (e) => {
      if (e.data.progress != null) { onProgress(e.data.progress); return; }
      w.terminate();
      if (e.data.error) reject(new Error(e.data.error)); else resolve(e.data.result);
    };
    w.onerror = (e) => { w.terminate(); reject(new Error(e.message || 'worker failed')); };
    w.postMessage({ id: 1, cmd, ...data }, transfer);
  });
}

const channelsOf = (buf) => Array.from({ length: buf.numberOfChannels }, (_, i) => buf.getChannelData(i).slice());

function toBuffer(ctx, channels, sr) {
  const b = ctx.createBuffer(Math.max(2, channels.length), channels[0].length, sr);
  b.copyToChannel(channels[0], 0);
  b.copyToChannel(channels[1] || channels[0], 1);
  return b;
}

export class KaraokeSession {
  constructor(track) {
    this.track = track;
    this.prefsKey = 'karaoke.track.' + track.id;
    this.prefs = { backing: null, offsetMs: null, keyShift: 0, ...(db.kvGetJson(this.prefsKey) || {}) };
    const preset = db.kvGet('karaoke.preset');
    this.mix = { voice: 1, backing: 0.8, voice2: 1, amount: 1, preset: VOICE_PRESETS[preset] ? preset : 'studio' };
    this.takes = [];
    this.lines = [];
    this.lyricsPlain = null;
    this.ref = null;
    this.candidates = [];
    this.backingInfo = null;
  }

  savePrefs() { db.kvSetJson(this.prefsKey, this.prefs); }

  get latencySec() {
    const saved = db.kvGet('set.karaokeLatencyMs');
    if (saved != null && saved !== 'null') return Number(saved) / 1000;
    const c = this.ctx;
    return ((c && (c.outputLatency || 0) + (c.baseLatency || 0)) || 0.08) + 0.03;
  }

  set latencySec(v) { db.kvSet('set.karaokeLatencyMs', String(Math.round(v * 1000))); }

  get offsetSec() { return (this.prefs.offsetMs || 0) / 1000; }

  async decode(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error('audio not available (HTTP ' + res.status + ')');
    return this.ctx.decodeAudioData(await res.arrayBuffer());
  }

  /** step(name, state, detail) callback for the progress UI. */
  async prepare(step) {
    this.ctx = this.ctx || new AudioContext({ latencyHint: 'interactive' });
    const sr = this.ctx.sampleRate;
    // 1. lyrics
    step('lyrics', 'run');
    try {
      const ly = await getLyrics({ trackId: this.track.id, title: this.track.title, artists: this.track.artists, album: this.track.album, durationMs: this.track.duration_ms });
      const parsed = ly.synced ? parseLrc(ly.synced) : [];
      this.lyricsPlain = ly.plain;
      this.rawLines = parsed.filter((l, i, a) => l.text || (a[i + 1] && a[i + 1].ms - l.ms > 4000));
      step('lyrics', 'ok', parsed.length ? `${parsed.length} synced lines` : ly.plain ? 'only plain lyrics' : 'no lyrics found');
    } catch (e) {
      this.rawLines = [];
      step('lyrics', 'warn', e.message);
    }
    // 2. original
    step('original', 'run');
    const off = bridge.on('media', (m) => step(m.videoId === this.backingVideo ? 'backing' : 'original', 'run', Math.round(m.progress * 100) + '%'));
    try {
      const o = await bridge.callAsync('media.prepare', { trackId: this.track.id });
      this.originalUrl = o.url;
      const orig = await this.decode(o.url);
      this.duration = orig.duration;
      step('original', 'ok', o.kind === 'YOUTUBE' ? 'from YouTube' : o.kind === 'LOCAL_FILE' ? 'local file' : 'downloaded');
      // 3. reference melody + envelope
      step('melody', 'run');
      const an = await dsp('analyzeOriginal', { channels: channelsOf(orig), sr }, [], (p) => step('melody', 'run', Math.round(p * 100) + '%'));
      this.refRaw = an.ref;
      this.envOrig = an.env;
      this.origChannels = null;
      step('melody', 'ok');
      // 4. backing
      await this.loadBacking(step, orig);
    } finally {
      off();
    }
    this.buildTimeline();
  }

  async loadBacking(step, origBuf = null) {
    const sr = this.ctx.sampleRate;
    step('backing', 'run');
    if (this.prefs.backing == null) {
      try {
        const r = await bridge.callAsync('engine.call', { method: 'karaokeFind', args: { trackId: this.track.id }, timeoutMs: 45000 });
        this.candidates = r.candidates || [];
      } catch (e) {
        this.candidates = [];
      }
      this.prefs.backing = this.candidates[0] ? this.candidates[0].videoId : 'filter';
    }
    let buf;
    if (this.prefs.backing === 'filter') {
      const orig = origBuf || await this.decode(this.originalUrl);
      const out = await dsp('vocalFilter', { channels: channelsOf(orig), sr });
      buf = toBuffer(this.ctx, out.channels, sr);
      this.prefs.offsetMs = 0;
      this.backingInfo = { kind: 'filter', title: 'Vocal filter on the original' };
      step('backing', 'ok', 'vocal filter (no karaoke version found)');
    } else {
      this.backingVideo = this.prefs.backing;
      const m = await bridge.callAsync('media.prepare', { videoId: this.prefs.backing });
      buf = await this.decode(m.url);
      const cand = this.candidates.find((c) => c.videoId === this.prefs.backing);
      this.backingInfo = { kind: 'youtube', videoId: this.prefs.backing, title: cand ? cand.title : 'YouTube karaoke version' };
      if (this.prefs.offsetMs == null) {
        step('sync', 'run');
        const env = (await dsp('envelope', { channels: channelsOf(buf), sr })).env;
        const r = await dsp('align', { a: this.envOrig, b: env, maxLag: 20 * 50 });
        this.prefs.offsetMs = Math.round((r.lag / 50) * 1000);
        this.alignScore = r.score;
        step('sync', r.score > 0.12 ? 'ok' : 'warn', r.score > 0.12 ? `offset ${(r.lag / 50).toFixed(2)} s` : 'uncertain: check the lyrics timing');
      }
      step('backing', 'ok', this.backingInfo.title);
    }
    this.backingRaw = buf;
    this.backing = buf;
    this.savePrefs();
    if (this.prefs.keyShift) await this.applyKey(this.prefs.keyShift, step);
  }

  async applyKey(semitones, step = () => {}) {
    this.prefs.keyShift = semitones;
    this.savePrefs();
    if (!semitones) { this.backing = this.backingRaw; return; }
    step('key', 'run');
    const out = await dsp('pitchShift', { channels: channelsOf(this.backingRaw), sr: this.ctx.sampleRate, semitones }, [], (p) => step('key', 'run', Math.round(p * 100) + '%'));
    this.backing = toBuffer(this.ctx, out.channels, this.ctx.sampleRate);
    step('key', 'ok', (semitones > 0 ? '+' : '') + semitones);
  }

  /** Lines and reference melody on the backing timeline. */
  buildTimeline() {
    const off = this.offsetSec;
    this.lines = (this.rawLines || []).map((l, i, a) => ({
      text: l.text, start: l.ms / 1000 + off, end: (a[i + 1] ? a[i + 1].ms / 1000 : l.ms / 1000 + 6) + off,
    })).filter((l) => l.text);
    const n = Math.ceil((this.backing ? this.backing.duration : this.duration || 0) / HOP);
    const midi = new Float32Array(Math.max(0, n));
    if (this.refRaw) {
      // map by time: the analysis hop is not exactly HOP (decimation rounding), and that drifts over a song
      const src = this.refRaw.midi, h = this.refRaw.hopSec || HOP;
      for (let j = 0; j < n; j++) { const i = Math.round((j * HOP - off) / h); if (i >= 0 && i < src.length) midi[j] = src[i]; }
    }
    // only keep the melody where lyrics are sung (instruments otherwise dominate)
    if (this.lines.length) {
      for (let j = 0; j < n; j++) {
        const t = j * HOP;
        if (!this.lines.some((l) => t >= l.start - 0.2 && t < l.end)) midi[j] = 0;
      }
    }
    this.ref = { hopSec: HOP, midi };
  }

  nudge(ms) {
    this.prefs.offsetMs = (this.prefs.offsetMs || 0) + ms;
    this.savePrefs();
    this.buildTimeline();
  }

  // ---------------------------------------------------------------- singing

  /**
   * Records from the mic while the backing plays. The singer can seek (skip the intro, redo a part): every seek
   * starts a new segment {ctxAt, songAt}; the recording itself is one continuous stream from `startAt`, and
   * finishTake() places each stretch of it at the right song position.
   */
  async startSinging({ monitor = false, onTick, from = 0 } = {}) {
    const ctx = this.ctx;
    if (ctx.state !== 'running') await ctx.resume();
    if (!workletUrl) workletUrl = await blobUrl('./recorder-worklet.js');
    if (!workletReady.has(ctx)) { await ctx.audioWorklet.addModule(workletUrl); workletReady.add(ctx); }
    const granted = await bridge.callAsync('permission.request', { name: 'android.permission.RECORD_AUDIO' });
    if (!granted) throw new Error('Microphone permission is needed to sing');
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 1 } });
    const mic = ctx.createMediaStreamSource(this.stream);
    const rec = new AudioWorkletNode(ctx, 'tl-recorder', { numberOfInputs: 1, numberOfOutputs: 1, channelCount: 1 });
    const sink = ctx.createGain();
    sink.gain.value = 0;
    mic.connect(rec).connect(sink).connect(ctx.destination);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    mic.connect(analyser);
    const extra = [];
    if (monitor) {
      const g = ctx.createGain();
      g.gain.value = 0.9;
      mic.connect(g);
      extra.push(...voiceChain(ctx, g, ctx.destination, { preset: this.mix.preset, level: 1, amount: this.mix.amount }));
    }
    const chunks = [];
    rec.port.onmessage = (e) => { if (e.data.chunk) chunks.push(e.data.chunk); if (e.data.done) this._recDone && this._recDone(); };
    const startAt = ctx.currentTime + 3;
    const bus = ctx.createGain(); // backing + earlier duet voices; rebuilt on every seek
    bus.connect(ctx.destination);
    const segments = [{ ctxAt: startAt, songAt: Math.max(0, from) }];
    let playing = [];
    let finish = () => {}; // replaced below; the backing's onended calls it when the song ends
    const startSources = (at, songAt) => {
      for (const n of playing) { try { n.stop(at); } catch { /* ended */ } }
      playing = [];
      const src = ctx.createBufferSource();
      src.buffer = this.backing;
      const bg = ctx.createGain();
      bg.gain.value = this.mix.backing;
      src.connect(bg).connect(bus);
      src.start(at, songAt);
      src.onended = () => { if (playing[0] === src) finish(); };
      playing.push(src);
      for (const take of this.takes) { // duet: earlier voices play along
        const v = ctx.createBufferSource();
        v.buffer = take.buffer;
        const g = ctx.createGain();
        v.connect(g);
        playing.push(...voiceChain(ctx, g, bus, { preset: this.mix.preset, level: 0.9, amount: this.mix.amount }));
        const off = songAt + take.latency;
        if (off < take.buffer.duration) v.start(at, off);
        playing.push(v);
      }
    };
    startSources(startAt, segments[0].songAt);
    rec.port.postMessage({ cmd: 'start', frame: Math.round(startAt * ctx.sampleRate) });
    const live = new Float32Array(Math.ceil(this.backing.duration / HOP) + 10);
    const lat = this.latencySec;
    const frame = new Float32Array(analyser.fftSize);
    const songAt = (c) => {
      let seg = segments[0];
      for (const x of segments) if (x.ctxAt <= c) seg = x;
      return seg.songAt + Math.max(0, c - seg.ctxAt);
    };
    this.running = { startAt, live, lat, segments, songAt };
    let raf, level = 0, done = false;
    const tick = () => {
      const c = ctx.currentTime;
      const t = c < startAt ? segments[0].songAt : songAt(c);
      let pitch = 0;
      if (c >= startAt) {
        analyser.getFloatTimeDomainData(frame);
        // the voicing threshold follows the mic's own level (phone and headset mics differ a lot)
        let e = 0;
        for (let i = 0; i < frame.length; i++) e += frame[i] * frame[i];
        level = Math.max(Math.sqrt(e / frame.length), level * 0.995);
        const p = yin(decimate(frame, 4), ctx.sampleRate / 4, { fmin: 80, fmax: 1100, minRms: Math.max(0.0015, 0.12 * level) });
        if (p.hz > 0) pitch = hzToMidi(p.hz);
        const j = Math.round((t - lat) / HOP);
        if (j >= 0 && j < live.length) { live[j] = pitch; if (j > 0 && !live[j - 1]) live[j - 1] = pitch; }
      }
      onTick && onTick({ t, pitch, countdown: c < startAt ? Math.ceil(startAt - c) : 0 });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const result = new Promise((resolve) => {
      finish = async () => {
        if (done) return;
        done = true;
        cancelAnimationFrame(raf);
        const endCtx = ctx.currentTime;
        await new Promise((r) => { this._recDone = r; rec.port.postMessage({ cmd: 'stop' }); setTimeout(r, 800); });
        for (const n of [...playing, ...extra]) { try { n.stop(); } catch { /* ended */ } }
        try { bus.disconnect(); } catch { /* ignore */ }
        this.stream.getTracks().forEach((tr) => tr.stop());
        mic.disconnect();
        const total = chunks.reduce((n, x) => n + x.length, 0);
        const pcm = new Float32Array(total);
        let o = 0;
        for (const x of chunks) { pcm.set(x, o); o += x.length; }
        this.running = null;
        this._seek = null;
        resolve({ pcm, sr: ctx.sampleRate, latency: lat, live, startAt, endCtx: Math.max(endCtx, startAt), segments });
      };
      this._stop = finish;
    });
    this._seek = (to) => {
      const c = ctx.currentTime;
      if (c < startAt) return; // not during the countdown
      const at = c + 0.05;
      const target = Math.max(0, Math.min(this.backing.duration - 1, to));
      segments.push({ ctxAt: at, songAt: target });
      startSources(at, target);
    };
    return result;
  }

  stopSinging() { if (this._stop) { const s = this._stop; this._stop = null; s(); } }

  /** Jump while singing (seconds on the song timeline). */
  seekSinging(t) { if (this._seek) this._seek(t); }

  liveScore() {
    if (!this.running || !this.ref) return null;
    return scoreTake({ hopSec: HOP, midi: this.running.live }, this.ref, { lines: this.lines.length ? this.lines : null, keyShift: this.prefs.keyShift }).score;
  }

  /**
   * Turns a recording into a take: the voice placed on the song timeline (seeks resolved; later singing over the
   * same part replaces it) plus the sung regions, then scores it from the recorded audio.
   */
  async finishTake(raw) {
    const { sr } = raw;
    const { voice, regions: merged, songEnd } = placeSegments(raw, Math.ceil(this.backing.duration * sr) + sr);
    const len = voice.length;
    const buffer = this.ctx.createBuffer(1, len, sr);
    buffer.copyToChannel(voice, 0);
    let score = null;
    try {
      const c = (await dsp('contour', { samples: voice, sr })).contour;
      const shift = Math.round(raw.latency / c.hopSec);
      const midi = new Float32Array(c.midi.length);
      for (let i = shift; i < c.midi.length; i++) midi[i - shift] = c.midi[i];
      // score only what was sung: lyric lines (or the whole region) inside the sung regions
      const parts = [];
      for (const [a, b] of merged) {
        if (this.lines.length) { for (const l of this.lines) { const x = Math.max(a, l.start), y = Math.min(b, l.end); if (y - x > 0.3) parts.push({ start: x, end: y }); } }
        else parts.push({ start: a, end: b });
      }
      score = parts.length ? scoreTake({ hopSec: c.hopSec, midi }, this.ref, { lines: parts, keyShift: this.prefs.keyShift }).score : null;
    } catch (e) {
      bridge.log('W', 'karaoke', 'scoring failed: ' + e.message);
    }
    return { buffer, latency: raw.latency, score, regions: merged, sungStart: merged.length ? merged[0][0] : 0, sungEnd: songEnd };
  }

  // ---------------------------------------------------------------- mixing

  /** Part of the song that the recording covers: from just before the first sung moment to just after the last. */
  get mixRange() {
    const starts = this.takes.map((t) => t.sungStart), ends = this.takes.map((t) => t.sungEnd);
    const a = starts.length ? Math.max(0, Math.min(...starts) - 1) : 0;
    const b = ends.length ? Math.min(this.backing.duration, Math.max(...ends) + 2) : this.backing.duration;
    return [a, Math.max(a + 1, b)];
  }

  /** Backing + all takes with the voice preset, from song position `from`, into `out`. Returns what to stop(). */
  buildMix(ctx, when = 0, from = 0, out = ctx.destination) {
    const b = ctx.createBufferSource();
    b.buffer = this.backing;
    const bg = ctx.createGain();
    bg.gain.value = this.mix.backing;
    b.connect(bg).connect(out);
    b.start(when, from);
    const nodes = [b];
    this.takes.forEach((take, i) => {
      const v = ctx.createBufferSource();
      v.buffer = take.buffer;
      const g = ctx.createGain();
      v.connect(g);
      nodes.push(...voiceChain(ctx, g, out, { preset: this.mix.preset, level: i === 0 ? this.mix.voice : this.mix.voice2, amount: this.mix.amount }));
      const offset = Math.max(0, take.latency + from);
      if (offset < take.buffer.duration) v.start(when, offset);
      nodes.push(v);
    });
    return nodes;
  }

  /** The review player (play / pause / seek over the recorded part). */
  player(onEnd) {
    this.closePlayer();
    const [a, b] = this.mixRange;
    this.reviewPlayer = new MixPlayer(this.ctx, (ctx, when, from, out) => this.buildMix(ctx, when, from, out), { start: a, end: b, onEnd });
    return this.reviewPlayer;
  }

  closePlayer() { if (this.reviewPlayer) { this.reviewPlayer.close(); this.reviewPlayer = null; } }

  /** Renders the mix offline and saves it as AAC (.m4a) in Music/TuneLab Karaoke. */
  async save(onProgress = () => {}) {
    const sr = this.ctx.sampleRate;
    const [from, to] = this.mixRange;
    const length = Math.max(sr, Math.ceil((to - from) * sr));
    const off = new OfflineAudioContext(2, length, sr);
    this.buildMix(off, 0, from, off.destination);
    onProgress('Mixing…');
    const out = await off.startRendering();
    const L = out.getChannelData(0), R = out.getChannelData(1);
    let peak = 0;
    for (let i = 0; i < length; i++) peak = Math.max(peak, Math.abs(L[i]), Math.abs(R[i]));
    const norm = peak > 0.98 ? 0.98 / peak : 1;
    const { id } = bridge.call('rec.begin');
    const FR = 96000; // frames per chunk (384 KB)
    for (let s = 0; s < length; s += FR) {
      const n = Math.min(FR, length - s);
      const pcm = new Int16Array(n * 2);
      for (let i = 0; i < n; i++) {
        pcm[2 * i] = Math.max(-1, Math.min(1, L[s + i] * norm)) * 32767;
        pcm[2 * i + 1] = Math.max(-1, Math.min(1, R[s + i] * norm)) * 32767;
      }
      bridge.call('rec.append', { id, b64: bytesToB64(new Uint8Array(pcm.buffer)) });
      onProgress(`Saving… ${Math.round(((s + n) / length) * 100)}%`);
      await new Promise((r) => setTimeout(r, 0));
    }
    onProgress('Encoding…');
    const scores = this.takes.map((t) => t.score).filter((x) => x != null);
    return bridge.callAsync('rec.finish', {
      id, sampleRate: sr, channels: 2, title: this.track.title, artists: this.track.artists, trackId: this.track.id,
      score: scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null,
      keyShift: this.prefs.keyShift, backing: this.prefs.backing, voices: this.takes.length,
    });
  }

  close() {
    this.stopSinging();
    this.closePlayer();
    try { this.stream && this.stream.getTracks().forEach((t) => t.stop()); } catch { /* ignore */ }
    try { this.ctx && this.ctx.close(); } catch { /* ignore */ }
  }
}
