// Play / pause / seek over WebAudio sources (AudioBufferSourceNodes can't pause, so pausing = stop and
// remember the position, playing = build fresh sources from that position).
export class MixPlayer {
  /**
   * build(ctx, when, from, out) creates and starts the sources (connected to `out`) and returns everything
   * that must be stop()ped. [start, end] is the playable range in seconds.
   */
  constructor(ctx, build, { start = 0, end = Infinity, onEnd = () => {} } = {}) {
    this.ctx = ctx;
    this.build = build;
    this.start = start;
    this.end = end;
    this.onEnd = onEnd;
    this._pos = start;
    this.nodes = null;
  }

  get playing() { return !!this.nodes; }
  get duration() { return this.end - this.start; }
  get pos() { return this.nodes ? Math.min(this.end, this.ctx.currentTime - this.t0) : this._pos; }

  play(from = this._pos) {
    if (from >= this.end - 0.05) from = this.start;
    this._stopNodes();
    const ctx = this.ctx;
    if (ctx.state !== 'running') ctx.resume();
    const out = ctx.createGain();
    out.connect(ctx.destination);
    const when = ctx.currentTime + 0.03;
    this.out = out;
    this.nodes = this.build(ctx, when, Math.max(this.start, from), out) || [];
    this.t0 = when - Math.max(this.start, from);
    this.timer = setInterval(() => {
      if (this.nodes && this.pos >= this.end - 0.02) { this._stopNodes(); this._pos = this.start; this.onEnd(); }
    }, 100);
  }

  pause() {
    if (!this.nodes) return;
    this._pos = this.pos;
    this._stopNodes();
  }

  toggle() { if (this.playing) this.pause(); else this.play(); }

  seek(t) {
    const x = Math.max(this.start, Math.min(this.end, t));
    if (this.nodes) this.play(x); else this._pos = x;
  }

  /** Rebuild from the current position (after an effect/volume change). */
  refresh() { if (this.nodes) this.play(this.pos); }

  _stopNodes() {
    clearInterval(this.timer);
    if (this.nodes) for (const n of this.nodes) { try { n.stop(); } catch { /* not started / ended */ } }
    // disconnecting the output cuts reverb/echo tails at once: pause means silence
    try { this.out && this.out.disconnect(); } catch { /* ignore */ }
    this.nodes = null;
    this.out = null;
  }

  close() { this._stopNodes(); }
}
