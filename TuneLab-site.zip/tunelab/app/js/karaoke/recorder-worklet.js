// AudioWorklet that records the microphone from an exact audio frame on (loaded from a Blob URL).
class TlRecorder extends AudioWorkletProcessor {
  constructor() {
    super();
    this.from = Infinity;
    this.on = false;
    this.buf = [];
    this.size = 0;
    this.port.onmessage = (e) => {
      if (e.data.cmd === 'start') { this.from = e.data.frame; this.on = true; }
      if (e.data.cmd === 'stop') { this.flush(); this.on = false; this.port.postMessage({ done: true }); }
    };
  }
  flush() {
    if (!this.size) return;
    const out = new Float32Array(this.size);
    let o = 0;
    for (const b of this.buf) { out.set(b, o); o += b.length; }
    this.buf = [];
    this.size = 0;
    this.port.postMessage({ chunk: out }, [out.buffer]);
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (this.on && ch) {
      const start = currentFrame, end = currentFrame + ch.length;
      if (end > this.from) {
        const skip = Math.max(0, this.from - start);
        this.buf.push(ch.slice(skip));
        this.size += ch.length - skip;
        if (this.size >= 24000) this.flush();
      }
    }
    return true;
  }
}
registerProcessor('tl-recorder', TlRecorder);
