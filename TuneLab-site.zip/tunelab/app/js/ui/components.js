// Reusable UI pieces: virtual track list with letter index + drag reorder, sheets, dialogs, toasts.
import { icon, art, esc, h, $ } from './dom.js';
import { fmtDur } from '../core/util.js';

export const ROW_H = 64;

// ------------------------------------------------------------------ overlays stack (for the back button)
const overlays = [];
export function closeTopOverlay() {
  const c = overlays.pop();
  if (c) { c(); return true; }
  return false;
}
export function closeAllOverlays() { while (overlays.length) overlays.pop()(); }

function mountOverlay(el, onClose) {
  const root = $('#overlay');
  const scrim = h('<div class="scrim"></div>');
  root.append(scrim, el);
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    scrim.remove(); el.remove();
    const i = overlays.indexOf(close);
    if (i >= 0) overlays.splice(i, 1);
    onClose && onClose();
  };
  scrim.addEventListener('click', close);
  overlays.push(close);
  return close;
}

// ------------------------------------------------------------------ in-app dropdowns (no Android picker dialogs)

/** Popover list anchored to `anchor`. options: [{value, label}]. Resolves the chosen value (or null). */
export function dropdownMenu(anchor, options, current) {
  return new Promise((resolve) => {
    const el = h(`<div class="dd-menu" role="listbox">${options.map((o, i) => `<button class="dd-item${String(o.value) === String(current) ? ' on' : ''}" data-i="${i}" role="option">
      <span>${esc(o.label)}</span>${String(o.value) === String(current) ? icon('check') : ''}</button>`).join('')}</div>`);
    const close = mountOverlay(el, () => resolve(null));
    el.previousElementSibling.classList.add('light'); // the dropdown scrim is lighter than a sheet's
    const r = anchor.getBoundingClientRect();
    const W = window.innerWidth, H = window.innerHeight;
    const width = Math.min(W - 16, Math.max(r.width, 200));
    el.style.width = width + 'px';
    el.style.left = Math.max(8, Math.min(W - width - 8, r.left)) + 'px';
    const below = H - r.bottom - 12, above = r.top - 12;
    if (below >= Math.min(320, options.length * 48) || below >= above) { el.style.top = (r.bottom + 4) + 'px'; el.style.maxHeight = Math.max(160, below) + 'px'; }
    else { el.style.bottom = (H - r.top + 4) + 'px'; el.style.maxHeight = Math.max(160, above) + 'px'; }
    el.querySelector('.on')?.scrollIntoView({ block: 'nearest' });
    el.addEventListener('click', (e) => {
      const b = e.target.closest('.dd-item');
      if (!b) return;
      const v = options[+b.dataset.i].value;
      resolve(v); // before close(): closing resolves null (dismissed)
      close();
    });
  });
}

/**
 * Replaces the look and the picker of every <select> under `root` with an in-app dropdown. The <select> stays in
 * the DOM (hidden) and keeps the value, and a real "change" event is fired, so view code needs no changes.
 */
export function enhanceSelects(root = document) {
  for (const sel of root.querySelectorAll('select:not([data-dd])')) {
    sel.dataset.dd = '1';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'dd';
    btn.setAttribute('aria-haspopup', 'listbox');
    if (sel.getAttribute('aria-label')) btn.setAttribute('aria-label', sel.getAttribute('aria-label'));
    if (sel.style.maxWidth) btn.style.maxWidth = sel.style.maxWidth;
    const label = () => { btn.innerHTML = `<span>${esc(sel.options[sel.selectedIndex]?.text || '')}</span>${icon('down')}`; };
    label();
    sel.addEventListener('change', label);
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const opts = [...sel.options].map((o) => ({ value: o.value, label: o.text }));
      const v = await dropdownMenu(btn, opts, sel.value);
      if (v == null || v === sel.value) return;
      sel.value = v;
      sel.dispatchEvent(new Event('change', { bubbles: true }));
    });
    sel.after(btn);
  }
}

/** Bottom sheet menu. items: [{icon, label, sub, run, danger}] */
export function sheet({ head, items = [], body = '' }) {
  return new Promise((resolve) => {
    const el = h(`<div class="sheet"><div class="grab"></div>
      ${head ? `<div class="sh-head">${head.art !== undefined ? art(head.art) : ''}<div class="meta"><div class="t1">${esc(head.title)}</div>${head.sub ? `<div class="t2">${esc(head.sub)}</div>` : ''}</div></div>` : ''}
      ${body ? `<div class="body">${body}</div>` : ''}
      ${items.map((it, i) => `<button class="item${it.danger ? ' danger' : ''}" data-i="${i}">${icon(it.icon || 'note')}<div><div>${esc(it.label)}</div>${it.sub ? `<div class="faint">${esc(it.sub)}</div>` : ''}</div></button>`).join('')}
    </div>`);
    const close = mountOverlay(el, () => resolve(null));
    el.addEventListener('click', (e) => {
      const b = e.target.closest('.item');
      if (!b) return;
      const it = items[+b.dataset.i];
      close();
      resolve(it);
      try { it.run && it.run(); } catch (err) { console.error(err); toast(String(err.message || err)); }
    });
  });
}

/** Sheet with custom content; returns {el, close}. */
export function panel(html) {
  const el = h(`<div class="sheet"><div class="grab"></div><div class="body">${html}</div></div>`);
  const close = mountOverlay(el);
  return { el, close };
}

export function dialog({ title, body = '', buttons = [{ label: 'OK', value: true, primary: true }] }) {
  return new Promise((resolve) => {
    const el = h(`<div class="dialog"><h3>${esc(title)}</h3>${body}<div class="btns">${buttons.map((b, i) =>
      `<button class="btn ${b.primary ? 'primary' : ''} ${b.danger ? 'danger' : ''}" data-i="${i}">${esc(b.label)}</button>`).join('')}</div></div>`);
    let value = null;
    const close = mountOverlay(el, () => resolve(value));
    el.addEventListener('click', (e) => {
      const b = e.target.closest('.btns .btn');
      if (!b) return;
      const def = buttons[+b.dataset.i];
      value = typeof def.value === 'function' ? def.value(el) : def.value;
      close();
    });
    setTimeout(() => { const inp = el.querySelector('input,textarea'); if (inp) { inp.focus(); inp.select?.(); } }, 50);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.target.tagName === 'INPUT') { const p = buttons.findIndex((b) => b.primary); if (p >= 0) el.querySelector(`[data-i="${p}"]`).click(); }
    });
  });
}

export function prompt({ title, value = '', placeholder = '', ok = 'Save', type = 'text' }) {
  return dialog({
    title,
    body: `<input type="${type}" value="${esc(value)}" placeholder="${esc(placeholder)}">`,
    buttons: [{ label: 'Cancel', value: null }, { label: ok, primary: true, value: (el) => el.querySelector('input').value.trim() || null }],
  });
}

export function confirmDialog({ title, text = '', ok = 'OK', danger = false }) {
  return dialog({ title, body: text ? `<p class="muted">${esc(text)}</p>` : '', buttons: [{ label: 'Cancel', value: false }, { label: ok, primary: !danger, danger, value: true }] });
}

export function choose({ title, options }) {
  return new Promise((resolve) => {
    sheet({ head: { title }, items: options.map((o) => ({ icon: o.icon || (o.on ? 'check' : 'note'), label: o.label, sub: o.sub, run: () => resolve(o.value) })) })
      .then((r) => { if (!r) resolve(null); });
  });
}

export function toast(msg, { action, onAction, ms = 3500 } = {}) {
  const box = $('#toast');
  // never a pile of toasts: the same text replaces itself, and at most two are shown (newest wins)
  for (const old of [...box.children]) if (old.firstChild?.textContent === String(msg)) old.remove();
  while (box.children.length >= 2) box.firstChild.remove();
  const el = h(`<div class="toast"><span>${esc(msg)}</span>${action ? `<button>${esc(action)}</button>` : ''}</div>`);
  box.append(el);
  const t = setTimeout(() => el.remove(), ms);
  if (action) el.querySelector('button').addEventListener('click', () => { clearTimeout(t); el.remove(); onAction && onAction(); });
}

// ------------------------------------------------------------------ track rows

export function badgesFor(t) {
  const b = [];
  if (t.rec) b.push('<span class="badge rec">NEW</span>');
  if (t.best_source === 'DOWNLOADED') b.push(`<span class="badge acc" title="Downloaded">${icon('downloaded')}</span>`.replace('<svg ', '<svg style="width:13px;height:13px" '));
  else if (t.best_source === 'LOCAL_FILE') b.push('<span class="badge acc">LOCAL</span>');
  if (t.match_state === 'REVIEW') b.push('<span class="badge warn">CHECK</span>');
  else if (t.match_state === 'FAILED' && !t.best_source) b.push('<span class="badge err">NO MATCH</span>');
  if (t.missing_on_spotify || t.entry_missing) b.push('<span class="badge">GONE ON SPOTIFY</span>');
  if (t.state === 'FAILED') b.push('<span class="badge err">FAILED</span>');
  else if (t.state === 'QUEUED') b.push('<span class="badge">QUEUED</span>');
  else if (t.state === 'RUNNING') b.push(`<span class="badge acc">${Math.round((t.progress || 0) * 100)}%</span>`);
  return b.join('');
}

export function trackRowHtml(t, i, { top = true, current = false, reorder = false, sub = null, staticRow = false } = {}) {
  const artists = t.artists || (Array.isArray(t.artistsArr) ? t.artistsArr.join(', ') : '') || t.channel || '';
  const dur = t.duration_ms ?? t.durationMs;
  const heart = t.liked ? `<svg class="heart" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>` : '';
  const line2 = sub != null ? `${badgesFor(t)}<span>${esc(sub)}</span>` : `${heart}${badgesFor(t)}<span>${esc(artists)}</span>${dur ? `<span class="sep">·</span><span>${fmtDur(dur)}</span>` : ''}`;
  return `<div class="trow${current ? ' current' : ''}${staticRow ? ' static' : ''}" data-i="${i}" ${top && !staticRow ? `style="top:${i * ROW_H}px"` : ''}>
    ${art(t.artwork_url || t.thumb || t.artwork, { fallback: t.kind === 'artist' ? 'artist' : t.kind === 'album' ? 'album' : 'note', round: t.kind === 'artist' })}
    <div class="meta"><div class="t1">${esc(t.title || t.name || '')}</div><div class="t2">${line2}</div></div>
    ${reorder ? `<div class="handle">${icon('drag')}</div>` : ''}
    <button class="icon-btn more" aria-label="More">${icon('more')}</button>
  </div>`;
}

// ------------------------------------------------------------------ virtual list

/**
 * Virtualized list inside the #view scroller: only visible rows exist in the DOM, so 10k items stay fast.
 * opts: {items, renderRow(item,i), onTap(item,i,e), onMore(item,i,e), letterOf(item), onMove(from,to), isCurrent(item)}
 */
export class VirtualList {
  constructor(container, opts) {
    this.c = container;
    this.o = opts;
    this.items = opts.items || [];
    this.scroller = opts.scroller || $('#view');
    this.range = [-1, -1];
    this.onScroll = () => { if (!this.raf) this.raf = requestAnimationFrame(() => { this.raf = 0; this.render(); }); };
    this.scroller.addEventListener('scroll', this.onScroll, { passive: true });
    window.addEventListener('resize', this.onScroll);
    this.c.classList.add('list');
    this.c.addEventListener('click', (e) => this.click(e));
    if (opts.onMove) this.c.addEventListener('pointerdown', (e) => this.dragStart(e));
    this.setItems(this.items);
  }

  setItems(items) {
    this.items = items;
    this.c.style.height = items.length * ROW_H + 'px';
    this.range = [-1, -1];
    this.render();
    this.buildIndex();
  }

  refresh() { this.range = [-1, -1]; this.render(); }

  listTop() {
    return this.c.getBoundingClientRect().top - this.scroller.getBoundingClientRect().top + this.scroller.scrollTop;
  }

  render() {
    if (!this.c.isConnected) return;
    const top = this.listTop();
    const st = this.scroller.scrollTop - top;
    const vh = this.scroller.clientHeight;
    const first = Math.max(0, Math.floor(st / ROW_H) - 10);
    const last = Math.min(this.items.length, Math.ceil((st + vh) / ROW_H) + 10);
    if (first === this.range[0] && last === this.range[1]) return;
    this.range = [first, last];
    let html = '';
    for (let i = first; i < last; i++) html += this.o.renderRow(this.items[i], i);
    this.c.innerHTML = html;
  }

  click(e) {
    const row = e.target.closest('.trow');
    if (!row || e.target.closest('.handle')) return;
    const i = +row.dataset.i;
    const item = this.items[i];
    if (e.target.closest('.more')) this.o.onMore && this.o.onMore(item, i, e);
    else this.o.onTap && this.o.onTap(item, i, e);
  }

  scrollToIndex(i) { this.scroller.scrollTop = this.listTop() + i * ROW_H - 8; }

  // ---- fast-scroll letter index
  buildIndex() {
    this.az?.remove();
    this.az = null;
    this.c.classList.remove('has-az');
    if (!this.o.letterOf || this.items.length < 40) return;
    const first = new Map();
    this.items.forEach((it, i) => { const l = this.o.letterOf(it); if (l && !first.has(l)) first.set(l, i); });
    if (first.size < 3) return;
    const letters = [...first.keys()];
    const r = this.scroller.getBoundingClientRect();
    const az = h(`<div class="az" style="top:${r.top + 8}px;height:${Math.max(120, r.height - 16)}px">${letters.map((l) => `<span>${esc(l)}</span>`).join('')}</div>`);
    document.body.append(az);
    this.az = az;
    this.c.classList.add('has-az');
    let bubble = null;
    const pick = (y) => {
      const rr = az.getBoundingClientRect();
      const idx = Math.max(0, Math.min(letters.length - 1, Math.floor((y - rr.top) / rr.height * letters.length)));
      const l = letters[idx];
      this.scrollToIndex(first.get(l));
      if (!bubble) { bubble = h('<div class="az-bubble"></div>'); document.body.append(bubble); }
      bubble.textContent = l;
      bubble.style.top = Math.max(rr.top, Math.min(rr.bottom - 64, y - 32)) + 'px';
    };
    az.addEventListener('pointerdown', (e) => { az.setPointerCapture(e.pointerId); pick(e.clientY); e.preventDefault(); });
    az.addEventListener('pointermove', (e) => { if (e.buttons) pick(e.clientY); });
    const end = () => { bubble?.remove(); bubble = null; };
    az.addEventListener('pointerup', end);
    az.addEventListener('pointercancel', end);
  }

  // ---- drag & drop reorder (via the row handle)
  dragStart(e) {
    const handle = e.target.closest('.handle');
    if (!handle) return;
    e.preventDefault();
    const row = handle.closest('.trow');
    const from = +row.dataset.i;
    const ghost = row.cloneNode(true);
    ghost.classList.add('dragging');
    this.c.append(ghost);
    const line = h('<div class="drop-line"></div>');
    this.c.append(line);
    const startY = e.clientY;
    const baseTop = from * ROW_H;
    let to = from;
    let autoScroll = 0;
    const move = (y) => {
      const dy = y - startY + (this.scroller.scrollTop - startScroll);
      ghost.style.top = baseTop + dy + 'px';
      to = Math.max(0, Math.min(this.items.length - 1, Math.round((baseTop + dy) / ROW_H)));
      line.style.top = (to > from ? (to + 1) * ROW_H : to * ROW_H) - 1 + 'px';
      const r = this.scroller.getBoundingClientRect();
      autoScroll = y < r.top + 60 ? -12 : y > r.bottom - 60 ? 12 : 0;
    };
    const startScroll = this.scroller.scrollTop;
    let lastY = e.clientY;
    const tick = () => {
      if (!ghost.isConnected) return;
      if (autoScroll) { this.scroller.scrollTop += autoScroll; move(lastY); }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    const onMove = (ev) => { lastY = ev.clientY; move(ev.clientY); };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      ghost.remove(); line.remove();
      if (to !== from) this.o.onMove(from, to);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    move(e.clientY);
  }

  destroy() {
    this.scroller.removeEventListener('scroll', this.onScroll);
    window.removeEventListener('resize', this.onScroll);
    this.az?.remove();
  }
}

/** First letter for the fast-scroll index ('#' for digits/symbols). */
export function letterOf(s) {
  const c = String(s || '').trim().replace(/^the\s+/i, '').charAt(0).toUpperCase();
  if (!c) return null;
  return /[A-Z]/.test(c) ? c : /[0-9]/.test(c) ? '#' : c.normalize('NFKD').charAt(0).toUpperCase().replace(/[^A-Z]/, '#');
}
