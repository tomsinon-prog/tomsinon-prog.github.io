// Player state in the UI (mirrors PlaybackService), mini player and the full Now Playing screen.
import { hasEngine } from '../core/platform.js';
import * as bridge from '../core/bridge.js';
import * as db from '../core/db.js';
import * as settings from '../core/settings.js';
import { icon, art, esc, $ } from './dom.js';
import { fmtDur } from '../core/util.js';
import { VirtualList, trackRowHtml, sheet, toast } from './components.js';
import { parseLrc, activeLine } from '../lib/lrc.js';
import { getLyrics } from '../lib/lyrics.js';

const listeners = new Set();

export const player = {
  state: { status: 'idle', queue: [], index: -1, current: null, posMs: 0, durMs: 0, at: Date.now() },
  apply(s) {
    if (!s) return;
    const q = s.queue || this.state.queue;
    this.state = { ...this.state, ...s, queue: q };
    for (const fn of listeners) { try { fn(this.state); } catch (e) { console.error(e); } }
  },
  pos() {
    const s = this.state;
    if (s.status === 'playing' && !s.buffering) return Math.min(s.durMs || Infinity, s.posMs + (Date.now() - s.at));
    return s.posMs || 0;
  },
  cmd(cmd, args = {}) {
    try { this.apply(bridge.call('player', { cmd, ...args })); }
    catch (e) { toast(e.message || String(e)); }
  },
  on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  currentId() { return this.state.current ? this.state.current.trackId : null; },
};

export function initPlayer() {
  bridge.on('player', (s) => player.apply(s));
  try { player.apply(bridge.call('player.state')); } catch { /* service not running yet */ }
  renderMini();
  player.on(renderMini);
  player.on(updateNp);
  setInterval(tickProgress, 500);
  initNpGestures();
}

/**
 * Now Playing gestures: drag down = close (like Back); swipe the artwork / title left = next, right = previous.
 * Sliders, buttons' own taps and the lyrics/queue panel keep working normally.
 */
function initNpGestures() {
  const np = $('#np');
  let sx = 0, sy = 0, t0 = 0, mode = null, side = false, art = null;
  const reset = () => { np.style.transition = ''; np.style.transform = ''; if (art) { art.style.transition = ''; art.style.transform = ''; art.style.opacity = ''; } };
  np.addEventListener('touchstart', (e) => {
    if (!npOpen || e.touches.length !== 1) { mode = 'none'; return; }
    const t = e.target;
    mode = t.closest('input, .np-panel, .np-err') ? 'none' : null;
    side = !!t.closest('.np-stage, .np-title');
    art = np.querySelector('.np-art');
    sx = e.touches[0].clientX; sy = e.touches[0].clientY; t0 = Date.now();
  }, { passive: true });
  np.addEventListener('touchmove', (e) => {
    if (mode === 'none') return;
    const dx = e.touches[0].clientX - sx, dy = e.touches[0].clientY - sy;
    if (!mode) {
      if (dy > 12 && dy > Math.abs(dx) * 1.2) mode = 'down';
      else if (side && Math.abs(dx) > 12 && Math.abs(dx) > Math.abs(dy) * 1.2) mode = 'side';
      else return;
    }
    if (mode === 'down') { np.style.transition = 'none'; np.style.transform = `translateY(${Math.max(0, dy)}px)`; }
    else if (art) { art.style.transition = 'none'; art.style.transform = `translateX(${dx}px)`; art.style.opacity = String(1 - Math.min(0.6, Math.abs(dx) / 400)); }
  }, { passive: true });
  np.addEventListener('touchend', (e) => {
    if (!mode || mode === 'none') { mode = null; return; }
    const tt = e.changedTouches[0];
    const dx = tt.clientX - sx, dy = tt.clientY - sy;
    const fast = Date.now() - t0 < 250;
    if (mode === 'down') {
      if (dy > 120 || (fast && dy > 40)) {
        np.style.transition = 'transform .18s ease';
        np.style.transform = 'translateY(105%)';
        setTimeout(() => { closeNowPlaying(); reset(); }, 180);
      } else { np.style.transition = 'transform .18s ease'; np.style.transform = ''; setTimeout(reset, 200); }
    } else {
      if (Math.abs(dx) > 80 || (fast && Math.abs(dx) > 30)) {
        if (art) { art.style.transition = 'transform .15s ease, opacity .15s'; art.style.transform = `translateX(${dx < 0 ? -420 : 420}px)`; art.style.opacity = '0'; }
        setTimeout(() => { player.cmd(dx < 0 ? 'next' : 'prev'); setTimeout(reset, 50); }, 150);
      } else if (art) { art.style.transition = 'transform .15s ease, opacity .15s'; art.style.transform = ''; art.style.opacity = ''; setTimeout(reset, 160); }
    }
    mode = null;
  });
}

// ------------------------------------------------------------------ mini player

let miniKey = '';
function renderMini() {
  const el = $('#mini');
  const s = player.state;
  const c = s.current;
  if (!c) { el.classList.add('hidden'); return; }
  el.classList.remove('hidden');
  const playing = s.playWhenReady && s.status !== 'error' && s.status !== 'ended';
  const loading = s.status === 'loading' || s.buffering;
  const key = `${c.trackId}|${playing}|${loading}|${s.status}|${c.liked}`;
  if (key === miniKey) return;
  miniKey = key;
  el.innerHTML = `${art(c.artwork)}<div class="meta"><div class="t1">${esc(c.title)}</div><div class="t2">${s.status === 'error' ? '<span style="color:var(--danger)">Playback problem · tap for options</span>' : esc(c.artists)}</div></div>
    <button class="icon-btn like ${c.liked ? 'on' : ''}" data-a="like" aria-label="Like">${icon(c.liked ? 'heart' : 'heartO')}</button>
    <button class="icon-btn" data-a="toggle">${loading && playing ? icon('refresh', 'spin') : icon(playing ? 'pause' : 'play')}</button>
    <button class="icon-btn" data-a="next">${icon('next')}</button><div class="bar"><div></div></div>`;
  el.onclick = async (e) => {
    const b = e.target.closest('[data-a]');
    if (b) {
      e.stopPropagation();
      if (b.dataset.a === 'like') (await import('./actions.js')).toggleLike(player.state.current.trackId);
      else player.cmd(b.dataset.a);
      return;
    }
    openNowPlaying();
  };
  tickProgress();
}

function tickProgress() {
  const s = player.state;
  const d = s.durMs || (s.current && s.current.durationMs) || 0;
  const p = player.pos();
  const bar = $('#mini .bar div');
  if (bar) bar.style.width = d ? Math.min(100, (p / d) * 100) + '%' : '0';
  if (npOpen) {
    const seek = $('#np .seek input');
    if (seek && !seeking) { seek.max = d || 1; seek.value = p; }
    const t = $('#np .times');
    if (t) t.innerHTML = `<span>${fmtDur(p) || '0:00'}</span><span>${fmtDur(d)}</span>`;
    if (panelMode === 'lyrics') syncLyrics(p);
    const sl = $('#np .sleep-left');
    if (sl) sl.textContent = s.sleepInMs > 0 ? Math.ceil((s.sleepInMs - (Date.now() - s.at)) / 60000) + ' min' : s.sleepEndOfTrack ? 'end of track' : '';
  }
}

// ------------------------------------------------------------------ now playing

let npOpen = false, seeking = false, npKey = '', panelMode = 'none', queueList = null, lyrics = null, lyricsFor = 0, lastLyricIdx = -2;

export function isNpOpen() { return npOpen; }

export function openNowPlaying() {
  if (!player.state.current) return;
  npOpen = true;
  npKey = '';
  document.body.classList.add('np-open');
  $('#np').classList.remove('closed');
  updateNp();
}

export function closeNowPlaying() {
  if (!npOpen) return false;
  npOpen = false;
  document.body.classList.remove('np-open');
  $('#np').classList.add('closed');
  queueList?.destroy();
  queueList = null;
  return true;
}

function sourceChip(s) {
  const src = s.source;
  if (!src) return s.status === 'loading' ? '<span class="badge">RESOLVING…</span>' : '';
  const label = src.kind === 'LOCAL_FILE' ? 'LOCAL' : src.kind === 'DOWNLOADED' ? 'DOWNLOADED' : (src.cached ? 'YOUTUBE · CACHED' : 'YOUTUBE');
  const detail = src.kind === 'YOUTUBE' ? [src.mime && src.mime.replace('audio/', ''), src.bitrate ? Math.round(src.bitrate / 1000) + ' kbps' : '', src.client].filter(Boolean).join(' · ') : '';
  return `<span class="badge acc">${label}</span>${detail ? `<span>${esc(detail)}</span>` : ''}`;
}

function updateNp() {
  if (!npOpen) return;
  const s = player.state;
  const c = s.current;
  const np = $('#np');
  if (!c) { closeNowPlaying(); return; }
  const playing = s.playWhenReady && s.status !== 'error' && s.status !== 'ended';
  const key = `${c.trackId}|${s.queueVersion}`;
  if (key !== npKey) {
    npKey = key;
    np.innerHTML = `<div class="np-top"><button class="icon-btn" data-a="close">${icon('down')}</button>
        <div class="ctx">${esc(s.context?.name || (s.radio ? 'Radio' : 'Now playing'))}</div>
        <button class="icon-btn" data-a="menu">${icon('more')}</button></div>
      <div class="np-body">
        <div class="np-stage">${panelMode === 'none' ? art(c.artwork ? c.artwork.replace(/=w\d+-h\d+/, '=w720-h720') : null, { cls: 'np-art' }) : '<div class="np-panel"></div>'}</div>
        <div class="np-title"><div class="meta"><div class="t1">${esc(c.title)}</div><div class="t2">${esc(c.artists)}</div></div>
          <button class="icon-btn like ${c.liked ? 'on' : ''}" data-a="like">${icon(c.liked ? 'heart' : 'heartO')}</button></div>
        <div class="src"></div>
        <div class="np-err"></div>
        <div class="seek"><input type="range" min="0" max="${s.durMs || c.durationMs || 1}" value="${player.pos()}" step="500"></div>
        <div class="times"></div>
        <div class="ctrls">
          <button class="icon-btn shuf" data-a="shuffle"></button>
          <button class="icon-btn" data-a="prev">${icon('prev')}</button>
          <button class="play" data-a="toggle"></button>
          <button class="icon-btn" data-a="next">${icon('next')}</button>
          <button class="icon-btn rep ${s.repeat ? 'on' : ''}" data-a="repeat">${icon(s.repeat === 2 ? 'repeat1' : 'repeat')}</button>
        </div>
        <div class="np-row2">
          <button class="icon-btn ${panelMode === 'queue' ? 'on' : ''}" data-a="queue">${icon('queue')}</button>
          <button class="icon-btn ${panelMode === 'lyrics' ? 'on' : ''}" data-a="lyrics">${icon('lyrics')}</button>
          ${hasEngine() ? `<button class="icon-btn ${s.radio ? 'on' : ''}" data-a="radio">${icon('radio')}</button>` : ''}
          <button class="icon-btn ${s.sleepInMs > 0 || s.sleepEndOfTrack ? 'on' : ''}" data-a="sleep">${icon('timer')}<small class="sleep-left faint"></small></button>
        </div>
      </div>`;
    const seek = np.querySelector('.seek input');
    seek.addEventListener('input', () => { seeking = true; np.querySelector('.times span').textContent = fmtDur(+seek.value) || '0:00'; });
    seek.addEventListener('change', () => { seeking = false; player.cmd('seek', { ms: +seek.value }); });
    np.onclick = onNpClick;
    fitArt();
    renderPanel();
  }
  np.querySelector('.play').innerHTML = (s.status === 'loading' || s.buffering) && playing ? icon('refresh', 'spin') : icon(playing ? 'pause' : 'play');
  const shuf = np.querySelector('.shuf');
  const mode = shuffleMode(s);
  shuf.classList.toggle('on', mode > 0);
  shuf.innerHTML = icon(mode === 2 ? 'shuffleSmart' : 'shuffle');
  shuf.setAttribute('aria-label', ['Shuffle off', 'Shuffle', 'Smart shuffle'][mode]);
  const rep = np.querySelector('.rep');
  rep.classList.toggle('on', !!s.repeat);
  rep.innerHTML = icon(s.repeat === 2 ? 'repeat1' : 'repeat');
  const like = np.querySelector('.like');
  like.classList.toggle('on', !!c.liked);
  like.innerHTML = icon(c.liked ? 'heart' : 'heartO');
  np.querySelector('.src').innerHTML = sourceChip(s);
  const errEl = np.querySelector('.np-err');
  const errKey = s.status === 'error' ? String(s.error) : '';
  if (errEl.dataset.key !== errKey) {
    errEl.dataset.key = errKey;
    errEl.innerHTML = s.status === 'error' ? `<div class="banner err"><b>Can't play this song</b><div class="faint" style="margin:2px 0 8px">${esc(shortError(s.error))}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn small primary" data-a="retry">Try again</button><button class="btn small" data-a="source">Choose another source</button><button class="btn small" data-a="next">Skip</button></div></div>` : '';
    fitArt(); // the banner takes room from the artwork
  }
  if (panelMode === 'queue' && queueList) {
    queueList.setItems(s.queue);
  }
  tickProgress();
}

async function onNpClick(e) {
  const b = e.target.closest('[data-a]');
  if (!b) return;
  const a = b.dataset.a;
  const s = player.state;
  const c = s.current;
  const actions = await import('./actions.js');
  switch (a) {
    case 'close': closeNowPlaying(); break;
    case 'toggle': case 'next': case 'prev': case 'retry': player.cmd(a); break;
    case 'shuffle': {
      const next = (shuffleMode(s) + 1) % 3;
      player.cmd('shuffleMode', { mode: next });
      toast(next === 2 ? `Smart shuffle: a new song after every ${settings.get('smartShuffleEvery') || 4}` : next === 1 ? 'Shuffle on' : 'Shuffle off');
      break;
    }
    case 'repeat': player.cmd('repeat', { mode: ((s.repeat || 0) + 1) % 3 }); break;
    case 'like': actions.toggleLike(c.trackId); break;
    case 'source': player.cmd('dismissError'); actions.chooseSource(c.trackId); break;
    case 'radio': radioMenu(s, c, actions); break;
    case 'sleep': sleepMenu(); break;
    case 'queue': panelMode = panelMode === 'queue' ? 'none' : 'queue'; npKey = ''; updateNp(); break;
    case 'lyrics': panelMode = panelMode === 'lyrics' ? 'none' : 'lyrics'; npKey = ''; updateNp(); break;
    case 'menu': actions.trackMenu({ id: c.trackId, title: c.title, artists: c.artists, artwork_url: c.artwork }); break;
    default: break;
  }
}

/** Artwork fills the free space above the controls as a square (and shrinks when a message needs room). */
function fitArt() {
  const stage = $('#np .np-stage');
  const a = stage && stage.querySelector('.np-art');
  if (!a) return;
  a.style.width = a.style.height = '0px'; // measure the free space without the artwork itself
  const cs = getComputedStyle(stage);
  const free = stage.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
  const size = Math.max(96, Math.min(stage.clientWidth, free));
  a.style.width = a.style.height = size + 'px';
}
window.addEventListener('resize', () => npOpen && fitArt());

/** One calm sentence instead of the per-client error dump (that goes to the log). */
function shortError(e) {
  const m = String(e || '');
  if (!m) return 'Something went wrong.';
  if (m.length < 100 && !/[:|]/.test(m)) return m; // already a sentence for people (PlaybackService.giveUp)
  if (/unknownhost|unable to resolve|getaddrinfo|network|timeout|timed out/i.test(m)) return 'No connection to YouTube right now.';
  if (/video is unavailable|private|removed|copyright/i.test(m)) return 'This YouTube version is not available.';
  return 'YouTube didn\'t give a playable stream.';
}

// one-shot messages from the player ("Playing another version…", "Couldn't play … · skipped")
let lastNotice = null;
player.on((s) => {
  const id = s.notice ? s.notice.id : 0;
  if (lastNotice === null) { lastNotice = id; return; } // first state: don't repeat an old message after a restart
  if (id && id !== lastNotice) { lastNotice = id; toast(s.notice.text, { ms: 4000 }); }
});

/** 0 = off, 1 = shuffle, 2 = smart shuffle. */
export function shuffleMode(s) { return s.smart ? 2 : s.shuffle ? 1 : 0; }

/** Radio is an action (it replaces the queue, with Undo), not a toggle. */
function radioMenu(s, c, actions) {
  const auto = settings.get('autoRadio');
  const items = [{ icon: 'radio', label: 'Start radio from this song', sub: 'Replaces your queue with similar music (you can undo)', run: () => actions.startRadio(c.trackId) }];
  if (s.radio) items.push({ icon: 'close', label: 'Stop radio', sub: 'Plays what is in the queue, then stops', run: () => { player.cmd('radioOff'); toast('Radio stopped'); } });
  items.push({ icon: auto ? 'check' : 'radio', label: `Autoplay is ${auto ? 'on' : 'off'}`, sub: 'When the queue ends, keep playing similar music', run: () => { settings.set('autoRadio', !auto); toast(`Autoplay ${auto ? 'off' : 'on'}`); } });
  sheet({ head: { title: s.radio ? (s.context?.name || 'Radio') : 'Radio', sub: s.radio ? 'Radio is playing' : `Based on ${c.title}` }, items });
}

function sleepMenu() {
  const opts = [15, 30, 45, 60, 90].map((m) => ({ icon: 'timer', label: `${m} minutes`, run: () => { player.cmd('sleep', { minutes: m }); toast(`Sleep timer: ${m} min`); } }));
  opts.push({ icon: 'timer', label: 'End of this track', run: () => { player.cmd('sleep', { endOfTrack: true }); toast('Stops after this track'); } });
  if (player.state.sleepInMs > 0 || player.state.sleepEndOfTrack) opts.push({ icon: 'close', label: 'Turn off sleep timer', run: () => player.cmd('sleep', { cancel: true }) });
  sheet({ head: { title: 'Sleep timer' }, items: opts });
}

function renderPanel() {
  const panel = $('#np .np-panel');
  queueList?.destroy();
  queueList = null;
  if (!panel) return;
  if (panelMode === 'queue') {
    const s = player.state;
    panel.innerHTML = `<div class="section"><h2>Queue <small>${s.queue.length} songs</small></h2></div><div class="qlist"></div>
      <div class="row-actions"><button class="btn small" data-a2="clear">Clear upcoming</button></div>`;
    const scroller = panel;
    queueList = new VirtualList(panel.querySelector('.qlist'), {
      scroller, items: s.queue,
      renderRow: (t, i) => trackRowHtml(t, i, { current: i === player.state.index, reorder: true }),
      onTap: (t, i) => player.cmd('jump', { index: i }),
      onMore: async (t, i) => (await import('./actions.js')).trackMenu({ id: t.trackId, title: t.title, artists: t.artists, artwork_url: t.artwork }, { queueIndex: i }),
      onMove: (from, to) => player.cmd('move', { from, to }),
    });
    panel.querySelector('[data-a2="clear"]').onclick = () => player.cmd('clearQueue');
    setTimeout(() => queueList && queueList.scrollToIndex(Math.max(0, player.state.index - 1)), 50);
  } else if (panelMode === 'lyrics') {
    panel.innerHTML = '<div class="lyrics"><p class="muted">Looking for lyrics…</p></div>';
    loadLyrics();
  } else {
    panel.innerHTML = '';
  }
}

// ------------------------------------------------------------------ lyrics (LRCLIB)

async function loadLyrics() {
  const c = player.state.current;
  if (!c) return;
  const box = $('#np .lyrics');
  lyricsFor = c.trackId;
  lastLyricIdx = -2;
  try {
    const row = await getLyrics({ trackId: c.trackId, title: c.title, artists: c.artists, album: c.album, durationMs: c.durationMs });
    if (lyricsFor !== c.trackId || !box.isConnected) return;
    if (row.synced) {
      lyrics = parseLrc(row.synced);
      box.className = 'lyrics';
      box.innerHTML = lyrics.map((l, i) => `<p data-i="${i}">${esc(l.text || '♪')}</p>`).join('');
      box.onclick = (e) => { const p = e.target.closest('p'); if (p) player.cmd('seek', { ms: lyrics[+p.dataset.i].ms }); };
    } else if (row.plain) {
      lyrics = null;
      box.className = 'lyrics plain';
      box.innerHTML = row.plain.split('\n').map((l) => `<p>${esc(l)}</p>`).join('');
    } else {
      lyrics = null;
      box.innerHTML = '<p class="muted">No lyrics found on LRCLIB.</p>';
    }
  } catch (e) {
    box.innerHTML = `<p class="muted">Lyrics unavailable: ${esc(e.message)}</p>`;
  }
}

function syncLyrics(posMs) {
  if (!lyrics || lyricsFor !== player.currentId()) return;
  const i = activeLine(lyrics, posMs + 250);
  if (i === lastLyricIdx) return;
  const box = $('#np .lyrics');
  if (!box) return;
  box.querySelector('p.on')?.classList.remove('on');
  const p = box.querySelector(`p[data-i="${i}"]`);
  if (p) {
    p.classList.add('on');
    const body = $('#np .np-panel');
    if (body) body.scrollTo({ top: p.offsetTop - body.clientHeight * 0.4, behavior: 'smooth' });
  }
  lastLyricIdx = i;
}

export function refreshLyricsOnTrackChange() {
  if (panelMode === 'lyrics' && npOpen && lyricsFor !== player.currentId()) renderPanel();
}
player.on(() => refreshLyricsOnTrackChange());
