import { isDesktop, isWeb, hasEngine, platform } from '../../core/platform.js';
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import { icon, art, esc } from '../dom.js';
import { player } from '../player.js';
import { playCollection, startRadio, engineCall } from '../actions.js';
import { fmtAgo } from '../../core/util.js';
import { toast } from '../components.js';

function greeting() {
  const h = new Date().getHours();
  return h < 6 ? 'Good night' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}

export function render(el, p, ctx) {
  ctx.setTitle(greeting());
  const draw = () => {
    const likesN = db.countLikes();
    const pls = db.listPlaylists().filter((x) => x.origin !== 'MIX');
    const mix = db.mixPlaylist();
    const mixTracks = mix ? db.playlistEntries(mix.id) : [];
    const releases = hasEngine() ? db.listReleases({ limit: 15 }) : [];
    const smart = db.listSmart();
    const recent = db.recentlyPlayed(20);
    const counts = db.matchCounts();
    const jobs = safe(() => bridge.call('jobs.status'), {});
    const seenArtists = new Set();
    const eng = hasEngine();
    const radioSeeds = !eng ? [] : recent.filter((t) => { const a = (t.artists || '').split(', ')[0]; if (seenArtists.has(a)) return false; seenArtists.add(a); return true; }).slice(0, 6);
    const empty = likesN === 0 && pls.length === 0;
    el.innerHTML = `
      ${empty ? `<div class="card"><h3>Welcome to TuneLab</h3><p class="muted">${isWeb() ? 'Your music from the phone, in this browser. Bring your library along with a backup file.' : 'Your music, under your control. Start by importing your Spotify library, or just search for something to play.'}</p>
        <div class="row-actions" style="padding:8px 0 0">${isWeb() ? '<button class="btn primary" data-a="importBackup">Open a backup file from the phone</button>' : platform() === 'desktop' ? '<button class="btn primary" data-go="transfer">Get my library from the phone</button>' : '<button class="btn primary" data-go="spotify">Import from Spotify</button>'}${isWeb() ? '' : '<button class="btn" data-go="csv">Import CSV</button><button class="btn" data-tab="search">Search</button>'}</div>${isWeb() ? '<p class="faint small" style="margin:10px 0 0">On the phone: Settings → Backup → Back up now. Get that file to this computer (mail, OneDrive, WhatsApp Web) and open it here.</p>' : ''}</div>` : ''}
      <div class="grid2" style="margin-top:6px">
        <button class="quick" data-go="likes"><div class="art liked">${icon('heart')}</div>Liked songs</button>
        ${eng ? `<button class="quick" data-a="mix">${art(recent[0]?.artwork_url, { fallback: 'sparkle' })}Your mix</button>` : ''}
        <button class="quick" data-go="history">${art(null, { fallback: 'history' })}Recently played</button>
        ${isDesktop() ? '' : `<button class="quick" data-tab="downloads">${art(null, { fallback: 'downloaded' })}Downloads</button>
        <button class="quick" data-go="recordings">${art(null, { fallback: 'lyrics' })}Karaoke</button>`}
        ${eng ? `<button class="quick" data-go="releases">${art(releases[0]?.thumb, { fallback: 'album' })}New releases</button>` : ''}
      </div>
      ${eng ? matchCard(counts, jobs) : ''}
      ${eng || mixTracks.length ? mixCard(mix, mixTracks, jobs) : ''}
      ${releases.length ? `<div class="section"><h2>New releases <button class="btn small" data-go="releases">All</button></h2></div><div class="hscroll" data-list="rel">${releases.map((r, i) => tile(r.thumb, r.title, `${r.artist} · ${r.kind}${r.year ? ' ' + r.year : ''}`, i, 'album', r.baseline ? '' : 'NEW')).join('')}</div>` : ''}
      ${recent.length ? `<div class="section"><h2>Recently played</h2></div><div class="hscroll" data-list="recent">${recent.map((t, i) => tile(t.artwork_url, t.title, t.artists, i)).join('')}</div>` : ''}
      ${pls.length ? `<div class="section"><h2>Your playlists <small>${pls.length}</small></h2></div><div class="hscroll" data-list="pls">${pls.slice(0, 20).map((pl, i) => tile(pl.cover || pl.artwork_url, pl.name, `${pl.n} songs`, i, 'queue')).join('')}</div>` : ''}
      ${smart.length ? `<div class="section"><h2>Smart playlists</h2></div><div class="hscroll" data-list="smart">${smart.map((sp, i) => tile(null, sp.name, 'Smart playlist', i, 'sparkle')).join('')}</div>` : ''}
      ${radioSeeds.length ? `<div class="section"><h2>Radio for you</h2></div><div class="hscroll" data-list="radio">${radioSeeds.map((t, i) => tile(t.artwork_url, `${(t.artists || '').split(', ')[0]} radio`, `Based on ${t.title}`, i, 'radio')).join('')}</div>` : ''}
      <div style="height:12px"></div>`;
    el.onclick = (e) => {
      const go = e.target.closest('[data-go]');
      if (go) return ctx.nav.go(go.dataset.go);
      const tb = e.target.closest('[data-tab]');
      if (tb) return ctx.nav.tab(tb.dataset.tab);
      const a = e.target.closest('[data-a]');
      if (a?.dataset.a === 'mix') return yourMix();
      if (a?.dataset.a === 'importBackup') return import('../actions.js').then((m) => m.restoreBackupFlow()).then((ok) => ok && draw());
      if (a?.dataset.a === 'disc') return mix ? ctx.nav.go('playlist', { id: mix.id }) : null;
      if (a?.dataset.a === 'discplay') { e.stopPropagation(); return mixTracks.length && playCollection(mixTracks.map((x) => x.id), { context: { type: 'playlist', id: mix.id, name: mix.name } }); }
      if (a?.dataset.a === 'discmake') { bridge.call('jobs.start', { job: 'weeklyMix', args: { force: true } }); toast('Building your Weekly Discovery…'); return setTimeout(draw, 300); }
      if (a?.dataset.a === 'match') { bridge.call('jobs.start', { job: 'match' }); toast('Matching started'); return setTimeout(draw, 300); }
      const t = e.target.closest('.tile');
      if (!t) return;
      const list = t.parentElement.dataset.list, i = +t.dataset.i;
      if (list === 'recent') playCollection(recent.map((x) => x.id), { index: i, context: { type: 'history', name: 'Recently played' } });
      if (list === 'pls') ctx.nav.go('playlist', { id: pls[i].id });
      if (list === 'radio') startRadio(radioSeeds[i].id);
      if (list === 'rel') ctx.nav.go('ytalbum', { browseId: releases[i].browse_id, title: releases[i].title });
      if (list === 'smart') ctx.nav.go('smart', { id: smart[i].id });
    };
  };
  const yourMix = async () => {
    const likes = db.listLikes({ sort: 'added' });
    if (!likes.length) { toast('Like some songs first'); return; }
    const seed = likes[Math.floor(Math.random() * Math.min(likes.length, 50))];
    startRadio(seed.id);
  };
  draw();
  const offs = [bridge.on('library', () => ctx.alive() && draw()), bridge.on('job', () => ctx.alive() && draw())];
  return () => offs.forEach((f) => f());
}

function matchCard(c, jobs) {
  const m = jobs.match;
  const running = m && (m.state === 'running' || m.state === 'queued' || m.state === 'waiting');
  if (!c.pending && !running && !c.REVIEW) return '';
  const pct = m && m.total > 0 ? Math.round((m.done / m.total) * 100) : 0;
  return `<div class="card"><h3>${running ? 'Matching your songs to YouTube' : 'Songs waiting for a YouTube match'}</h3>
    ${running ? `<div class="progress"><div style="width:${pct}%"></div></div><p class="faint">${esc(m.message || '')}</p>`
      : `<p class="muted">${c.pending} songs not matched yet${c.REVIEW ? `, ${c.REVIEW} need a quick check` : ''}. Matching runs in the background (about 1 song per 1.5 s) and you can keep using the app.</p>
         <div class="row-actions" style="padding:6px 0 0">${c.pending ? '<button class="btn primary small" data-a="match">Match now</button>' : ''}${c.REVIEW ? '<button class="btn small" data-go="review">Review</button>' : ''}</div>`}</div>`;
}

function tile(url, t1, t2, i, fb = 'note', badge = '') {
  const a = art(url, { fallback: fb });
  return `<button class="tile" data-i="${i}">${badge ? a.replace('>', `><span class="badge acc">${esc(badge)}</span>`) : a}<div class="t1">${esc(t1)}</div><div class="t2">${esc(t2 || '')}</div></button>`;
}

/** Weekly Discovery: this week's mix, or a hint while the first one is being built. */
function mixCard(mix, tracks, jobs) {
  const j = jobs.weeklyMix;
  const building = j && (j.state === 'running' || j.state === 'queued' || j.state === 'waiting');
  if (!mix) {
    if (!building && !(j && j.state === 'failed')) return '';
    return `<div class="card"><h3>Weekly Discovery</h3><p class="muted">${building ? 'Finding new music for you…' : 'Could not build the mix: ' + esc(j.message || '')}</p>
      ${building ? '' : '<div class="row-actions" style="padding:6px 0 0"><button class="btn small" data-a="discmake">Try again</button></div>'}</div>`;
  }
  const arts = tracks.filter((t) => t.artwork_url).slice(0, 1);
  return `<button class="mix-card" data-a="disc">${art(arts[0]?.artwork_url, { fallback: 'sparkle' })}
    <div class="meta"><div class="t0">Weekly Discovery${building ? ' · updating…' : ''}</div><div class="t1">${tracks.length} new songs for you</div>
    <div class="t2">${esc(mix.description || '')}${mix.updated_at ? ' · ' + fmtAgo(mix.updated_at) : ''}</div></div>
    <span class="play" data-a="discplay">${icon('play')}</span></button>`;
}

function safe(fn, d) { try { return fn(); } catch { return d; } }
