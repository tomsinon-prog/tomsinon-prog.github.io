// Liked songs, playlists (incl. Weekly Discovery), My Albums and smart playlists: header, offline toggle,
// sort/filter, virtual list, drag & drop reorder.
import { isDesktop, hasEngine } from '../../core/platform.js';
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import * as settings from '../../core/settings.js';
import { icon, art, esc } from '../dom.js';
import { VirtualList, trackRowHtml, letterOf, sheet, prompt, toast } from '../components.js';
import { player } from '../player.js';
import { trackMenu, playCollection, download, confirmDanger, emitLibraryChanged, radio, offlineSync, sharePlaylist } from '../actions.js';
import { fmtTotal, fmtAgo, debounce } from '../../core/util.js';
import { describe } from '../../lib/smart.js';

const SORT_LABELS = { position: 'Custom order', added: 'Recently added', title: 'Title', artist: 'Artist', album: 'Album', duration: 'Duration' };

export function render(el, p, ctx) {
  const kind = p.view; // likes | playlist | myalbum | smart | genre
  const sortKey = `ui.sort.${kind}`;
  let sort = db.kvGet(sortKey) || (kind === 'likes' ? 'added' : 'position');
  if (kind === 'likes' && sort === 'position') sort = 'added';
  let filter = '';
  let chip = 'all'; // predefined filter: all | downloaded | liked | notplayed | live | g:<genre>
  let searching = false;
  let reorder = false;
  let list = null;
  let items = [];
  let smartRows = null; // smart playlists are evaluated once per visit (random order stays stable while filtering)
  let lastCur = player.currentId();

  const meta = () => {
    if (kind === 'likes') return { title: 'Liked songs', sub: null, cover: null, offline: !!settings.get('likesOffline') };
    if (kind === 'playlist') {
      const pl = db.getPlaylist(p.id);
      if (!pl) return null;
      const mix = pl.origin === 'MIX';
      const sub = mix ? `New every Monday · updated ${fmtAgo(pl.updated_at)}${pl.description ? '<br>' + esc(pl.description) : ''}`
        : pl.origin === 'SPOTIFY' ? esc(`From Spotify${pl.spotify_owner ? ' · ' + pl.spotify_owner : ''}`) : null;
      return { title: pl.name, pl, mix, cover: pl.artwork_url, subHtml: sub, offline: !!pl.offline };
    }
    if (kind === 'genre') return { title: p.name, subHtml: 'Genre · songs in your library', cover: null };
    if (kind === 'smart') {
      const sp = db.getSmart(p.id);
      if (!sp) return null;
      const plName = (id) => db.getPlaylist(+id)?.name || 'a deleted playlist';
      return { title: sp.name, sp, subHtml: esc('Smart playlist · ' + describe(sp.spec, plName)), cover: null };
    }
    const a = db.getAlbum(p.id);
    return a ? { title: a.name, subHtml: 'My album', cover: a.artwork_url } : null;
  };

  const load = (m) => {
    const offline = settings.get('offlineMode');
    if (kind === 'likes') return db.listLikes({ sort, filter, offline });
    if (kind === 'playlist') return db.playlistEntries(p.id, { sort, filter, offline });
    if (kind === 'smart') {
      if (!smartRows) smartRows = db.smartTracks(m.sp.spec);
      return filterRows(smartRows, filter, offline);
    }
    if (kind === 'genre') {
      if (!smartRows) { const map = db.genreMap(); smartRows = db.librarySongs().filter((t) => db.genresOf(t, map).includes(p.name)); }
      return filterRows(smartRows, filter, offline);
    }
    return db.albumEntries(p.id, { filter, offline });
  };

  const offlineStatus = (m) => {
    const st = kind === 'likes' ? db.likesOfflineState() : db.playlistOfflineState(p.id);
    if (!m.offline) return kind === 'likes' ? 'Download all liked songs, and new likes automatically' : 'Download these songs, and songs you add later';
    return st.n && st.done >= st.n ? `All ${st.n} songs downloaded · tap to stop` : `${st.done || 0} of ${st.n} downloaded · tap to stop`;
  };

  const draw = () => {
    const m = meta();
    if (!m) { el.innerHTML = '<div class="empty">This list no longer exists.</div>'; return; }
    ctx.setTitle(m.title);
    const all = load(m);
    const chips = filterChips(all);
    if (!chips.some((c) => c.k === chip)) chip = 'all';
    items = applyChip(all, chip);
    const total = items.reduce((s, t) => s + (t.duration_ms || 0), 0);
    const canReorder = (kind === 'playlist' || kind === 'myalbum') && !m.mix && sort === 'position' && !filter && chip === 'all';
    const sorts = kind === 'likes' ? ['added', 'title', 'artist', 'album', 'duration'] : kind === 'playlist' ? ['position', 'added', 'title', 'artist', 'album', 'duration'] : [];
    const coverHtml = kind === 'likes' ? `<div class="art liked">${icon('heart')}</div>`
      : kind === 'smart' ? `<div class="art liked" style="background:linear-gradient(135deg,#7a5cff,#1e9bd6)">${icon('sparkle')}</div>`
        : kind === 'genre' ? `<div class="art liked" style="background:linear-gradient(135deg,#ff9f43,#ee5a6f)">${icon('note')}</div>`
        : m.mix ? `<div class="art liked" style="background:linear-gradient(135deg,#9b8cff,#ff7ab6)">${icon('sparkle')}</div>`
          : art(m.cover || items.find((t) => t.artwork_url)?.artwork_url, { fallback: kind === 'myalbum' ? 'album' : 'queue' });
    el.innerHTML = `<div class="coll-head">${coverHtml}<div><h2>${esc(m.title)}</h2>
        <div class="faint">${items.length} songs · ${fmtTotal(total)}${m.subHtml ? '<br>' + m.subHtml : ''}${settings.get('offlineMode') ? '<br>Offline mode: only available songs' : ''}</div></div></div>
      ${m.pl && !m.pl.importable ? '<div class="banner">Not importable: Spotify only shares songs of playlists you own or collaborate on. Copy it into your own playlist in Spotify first, then sync again.</div>' : ''}
      ${m.pl && m.pl.missing_on_spotify ? '<div class="banner">This playlist is no longer on Spotify. It stays here.</div>' : ''}
      <div class="coll-actions">
        <button class="btn primary" data-a="play">${icon('play')}<span>Play</span></button>
        <button class="btn" data-a="shuffle">${icon('shuffle')}<span>Shuffle</span></button>
        <button class="btn" data-a="smart">${icon('shuffleSmart')}<span>Smart shuffle</span></button>
        <button class="icon-btn" data-a="more" aria-label="More">${icon('more')}</button>
      </div>
      <div class="toolbar">${searching || filter ? `<input type="search" placeholder="Search in this list" value="${esc(filter)}">`
        : sorts.length > 1 ? `<select aria-label="Sort">${sorts.map((s) => `<option value="${s}" ${s === sort ? 'selected' : ''}>${SORT_LABELS[s]}</option>`).join('')}</select>` : '<span style="flex:1"></span>'}
        ${searching || filter ? '' : '<span style="flex:1"></span>'}
        <button class="icon-btn ${searching || filter ? 'on' : ''}" data-a="find" aria-label="Search in this list">${icon(searching || filter ? 'close' : 'search')}</button>
        ${canReorder ? `<button class="icon-btn ${reorder ? 'on' : ''}" data-a="reorder" title="Reorder">${icon('drag')}</button>` : ''}</div>
      ${chips.length > 1 ? `<div class="chips coll-chips">${chips.map((c) => `<button class="chip ${c.k === chip ? 'on' : ''}" data-chip="${esc(c.k)}">${esc(c.label)}${c.n != null ? ` <small>${c.n}</small>` : ''}</button>`).join('')}</div>` : ''}
      <div class="vlist"></div>
      ${items.length ? '' : `<div class="empty">${filter ? 'No matches.' : kind === 'likes' ? 'Tap ♡ on any song to like it, or import your Spotify likes.' : kind === 'smart' ? 'No songs match these rules (yet). Edit the rules with ⋮.' : 'Empty. Add songs from search or any song menu.'}</div>`}`;
    list?.destroy();
    list = new VirtualList(el.querySelector('.vlist'), {
      items,
      renderRow: (t, i) => trackRowHtml(t, i, { current: t.id === player.currentId(), reorder: reorder && canReorder }),
      onTap: (t, i) => playCollection(items.map((x) => x.id), { index: i, context: { type: kind, id: p.id || null, name: m.title } }),
      onMore: (t) => trackMenu(t, kind === 'playlist' ? { entryId: t.entry_id, playlistId: p.id } : kind === 'myalbum' ? { albumEntryId: t.entry_id } : {}),
      letterOf: sort === 'title' && kind !== 'smart' ? (t) => letterOf(t.title) : sort === 'artist' && kind !== 'smart' ? (t) => letterOf(t.artists) : null,
      onMove: reorder && canReorder ? (from, to) => {
        if (kind === 'playlist') db.moveEntry(p.id, items[from].entry_id, to); else db.moveAlbumEntry(p.id, items[from].entry_id, to);
        draw();
      } : null,
    });
    const input = el.querySelector('.toolbar input');
    if (input) {
      input.addEventListener('input', debounce(() => { filter = input.value.trim(); const pos = input.selectionStart; draw(); const i2 = el.querySelector('.toolbar input'); if (i2) { i2.focus(); i2.setSelectionRange(pos, pos); } }, 250));
      if (searching && !filter) setTimeout(() => input.focus(), 50);
    }
    const sel = el.querySelector('.toolbar select');
    if (sel) sel.onchange = () => { sort = sel.value; db.kvSet(sortKey, sort); reorder = false; draw(); };
  };

  const setOffline = async (on) => {
    if (on) {
      if (kind === 'likes') settings.set('likesOffline', true); else db.setPlaylistOffline(p.id, true);
      const n = offlineSync();
      toast(n ? `${n} songs will download${settings.get('downloadWifiOnly') ? ' on Wi-Fi' : ''}` : 'Everything is already downloaded');
      draw();
      return;
    }
    const ids = items.map((t) => t.id);
    const all = kind === 'likes' ? db.listLikes().map((t) => t.id) : db.playlistEntries(p.id).map((t) => t.id);
    const orphans = kind === 'likes' ? db.offlineOrphans(all, {}) : db.offlineOrphans(all.length ? all : ids, { exceptPlaylistId: p.id, likes: !!settings.get('likesOffline') });
    const turnOff = () => { if (kind === 'likes') settings.set('likesOffline', false); else db.setPlaylistOffline(p.id, false); };
    if (!orphans.length) { turnOff(); toast('No longer kept offline'); draw(); return; }
    let decided = false;
    await sheet({ head: { title: 'Stop keeping offline?', sub: `${orphans.length} downloaded songs are not needed by another offline list` }, items: [
      { icon: 'downloaded', label: 'Keep the downloads', sub: 'New songs are no longer downloaded automatically', run: () => { decided = true; turnOff(); toast('Downloads kept'); draw(); } },
      { icon: 'trash', label: `Remove ${orphans.length} downloads`, sub: 'The songs stay in your library and stream again', danger: true, run: () => {
        decided = true;
        turnOff();
        bridge.call('downloads.delete', { trackIds: orphans });
        toast(`${orphans.length} downloads removed`);
        emitLibraryChanged('downloads');
        draw();
      } },
    ] });
    if (!decided) draw(); // sheet dismissed: the switch goes back on
  };

  el.onclick = async (e) => {
    const c = e.target.closest('[data-chip]');
    if (c) { chip = c.dataset.chip; draw(); return; }
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const ids = items.map((x) => x.id);
    const name = meta()?.title;
    switch (b.dataset.a) {
      case 'play': playCollection(ids, { context: { type: kind, id: p.id || null, name } }); break;
      case 'shuffle': playCollection(ids, { shuffle: true, context: { type: kind, id: p.id || null, name } }); break;
      case 'smart': playCollection(ids, { smart: true, context: { type: kind, id: p.id || null, name } }); break;
      case 'reorder': reorder = !reorder; draw(); break;
      case 'find': if (searching || filter) { searching = false; filter = ''; } else searching = true; draw(); break;
      case 'more': moreMenu(ids); break;
      default: break;
    }
  };

  const moreMenu = (ids) => {
    const m = meta();
    const its = [
      ...(hasEngine() ? [{ icon: 'radio', label: kind === 'playlist' ? 'Playlist radio' : 'Radio from these songs', run: () => {
        if (kind === 'playlist') radio({ mode: 'playlist', playlistId: p.id });
        else if (ids.length) radio({ seedTrackId: ids[Math.floor(Math.random() * Math.min(ids.length, 30))], mode: 'track' });
      } }] : []),
      ...(isDesktop() ? [] : kind === 'likes' || kind === 'playlist' ? [{ icon: m.offline ? 'check' : 'downloaded', label: m.offline ? 'Kept offline' : 'Keep offline',
        sub: offlineStatus(m), run: () => setOffline(!m.offline) }] : [{ icon: 'download', label: `Download all (${ids.length})`, run: () => download(ids) }]),
      { icon: 'queue', label: 'Add all to queue', run: () => { player.cmd('enqueue', { trackIds: ids }); toast('Added to queue'); } },
      { icon: 'share', label: 'Share', sub: 'A link that opens this list in TuneLab', run: () => sharePlaylist(m.title, items) },
    ];
    if (m.mix) {
      its.unshift({ icon: 'refresh', label: 'Make a new mix now', sub: 'Replaces this week’s songs (liked ones stay in your likes)', run: () => {
        bridge.call('jobs.start', { job: 'weeklyMix', args: { force: true } });
        toast('Building a new Weekly Discovery…');
      } });
    }
    if (kind === 'smart') {
      its.unshift({ icon: 'edit', label: 'Edit rules', run: () => ctx.nav.go('smartedit', { id: p.id }) });
      its.push({ icon: 'playlistAdd', label: 'Save as a normal playlist', sub: 'A fixed copy of the songs shown now', run: async () => {
        const n = await prompt({ title: 'Playlist name', value: m.title, ok: 'Save' });
        if (!n) return;
        const id = db.createPlaylist(n);
        db.addToPlaylist(id, ids);
        emitLibraryChanged('playlists');
        toast(`Saved “${n}”`);
      } });
    }
    if (kind === 'playlist' || kind === 'myalbum' || kind === 'smart') {
      its.push({ icon: 'edit', label: 'Rename', run: async () => {
        const n = await prompt({ title: 'Rename', value: m.title });
        if (!n) return;
        if (kind === 'playlist') db.renamePlaylist(p.id, n); else if (kind === 'smart') db.updateSmart(p.id, { name: n }); else db.renameAlbum(p.id, n);
        emitLibraryChanged('playlists'); draw();
      } });
      its.push({ icon: 'trash', label: kind === 'myalbum' ? 'Delete album' : 'Delete playlist', danger: true, run: async () => {
        const text = kind === 'smart' ? 'Only the rules are deleted; the songs stay in your library.' : 'The songs stay in your library (likes, other playlists). A backup keeps a copy.';
        if (!(await confirmDanger(`Delete “${m.title}”?`, text))) return;
        if (kind === 'playlist') db.deletePlaylist(p.id); else if (kind === 'smart') db.deleteSmart(p.id); else db.deleteAlbum(p.id);
        emitLibraryChanged('playlists');
        ctx.nav.back();
      } });
    }
    sheet({ head: { title: m.title, sub: `${ids.length} songs` }, items: its });
  };

  draw();
  const offs = [
    bridge.on('library', (e) => { if (!ctx.alive()) return; if ((kind === 'smart' || kind === 'genre') && e?.what !== 'downloads') smartRows = null; draw(); }),
    player.on(() => { const c = player.currentId(); if (c !== lastCur) { lastCur = c; list && list.refresh(); } }),
  ];
  return () => { offs.forEach((f) => f()); list?.destroy(); };
}

function filterRows(rows, filter, offline) {
  let out = rows;
  if (filter) { const f = filter.toLowerCase(); out = out.filter((t) => `${t.title} ${t.artists} ${t.album}`.toLowerCase().includes(f)); }
  if (offline) out = out.filter((t) => t.best_source === 'LOCAL_FILE' || t.best_source === 'DOWNLOADED');
  return out;
}

/** Ready-made filters for a list: offline / liked / not played / live, plus the genres that occur in it. */
function filterChips(rows) {
  const out = [{ k: 'all', label: 'All' }];
  const dl = rows.filter(isOffline).length;
  if (dl && dl < rows.length) out.push({ k: 'downloaded', label: 'Downloaded', n: dl });
  const liked = rows.filter((t) => t.liked).length;
  if (liked && liked < rows.length) out.push({ k: 'liked', label: 'Liked', n: liked });
  const played = playedSet();
  const notPlayed = rows.filter((t) => !played.has(t.id)).length;
  if (notPlayed && notPlayed < rows.length) out.push({ k: 'notplayed', label: 'Not played yet', n: notPlayed });
  const live = rows.filter(isLive).length;
  if (live && live < rows.length) out.push({ k: 'live', label: 'Live', n: live });
  const map = db.genreMap();
  if (map.size) {
    const c = new Map();
    for (const t of rows) for (const g of db.genresOf(t, map)) c.set(g, (c.get(g) || 0) + 1);
    [...c.entries()].filter(([, n]) => n < rows.length || c.size > 1).sort((a, b) => b[1] - a[1]).slice(0, 8)
      .forEach(([g, n]) => out.push({ k: 'g:' + g, label: g, n }));
  }
  return out;
}

function applyChip(rows, chip) {
  if (chip === 'all') return rows;
  if (chip === 'downloaded') return rows.filter(isOffline);
  if (chip === 'liked') return rows.filter((t) => t.liked);
  if (chip === 'notplayed') { const played = playedSet(); return rows.filter((t) => !played.has(t.id)); }
  if (chip === 'live') return rows.filter(isLive);
  if (chip.startsWith('g:')) { const g = chip.slice(2), map = db.genreMap(); return rows.filter((t) => db.genresOf(t, map).includes(g)); }
  return rows;
}

const isOffline = (t) => t.best_source === 'DOWNLOADED' || t.best_source === 'LOCAL_FILE';
const isLive = (t) => /\b(live|unplugged|acoustic session|in concert)\b/i.test(`${t.title} ${t.album || ''}`);
function playedSet() { return new Set(db.q('SELECT DISTINCT track_id FROM play_event WHERE track_id IS NOT NULL AND ms_played>=30000').map((r) => r.track_id)); }
