// "Move library to another phone": the old phone shows a code, the new phone types it. Both on the same Wi-Fi;
// the library goes straight from phone to phone (sealed with the code), nothing through the internet.
import * as bridge from '../../core/bridge.js';
import * as settings from '../../core/settings.js';
import { icon, esc } from '../dom.js';
import { toast } from '../components.js';
import { isDesktop } from '../../core/platform.js';

const ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

/** What the user typed -> "XXXX-XXXX" as far as typed (only valid characters). */
export function formatCode(s) {
  const c = String(s || '').toUpperCase().split('').filter((ch) => ALPHABET.includes(ch)).join('').slice(0, 8);
  return c.length > 4 ? c.slice(0, 4) + '-' + c.slice(4) : c;
}

/** Backup counts -> "1,234 songs · 56 playlists · 789 likes · 12 albums". */
export function describeCounts(c = {}) {
  const n = (v) => Number(v || 0).toLocaleString('en-US');
  const parts = [];
  if (c.track) parts.push(`${n(c.track)} songs`);
  if (c.likes) parts.push(`${n(c.likes)} likes`);
  if (c.playlist) parts.push(`${n(c.playlist)} playlists`);
  if (c.user_album) parts.push(`${n(c.user_album)} albums`);
  return parts.join(' · ') || 'an empty library';
}

export function render(el, p, ctx) {
  const pc = isDesktop(); // Windows: only receiving, by typed address (no phone discovery there)
  ctx.setTitle(pc ? 'Library from the phone' : 'Move library');
  let mode = pc ? 'receive' : 'start'; // start | send | receive
  let send = null; // state from transfer.send / events
  let recv = { state: 'idle', error: '', manual: pc, code: '', address: '', result: null };
  const here = pc ? 'this computer' : 'this phone';
  let tick = null;

  const draw = () => {
    if (mode === 'start') el.innerHTML = startHtml();
    else if (mode === 'send') el.innerHTML = sendHtml();
    else el.innerHTML = receiveHtml();
    if (mode === 'receive' && recv.state === 'idle') {
      const inp = el.querySelector('#tcode');
      if (inp && !recv.code) setTimeout(() => inp.focus(), 50);
    }
  };

  const startHtml = () => `
    <div class="xfer-intro">${icon('phone')}<p>Likes, playlists, albums, history and settings go straight from one phone to the other over your Wi-Fi. Nothing goes through the internet.</p></div>
    <div class="set-card xfer-pick">
      <button class="set-row" data-a="send"><span class="xfer-ic">${icon('share')}</span><div class="meta"><div class="t1">Send from this phone</div><div class="t2">This is the old phone. You get a code.</div></div></button>
      <button class="set-row" data-a="receive"><span class="xfer-ic">${icon('download')}</span><div class="meta"><div class="t1">Receive on this phone</div><div class="t2">This is the new phone. You type the code.</div></div></button>
    </div>
    <p class="faint xfer-note">Downloads and karaoke recordings stay on the old phone. Songs you keep offline download again on the new one.</p>`;

  const sendHtml = () => {
    if (!send) return `<div class="xfer-big"><div class="spinner"></div><p>Preparing your library…</p></div>`;
    const left = Math.max(0, Math.round((send.until - Date.now()) / 60000));
    if (send.state === 'done') {
      return `<div class="xfer-big ok">${icon('check')}<h2>Your library is on the other phone</h2><p class="faint">${esc(describeCounts(send.counts))}</p>
        <button class="btn primary" data-a="close">Done</button></div>`;
    }
    if (send.state === 'expired' || send.state === 'blocked') {
      return `<div class="xfer-big">${icon('timer')}<h2>${send.state === 'expired' ? 'The code expired' : 'Stopped after too many wrong codes'}</h2>
        <button class="btn primary" data-a="send">New code</button></div>`;
    }
    return `<div class="xfer-big">
        <p class="faint">On the new phone: Settings → Move library to another phone → Receive, and type</p>
        <div class="xfer-code" aria-label="Code">${esc(send.code)}</div>
        <p class="xfer-wait">${send.state === 'sending' ? '<span class="spinner small"></span> Sending…' : '<span class="spinner small"></span> Waiting for the other phone'}</p>
        ${send.bad ? `<p class="xfer-warn">${icon('warn')} ${send.bad === 1 ? 'A wrong code was typed' : `A wrong code was typed ${send.bad} times`}</p>` : ''}
        <p class="faint small">${esc(describeCounts(send.counts))} · valid for ${left} min</p>
        ${send.addresses && send.addresses.length ? `<p class="faint small">Not found? Type this address on the new phone: <b>${esc(send.addresses[0])}</b></p>` : ''}
        <button class="btn" data-a="stop">Stop</button>
      </div>`;
  };

  const receiveHtml = () => {
    if (recv.state === 'done') {
      const r = recv.result || {};
      return `<div class="xfer-big ok">${icon('check')}<h2>Welcome back</h2><p>${esc(describeCounts(r.counts))} arrived.</p>
        <p class="faint small">Your previous library on ${here} was saved as a safety backup first.${settings.get('likesOffline') && !pc ? ' Liked songs start downloading now.' : ''}</p>
        <button class="btn primary" data-a="library">Open library</button></div>`;
    }
    const busy = ['searching', 'receiving', 'restoring'].includes(recv.state);
    const label = { searching: 'Looking for the other phone…', receiving: 'Receiving…', restoring: 'Putting everything in place…' }[recv.state];
    return `<div class="xfer-recv">
      ${pc ? '<p class="faint small">On the phone: Settings → Backup → Move library to another phone → Send. Type the code and the address it shows. The phone and this computer must be on the same network.</p>' : ''}
      <label class="faint" for="tcode">${pc ? 'Code from the phone' : 'Code from the old phone'}</label>
      <input id="tcode" class="xfer-input" value="${esc(recv.code)}" placeholder="XXXX-XXXX" maxlength="9" autocomplete="off" autocapitalize="characters" spellcheck="false" ${busy ? 'disabled' : ''}>
      ${recv.manual ? `<label class="faint" for="taddr">${pc ? 'Address shown on the phone' : 'Address shown on the old phone'}</label>
      <input id="taddr" class="xfer-input addr" value="${esc(recv.address)}" placeholder="192.168.1.20:41234" inputmode="decimal" autocomplete="off" ${busy ? 'disabled' : ''}>` : ''}
      <div class="xfer-warnbox">${icon('warn')}<span>This replaces the library on ${here}. A safety backup of it is saved first.</span></div>
      ${recv.error ? `<p class="xfer-err">${esc(recv.error)}</p>` : ''}
      ${busy ? `<p class="xfer-wait"><span class="spinner small"></span> ${esc(label)}</p>`
    : `<button class="btn primary wide" data-a="go" ${formatCode(recv.code).length === 9 && (!pc || recv.address.trim()) ? '' : 'disabled'}>Receive</button>
      ${recv.manual ? '' : '<button class="linkbtn" data-a="manual">Phones don’t find each other? Type the address</button>'}`}
    </div>`;
  };

  const startSend = async () => {
    mode = 'send';
    send = null;
    draw();
    try {
      send = await bridge.callAsync('transfer.send', {});
    } catch (err) {
      mode = 'start';
      toast('Couldn’t prepare the library. Try again.');
      bridge.log('W', 'Transfer', 'send: ' + err.message);
    }
    if (ctx.alive()) draw();
    clearInterval(tick);
    tick = setInterval(() => { if (ctx.alive() && mode === 'send' && send && send.state === 'waiting') draw(); }, 30000);
  };

  const startReceive = async () => {
    recv.error = '';
    recv.state = 'searching';
    draw();
    try {
      const r = await bridge.callAsync('transfer.receive', { code: recv.code, address: recv.manual ? recv.address : '' });
      recv = { ...recv, state: 'done', result: r };
      settings.invalidate();
      bridge.emitLocal('library', { what: 'restore' });
      import('../actions.js').then((m) => m.offlineSync()).catch(() => {});
    } catch (err) {
      recv.state = 'idle';
      recv.error = /code|phone|address|Wi-Fi|reach/i.test(err.message) ? err.message.replace(/\.$/, '') + '.' : 'Something went wrong. Try again.';
      if (/No phone found/.test(err.message)) recv.manual = true;
    }
    if (ctx.alive()) draw();
  };

  el.oninput = (e) => {
    if (e.target.id === 'tcode') {
      const f = formatCode(e.target.value);
      if (f !== e.target.value) e.target.value = f;
      recv.code = f;
      if (recv.error) { recv.error = ''; el.querySelector('.xfer-err')?.remove(); }
    }
    if (e.target.id === 'taddr') recv.address = e.target.value;
    const go = el.querySelector('[data-a="go"]');
    if (go) go.disabled = formatCode(recv.code).length !== 9 || (pc && !recv.address.trim());
  };
  el.onkeydown = (e) => {
    if (e.key === 'Enter' && mode === 'receive' && formatCode(recv.code).length === 9) startReceive();
  };
  el.onclick = (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (!a) return;
    if (a === 'send') return startSend();
    if (a === 'receive') { mode = 'receive'; return draw(); }
    if (a === 'stop' || a === 'close') { bridge.call('transfer.stop'); return ctx.nav.back(); }
    if (a === 'go') return startReceive();
    if (a === 'manual') { recv.manual = true; draw(); setTimeout(() => el.querySelector('#taddr')?.focus(), 50); return; }
    if (a === 'library') return ctx.nav.tab('library');
  };

  const off = bridge.on('transfer', (st) => {
    if (!ctx.alive()) return;
    if (st.side === 'receive') {
      if (mode === 'receive' && ['searching', 'receiving', 'restoring'].includes(recv.state)) { recv.state = st.state; draw(); }
      return;
    }
    if (mode === 'send' && send) { send = { ...send, ...st }; draw(); }
  });
  draw();
  return () => {
    off();
    clearInterval(tick);
    if (mode === 'send' && send && send.state !== 'done') bridge.call('transfer.stop');
  };
}
