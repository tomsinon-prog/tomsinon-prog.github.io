// Downloads tab: storage overview, download list, bulk actions.
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import * as settings from '../../core/settings.js';
import { icon, esc } from '../dom.js';
import { VirtualList, trackRowHtml, toast, sheet } from '../components.js';
import { player } from '../player.js';
import { trackMenu, download, confirmDanger, emitLibraryChanged, offlineSync } from '../actions.js';
import { fmtBytes } from '../../core/util.js';

export function render(el, p, ctx) {
  ctx.setTitle('Downloads');
  let list = null;
  let filterState = 'all';
  let optsOpen = false; // the options are folded away by default
  el.addEventListener('toggle', (e) => { if (e.target.classList?.contains('dl-opts')) optsOpen = e.target.open; }, true);
  const draw = () => {
    const items = db.listDownloads();
    const st = safe(() => bridge.call('cache.stats'), {});
    const job = safe(() => bridge.call('jobs.status'), {}).downloads;
    const done = items.filter((t) => t.state === 'DONE');
    const failed = items.filter((t) => t.state === 'FAILED').length;
    const pending = items.filter((t) => t.state === 'QUEUED' || t.state === 'RUNNING').length;
    const cachePct = st.limitBytes ? Math.min(100, Math.round((st.cacheBytes / st.limitBytes) * 100)) : 0;
    const offlinePls = db.listPlaylists().filter((x) => x.offline);
    const shown = filterState === 'all' ? items : items.filter((t) => (filterState === 'busy' ? t.state === 'QUEUED' || t.state === 'RUNNING' : t.state === 'FAILED'));
    el.innerHTML = `<div class="stats3">
        <div><div class="v">${done.length}</div><div class="l">songs · ${fmtBytes(st.downloadsBytes)}</div></div>
        <div><div class="v">${fmtBytes(st.cacheBytes)}</div><div class="l">cache of ${fmtBytes(st.limitBytes)}</div><div class="progress"><div style="width:${cachePct}%"></div></div></div>
        <div><div class="v">${fmtBytes(st.freeBytes)}</div><div class="l">free on phone</div></div></div>
      ${pending ? `<p class="faint" style="margin:0 16px 8px">${pending} waiting${job && job.message ? ' · ' + esc(job.message) : ''}</p>` : ''}
      <details class="set-card dl-opts"${optsOpen ? ' open' : ''}><summary>Download options<span class="faint">${esc([settings.get('likesOffline') ? 'likes offline' : '', settings.get('downloadWifiOnly') ? 'Wi-Fi only' : '', settings.get('offlineMode') ? 'offline mode' : ''].filter(Boolean).join(' · '))}</span></summary>
        <div class="set-row"><div class="meta"><div class="t1">Keep liked songs offline</div><div class="t2">Downloads all likes, and new likes automatically</div></div>
          <label class="switch"><input type="checkbox" data-s="likesOffline" ${settings.get('likesOffline') ? 'checked' : ''}><span></span></label></div>
        <div class="set-row"><div class="meta"><div class="t1">Download on Wi-Fi only</div></div>
          <label class="switch"><input type="checkbox" data-s="downloadWifiOnly" ${settings.get('downloadWifiOnly') ? 'checked' : ''}><span></span></label></div>
        <div class="set-row"><div class="meta"><div class="t1">Offline mode</div><div class="t2">Only show songs that play without internet</div></div>
          <label class="switch"><input type="checkbox" data-s="offlineMode" ${settings.get('offlineMode') ? 'checked' : ''}><span></span></label></div>
        <button class="set-row" data-go="offlinesets"><div class="meta"><div class="t1">Playlists kept offline</div><div class="t2">${offlinePls.length ? esc(offlinePls.map((x) => x.name).join(', ')) : 'None yet'}</div></div></button>
      </details>
      <div class="chips">
        <button class="chip ${filterState === 'all' ? 'on' : ''}" data-f="all">All ${items.length}</button>
        ${pending ? `<button class="chip ${filterState === 'busy' ? 'on' : ''}" data-f="busy">Waiting ${pending}</button>` : ''}
        ${failed ? `<button class="chip ${filterState === 'failed' ? 'on' : ''}" data-f="failed">Failed ${failed}</button>` : ''}
        ${failed ? '<button class="chip" data-a="retry">Retry failed</button>' : ''}
      </div>
      <div class="vlist"></div>${items.length ? '' : `<div class="empty">${icon('download')}No downloads yet. Use “Download” in any song menu, or “Keep offline” on a playlist.</div>`}`;
    list?.destroy();
    list = new VirtualList(el.querySelector('.vlist'), {
      items: shown,
      renderRow: (t, i) => trackRowHtml(t, i, { sub: t.state === 'FAILED' ? `Failed: ${t.error || ''}` : t.state === 'DONE' ? `${t.artists} · ${fmtBytes(t.size)}` : null, current: t.id === player.currentId() }),
      onTap: (t, i) => player.cmd('playTracks', { trackIds: done.map((x) => x.id), index: Math.max(0, done.findIndex((x) => x.id === t.id)), context: { type: 'downloads', name: 'Downloads' } }),
      onMore: (t) => trackMenu(t),
    });
    el.querySelectorAll('[data-s]').forEach((c) => c.addEventListener('change', () => {
      settings.set(c.dataset.s, c.checked);
      if (c.dataset.s === 'likesOffline') {
        if (c.checked) { const n = offlineSync(); toast(n ? `${n} liked songs will download` : 'All liked songs are already downloaded'); }
        else toast('New likes are no longer downloaded; existing downloads stay');
      }
      emitLibraryChanged('settings');
    }));
  };
  ctx.setActions(`<button class="icon-btn" data-a="more" aria-label="Storage">${icon('more')}</button>`, (e) => { if (e.target.closest('[data-a="more"]')) storageMenu(); });
  el.onclick = async (e) => {
    const go = e.target.closest('[data-go]');
    if (go) { ctx.nav.go(go.dataset.go); return; }
    const f = e.target.closest('[data-f]');
    if (f) { filterState = f.dataset.f; draw(); return; }
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'retry') { bridge.call('downloads.retry'); toast('Retrying'); }
    if (a === 'more') storageMenu();
  };
  const storageMenu = () => {
    sheet({ head: { title: 'Storage' }, items: [
      { icon: 'download', label: 'Download all likes once', sub: 'Without keeping new likes offline', run: () => download(db.listLikes().map((t) => t.id)) },
      { icon: 'trash', label: 'Clear stream cache', sub: 'Downloads are kept', run: () => { bridge.call('cache.clear'); toast('Cache cleared'); draw(); } },
      { icon: 'trash', label: 'Delete all downloads', danger: true, run: async () => {
        if (!(await confirmDanger('Delete all downloads?', 'The songs stay in your library and will stream again.'))) return;
        bridge.call('downloads.delete', { trackIds: db.listDownloads().map((t) => t.id) });
        emitLibraryChanged('downloads');
      } },
    ] });
  };
  draw();
  const offs = [bridge.on('downloads', () => ctx.alive() && draw()), bridge.on('library', () => ctx.alive() && draw()),
    bridge.on('job', (j) => j.job === 'downloads' && ctx.alive() && draw())];
  return () => { offs.forEach((f) => f()); list?.destroy(); };
}

function safe(fn, d) { try { return fn(); } catch { return d; } }
