// "Play in the car": choose the car (or a speaker) among the paired Bluetooth devices; when it connects, TuneLab
// starts playing by itself. Pausing on disconnect is normal Android behaviour ("becoming noisy").
import * as bridge from '../../core/bridge.js';
import * as settings from '../../core/settings.js';
import { icon, esc } from '../dom.js';
import { sheet, toast } from '../components.js';

const START = [['resume', 'Continue where I left off', 'Or shuffle liked songs when there is nothing to continue'], ['liked', 'Shuffle liked songs']];

/** Settings row summary: "Tesla Model 3" / "Tesla, JBL" / "Off". */
export function carSummary(list = settings.get('carDevices') || []) {
  if (!list.length) return 'Off';
  return list.map((d) => d.name).join(', ');
}

export function render(el, p, ctx) {
  ctx.setTitle('Play in the car');
  let info = null;

  const load = () => {
    try { info = bridge.call('car.devices'); } catch (err) { info = { granted: true, devices: [], error: err.message }; }
  };

  const draw = () => {
    const chosen = settings.get('carDevices') || [];
    const isOn = (a) => chosen.some((d) => d.address === a);
    const start = START.find(([k]) => k === settings.get('carStart')) || START[0];
    let body;
    if (!info.granted) {
      body = `<div class="set-card"><div class="set-row"><div class="meta"><div class="t1">Allow Nearby devices</div>
        <div class="t2">TuneLab needs it to see your car and to notice when it connects.</div></div></div></div>
        <div class="car-actions"><button class="btn primary" data-a="perm">Allow</button></div>`;
    } else if (!info.devices.length) {
      body = `<div class="set-card"><div class="set-row"><div class="meta"><div class="t1">No paired Bluetooth devices</div>
        <div class="t2">Pair the phone with the car first (in the car and in Android's Bluetooth settings), then come back here.</div></div></div></div>`;
    } else {
      body = `<div class="set-group"><h3>Start playing when this connects</h3><div class="set-card">${info.devices.map((d) => `
        <div class="set-row"><span class="car-ic">${icon(d.car ? 'car' : 'bluetooth')}</span><div class="meta"><div class="t1">${esc(d.name)}</div>${d.car ? '<div class="t2">Car</div>' : ''}</div>
        <label class="switch"><input type="checkbox" data-dev="${esc(d.address)}" ${isOn(d.address) ? 'checked' : ''}><span></span></label></div>`).join('')}</div></div>
      <div class="set-group"><h3>When it connects</h3><div class="set-card">
        <button class="set-row" data-a="start"><div class="meta"><div class="t1">${esc(start[1])}</div></div><svg class="chev" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2"/></svg></button>
        ${info.background ? `<div class="set-row"><div class="meta"><div class="t1">Starts from the background</div><div class="t2">Allowed</div></div>${icon('check')}</div>`
    : `<button class="set-row" data-a="battery"><div class="meta"><div class="t1">Let TuneLab start by itself</div><div class="t2">Android may block starting from the background. Tap and choose Allow.</div></div><span class="val warn">Needed</span></button>`}
      </div></div>`;
    }
    const sw = (name, title, sub) => `<div class="set-row"><div class="meta"><div class="t1">${esc(title)}</div><div class="t2">${esc(sub)}</div></div>
      <label class="switch"><input type="checkbox" data-s="${name}" ${settings.get(name) ? 'checked' : ''}><span></span></label></div>`;
    const likeGroup = `<div class="set-group"><h3>Like while driving</h3><div class="set-card">
      ${sw('carLikeGesture', 'Press play/pause twice', 'On the steering wheel (or headphones) while a song plays: liked, with a short tick. Twice again removes it.')}
      ${sw('carHeart', 'Show ♥ on the car screen', 'Liked songs get a heart before the title')}
    </div></div>`;
    el.innerHTML = `<p class="faint car-intro">${icon('car')}<span>When your car connects over Bluetooth, TuneLab starts playing. It pauses when the car disconnects. It only starts when the sound really goes to the car, never through the phone speaker.</span></p>
      ${body}
      ${likeGroup}
      <p class="faint car-tip">In the car: make this phone the priority phone and choose it as the media source once. The car's buttons control the app that played last. The Tesla screen has no heart button for phone apps, so liking works with play/pause twice.</p>`;
  };

  el.onchange = (e) => {
    if (e.target.dataset.s) { settings.set(e.target.dataset.s, e.target.checked); return; }
    const a = e.target.dataset.dev;
    if (!a) return;
    const dev = info.devices.find((d) => d.address === a);
    let list = (settings.get('carDevices') || []).filter((d) => d.address !== a);
    if (e.target.checked && dev) list = list.concat({ address: dev.address, name: dev.name });
    settings.set('carDevices', list);
    if (e.target.checked && !info.background) toast('Also tap “Let TuneLab start by itself”', { ms: 5000 });
  };
  el.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'perm') {
      await bridge.callAsync('permission.request', { name: 'android.permission.BLUETOOTH_CONNECT' });
      load();
      if (ctx.alive()) draw();
    }
    if (a === 'battery') bridge.call('battery.allowBackground');
    if (a === 'start') {
      sheet({ head: { title: 'When it connects' }, items: START.map(([k, label, sub]) => ({ icon: settings.get('carStart') === k ? 'check' : 'blank', label, sub, run: () => { settings.set('carStart', k); draw(); } })) });
    }
  };
  // Coming back from Android's dialog: show the new state.
  const onVis = () => { if (document.visibilityState === 'visible' && ctx.alive()) { load(); draw(); } };
  document.addEventListener('visibilitychange', onVis);
  load();
  draw();
  return () => document.removeEventListener('visibilitychange', onVis);
}
