// Diagnostics: app/engine status, "Test YouTube", "Test background", jobs and the in-app log.
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import { icon, esc } from '../dom.js';
import { toast } from '../components.js';
import { player } from '../player.js';
import { engineCall } from '../actions.js';
import { fmtAgo } from '../../core/util.js';

const TEST_QUERY = 'Dire Straits Private Investigations live';

export function render(el, p, ctx) {
  ctx.setTitle('Diagnostics');
  let report = db.kvGetJson('diag.lastTest');
  const draw = () => {
    const info = safe(() => bridge.call('app.info'), {});
    const eng = safe(() => bridge.call('engine.status'), {});
    const net = safe(() => bridge.call('net.state'), {});
    const jobs = safe(() => bridge.call('jobs.status'), {});
    const bg = db.kvGetJson('diag.bgtest');
    const ps = player.state;
    el.innerHTML = `
      <div class="card"><h3>App</h3><div class="kv">
        <b>Version</b><span>${esc(info.version)}</span>${info.platform === 'desktop' ? '<b>System</b><span>Windows</span>' : `<b>Android</b><span>${esc(info.release)} (SDK ${info.sdk})</span>`}<b>Device</b><span>${esc(info.device)}</span>
        <b>Database</b><span>schema v${info.dbVersion}</span><b>Network</b><span>${net.online ? (net.wifi ? 'Wi-Fi' : 'mobile data') : 'offline'}${net.metered ? ' (metered)' : ''}</span>
        <b>Engine</b><span>${eng.ready ? 'ready' : 'not ready'} · ${eng.ok || 0} ok / ${eng.failed || 0} failed / ${eng.timeouts || 0} timeouts · ${eng.restarts || 0} restarts</span>
        ${eng.lastError ? `<b>Last engine error</b><span>${esc(eng.lastError)}</span>` : ''}
        <b>Player</b><span>${esc(ps.status)}${ps.source ? ' · ' + esc(JSON.stringify(ps.source)) : ''}</span>
      </div></div>
      <div class="card"><h3>Test YouTube</h3><p class="muted">Searches “${TEST_QUERY}”, resolves the audio stream and downloads the first 512 KB.</p>
        <div class="row-actions" style="padding:4px 0"><button class="btn primary small" data-a="yt">${icon('play')}Run test</button>${report?.videoId ? '<button class="btn small" data-a="playtest">Play the result</button>' : ''}<button class="btn small" data-a="reset">Reset YouTube session</button></div>
        <div class="ytres">${report ? renderReport(report) : ''}</div></div>
      <div class="card" ${info.platform === 'desktop' ? 'hidden' : ''}><h3>Test background</h3><p class="muted">Checks that stream resolution keeps working with the screen off. Start, turn the screen off for 3 minutes, then come back.</p>
        <div class="row-actions" style="padding:4px 0"><button class="btn small" data-a="bg">Start 3-minute test</button></div>
        ${jobs.bgtest ? `<p class="faint">Status: ${esc(jobs.bgtest.state)} ${jobs.bgtest.done >= 0 ? `${jobs.bgtest.done}/${jobs.bgtest.total}` : ''} · ${esc(jobs.bgtest.message || '')}</p>` : ''}
        ${bg ? `<table class="mini"><tr><th>Time</th><th>Screen</th><th>Result</th><th>ms</th></tr>${bg.rows.map((r) => `<tr><td>${new Date(r.t).toLocaleTimeString()}</td><td>${r.screenOn ? 'on' : '<b>off</b>'}</td><td>${r.ok ? 'OK ' + esc(r.client || '') : '<span style="color:var(--danger)">' + esc(r.error || 'fail') + '</span>'}</td><td>${r.ms}</td></tr>`).join('')}</table>` : ''}</div>
      <div class="card"><h3>Jobs</h3>${Object.entries(jobs).filter(([k]) => !k.startsWith('_')).map(([k, v]) => `<p class="faint">${esc(k)}: ${esc(v.state)} ${v.done >= 0 ? v.done : ''}${v.total > 0 ? '/' + v.total : ''} · ${esc(v.message || '')} · ${fmtAgo(v.at)}</p>`).join('') || '<p class="faint">No jobs yet.</p>'}</div>
      <div class="section"><h2>Log <span><button class="btn small" data-a="copy">${icon('copy')}Copy</button> <button class="btn small" data-a="share">${icon('share')}Share</button> <button class="btn small" data-a="clear">Clear</button></span></h2></div>
      <pre class="log">${esc(safe(() => bridge.call('log.dump', { lines: 400 }), ''))}</pre>`;
  };

  el.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (!a) return;
    if (a === 'yt') { await runYoutubeTest(el, (r) => { report = r; }); draw(); }
    if (a === 'playtest' && report?.videoId) {
      const id = db.ensureYoutubeTrack({ videoId: report.videoId, title: report.title || 'Test', artists: [report.channel || ''], durationMs: report.durationMs || 0, thumb: report.thumb });
      player.cmd('playTracks', { trackIds: [id], index: 0, context: { type: 'diag', name: 'Diagnostics' } });
    }
    if (a === 'reset') { toast('Resetting…'); try { await engineCall('resetClient', {}, 60000); toast('YouTube session recreated'); } catch (err) { toast(err.message); } }
    if (a === 'bg') {
      let vid = report?.videoId;
      if (!vid) {
        toast('Finding a test song…');
        try { const r = await engineCall('diagSearch', { q: TEST_QUERY }, 60000); vid = (r.songs[0] || r.videos[0])?.videoId; } catch (err) { toast(err.message); return; }
      }
      db.run("DELETE FROM kv WHERE key='diag.bgtest'");
      bridge.call('jobs.start', { job: 'bgtest', args: { minutes: 3, everySec: 20, videoId: vid } });
      toast('Started. Turn the screen off now for 3 minutes.', { ms: 6000 });
      setTimeout(draw, 500);
    }
    if (a === 'copy') { bridge.call('clipboard', { text: fullLog() }); toast('Log copied'); }
    if (a === 'share') bridge.call('share', { text: fullLog(), subject: 'TuneLab log' });
    if (a === 'clear') { bridge.call('log.clear'); draw(); }
  };
  draw();
  const off = bridge.on('job', (j) => { if (j.job === 'bgtest' && ctx.alive()) draw(); });
  return off;
}

function fullLog() {
  const info = safe(() => bridge.call('app.info'), {});
  const eng = safe(() => bridge.call('engine.status'), {});
  const rep = db.kvGetJson('diag.lastTest');
  const bg = db.kvGetJson('diag.bgtest');
  return `TuneLab ${info.version} · Android ${info.release} (SDK ${info.sdk}) · ${info.device}\nengine: ${JSON.stringify(eng)}\n`
    + (rep ? `last YouTube test: ${JSON.stringify(rep)}\n` : '') + (bg ? `background test: ${JSON.stringify(bg)}\n` : '')
    + '\n' + bridge.call('log.dump', { lines: 4000 });
}

function renderReport(r) {
  const rows = r.steps.map((s) => `<tr><td>${esc(s.name)}</td><td>${s.ok ? '✓' : '<span style="color:var(--danger)">✗</span>'}</td><td>${s.ms != null ? s.ms + ' ms' : ''}</td><td>${esc(s.detail || '')}</td></tr>`).join('');
  return `<p class="faint">${new Date(r.at).toLocaleString()}</p><table class="mini">${rows}</table>`;
}

async function runYoutubeTest(el, setReport) {
  const box = el.querySelector('.ytres');
  const r = { at: Date.now(), steps: [] };
  const show = () => { box.innerHTML = renderReport(r) + `<p class="faint">${icon('refresh', 'spin')} running…</p>`; };
  show();
  try {
    const t0 = Date.now();
    const s = await engineCall('diagSearch', { q: TEST_QUERY }, 60000);
    r.steps.push({ name: 'Session', ok: true, ms: s.initMs, detail: `client created in ${s.stats.createMs} ms` });
    const pick = s.videos.find((v) => /live/i.test(v.title)) || s.songs[0] || s.videos[0];
    r.steps.push({ name: 'Search', ok: !!pick, ms: s.searchMs, detail: `${s.songs.length} songs, ${s.videos.length} videos${s.errors?.length ? ' · ' + s.errors.join('; ') : ''}` });
    show();
    if (!pick) throw new Error('no results');
    Object.assign(r, { videoId: pick.videoId, title: pick.title, channel: pick.channel || (pick.artists || []).join(', '), durationMs: pick.durationMs, thumb: pick.thumb });
    r.steps.push({ name: 'Picked', ok: true, detail: `${pick.title} (${pick.kind})` });
    const t1 = Date.now();
    const res = await engineCall('resolve', { videoId: pick.videoId, quality: 'high' }, 90000);
    r.steps.push({ name: 'Resolve', ok: true, ms: Date.now() - t1, detail: `${res.client} · itag ${res.itag} · ${res.mime} · ${Math.round(res.bitrate / 1000)} kbps${res.tried?.length ? ' · failed first: ' + res.tried.join(', ') : ''}` });
    show();
    const st = await bridge.callAsync('diag.stream', { url: res.url, headers: res.headers });
    r.steps.push({ name: 'Stream', ok: !!st.ok, ms: st.ms ?? st.ttfbMs, detail: st.ok ? `HTTP ${st.status} · first byte ${st.ttfbMs} ms · ${st.kbps} kbit/s` : `HTTP ${st.status}` });
    r.steps.push({ name: 'Total', ok: !!st.ok, ms: Date.now() - t0 });
  } catch (e) {
    r.steps.push({ name: 'Error', ok: false, detail: e.message });
  }
  db.kvSetJson('diag.lastTest', r);
  bridge.log('I', 'diag', 'YouTube test: ' + JSON.stringify(r.steps));
  setReport(r);
}

function safe(fn, d) { try { return fn(); } catch { return d; } }
