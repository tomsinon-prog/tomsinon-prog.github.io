// YouTube Music album and artist pages.
import * as db from '../../core/db.js';
import { icon, art, esc } from '../dom.js';
import { trackRowHtml, toast } from '../components.js';
import { player } from '../player.js';
import { engineCall, trackMenu, radio, playCollection, shareItem } from '../actions.js';
import { artistTile } from './explore.js';
import { primaryArtist } from '../../core/text.js';
import * as bridge from '../../core/bridge.js';

export async function render(el, p, ctx) {
  const isAlbum = p.view === 'ytalbum';
  ctx.setTitle(isAlbum ? (p.title || 'Album') : (p.name || 'Artist'));
  el.innerHTML = `<div class="empty">${icon('refresh', 'spin')}Loading…</div>`;
  let data;
  try {
    data = isAlbum ? await engineCall('album', { browseId: p.browseId }) : await engineCall('artist', { browseId: p.browseId });
  } catch (e) {
    el.innerHTML = `<div class="banner err">Could not load: ${esc(e.message)}</div>`;
    return;
  }
  if (!ctx.alive()) return;
  const tracks = isAlbum ? data.tracks : data.songs;
  const title = isAlbum ? data.title : data.name;
  ctx.setTitle(title || '');
  const known = isAlbum ? null : db.knownArtistKeys();
  const related = isAlbum ? [] : (data.related || []).map((a) => ({ ...a, isNew: !known.has(primaryArtist(a.title)) }));
  const followBtn = () => (db.isFollowed(title) ? `<button class="btn small follow on" data-a="follow">${icon('check')}<span>Following</span></button>` : `<button class="btn small follow" data-a="follow">${icon('add')}<span>Follow</span></button>`);
  el.innerHTML = `<div class="coll-head">${art(isAlbum ? data.thumb : data.thumb || tracks[0]?.thumb, { fallback: isAlbum ? 'album' : 'artist', round: !isAlbum })}<div><h2>${esc(title)}</h2>
      <div class="faint">${isAlbum ? esc((data.artists || []).join(', ')) + ' · ' : ''}${tracks.length} songs</div>${isAlbum ? '' : followBtn()}</div></div>
    <div class="coll-actions"><button class="btn primary" data-a="play">${icon('play')}<span>Play</span></button><button class="btn" data-a="shuffle">${icon('shuffle')}<span>Shuffle</span></button>
      ${isAlbum ? `<button class="btn" data-a="save">${icon('album')}<span>Save album</span></button>` : `<button class="btn" data-a="radio">${icon('radio')}<span>Artist radio</span></button>`}
      <button class="icon-btn" data-a="share" aria-label="Share">${icon('share')}</button></div>
    ${tracks.map((t, i) => trackRowHtml({ ...t, artists: (t.artists || []).join(', ') || t.channel }, i, { staticRow: true })).join('')}
    ${related.length ? `<div class="section"><h2>Fans also like</h2></div><div class="hscroll">${related.map((a, i) => artistTile(a, i, 'related')).join('')}</div><div style="height:12px"></div>` : ''}`;
  const ids = () => tracks.map((t) => db.ensureYoutubeTrack(t));
  el.onclick = (e) => {
    const b = e.target.closest('[data-a]');
    if (b) {
      if (b.dataset.a === 'play') player.cmd('playTracks', { trackIds: ids(), index: 0, context: { type: p.view, name: title } });
      if (b.dataset.a === 'shuffle') playCollection(ids(), { shuffle: true, context: { type: p.view, name: title } });
      if (b.dataset.a === 'save') { const id = db.createAlbum(title); db.addToAlbum(id, ids()); toast(`Saved “${title}” to My Albums`); }
      if (b.dataset.a === 'radio') radio({ mode: 'artist', artist: title });
      if (b.dataset.a === 'follow') {
        if (db.isFollowed(title)) { db.unfollowArtist(title); toast(`Unfollowed ${title}`); }
        else {
          db.followArtist({ name: title, browseId: p.browseId, thumb: data.thumb || null });
          toast(`Following ${title} · new releases show up on Home`);
          try { bridge.call('jobs.start', { job: 'newReleases' }); } catch { /* ignore */ }
        }
        b.outerHTML = followBtn();
      }
      if (b.dataset.a === 'share') shareItem(isAlbum ? { k: 'a', b: p.browseId, t: title, a: (data.artists || []).join(', ') } : { k: 'r', b: p.browseId, n: title });
      return;
    }
    const rt = e.target.closest('.tile[data-list="related"]');
    if (rt) { const a = related[+rt.dataset.i]; return ctx.nav.go('artist', { browseId: a.browseId, name: a.title }); }
    const r = e.target.closest('.trow');
    if (!r) return;
    const t = tracks[+r.dataset.i];
    if (e.target.closest('.more')) { trackMenu(t); return; }
    player.cmd('playTracks', { trackIds: ids(), index: +r.dataset.i, context: { type: p.view, name: title } });
  };
}
