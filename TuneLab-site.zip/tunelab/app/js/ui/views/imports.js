// Imports: Spotify (Web API + PKCE), CSV, Spotify data package, local files.
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import * as settings from '../../core/settings.js';
import { icon, esc } from '../dom.js';
import { toast, prompt, choose, confirmDialog } from '../components.js';
import { randomString, pkceChallenge, authorizeUrl, exchangeCode } from '../../lib/spotify.js';
import { parseTrackCsv } from '../../lib/csv.js';
import { importTracks, importDataPackage } from '../../lib/importer.js';
import { nativeFetch } from '../../yt/fetch-shim.js';
import { fmtAgo } from '../../core/util.js';
import { emitLibraryChanged } from '../actions.js';

export function render(el, p, ctx) {
  if (p.view === 'csv') return csvView(el, ctx);
  if (p.view === 'datapkg') return dataPkgView(el, ctx);
  if (p.view === 'local') return localView(el, ctx);
  return spotifyView(el, ctx);
}

const OAUTH_PORT = 43821;
export const REDIRECT_URI = `http://127.0.0.1:${OAUTH_PORT}/callback`;

// ------------------------------------------------------------------ Spotify

function spotifyView(el, ctx) {
  ctx.setTitle('Spotify import');
  const draw = () => {
    const tokens = db.kvGetJson('spotify.tokens');
    const me = db.kvGetJson('spotify.me');
    const last = db.kvGetJson('spotify.lastSync');
    const job = safe(() => bridge.call('jobs.status'), {}).spotifySync;
    const running = job && ['running', 'queued', 'waiting'].includes(job.state);
    const pls = db.q("SELECT name, importable, missing_on_spotify, (SELECT COUNT(*) FROM playlist_entry e WHERE e.playlist_id=p.id) n FROM playlist p WHERE origin='SPOTIFY' ORDER BY importable DESC, name");
    el.innerHTML = `
      <div class="card"><h3>1 · Your Spotify app</h3>
        <p class="muted">TuneLab uses your own Spotify Developer app (Development Mode, needs Premium). In the Spotify Developer Dashboard, create an app with <b>Web API</b> and add this exact Redirect URI:</p>
        <div style="display:flex;gap:8px;align-items:center"><code style="flex:1;word-break:break-all">${REDIRECT_URI}</code><button class="btn small" data-a="copyuri">${icon('copy')}Copy</button></div>
        <div class="set-row" style="padding:12px 0 0"><div class="meta"><div class="t1">Client ID</div><div class="t2">${settings.get('spotifyClientId') ? esc(settings.get('spotifyClientId')) : 'not set'}</div></div><button class="btn small" data-a="cid">${settings.get('spotifyClientId') ? 'Change' : 'Enter'}</button></div></div>
      <div class="card"><h3>2 · Connect</h3>
        ${tokens ? `<p>Connected${me ? ` as <b>${esc(me.name)}</b>` : ''}.</p><div class="row-actions" style="padding:0"><button class="btn small" data-a="connect">Reconnect</button><button class="btn small danger" data-a="disconnect">Disconnect</button></div>`
        : `<p class="muted">Opens Spotify in your browser. After you approve, tap “Back to TuneLab”.</p><button class="btn primary" data-a="connect" ${settings.get('spotifyClientId') ? '' : 'disabled'}>Connect Spotify</button>`}</div>
      <div class="card"><h3>3 · Import</h3>
        <p class="muted">Imports Liked Songs (with the date you liked them) and your own and collaborative playlists. Safe to repeat: nothing in TuneLab is deleted when it disappears from Spotify, it is only marked.</p>
        ${running ? `<div class="progress"><div style="width:${job.total > 0 ? Math.round(job.done / job.total * 100) : 5}%"></div></div><p class="faint">${esc(job.message || 'Working…')}</p>` : ''}
        ${last ? `<p class="faint">Last sync ${fmtAgo(last.at)}: ${last.summary.liked} liked songs, ${last.summary.importable} playlists imported, ${last.summary.notImportable} not importable${last.summary.missingLikes ? `, ${last.summary.missingLikes} likes gone on Spotify (kept)` : ''}.</p>` : ''}
        <button class="btn primary" data-a="sync" ${tokens && !running ? '' : 'disabled'}>${running ? 'Importing…' : 'Sync now'}</button></div>
      ${pls.length ? `<div class="section"><h2>Spotify playlists <small>${pls.length}</small></h2></div>${pls.map((pl) => `<div class="set-row"><div class="meta"><div class="t1">${esc(pl.name)}</div><div class="t2">${pl.importable ? `${pl.n} songs` : 'Not importable: copy it into your own playlist in Spotify first'}${pl.missing_on_spotify ? ' · gone on Spotify' : ''}</div></div></div>`).join('')}` : ''}`;
  };
  el.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'copyuri') { bridge.call('clipboard', { text: REDIRECT_URI }); toast('Copied'); }
    if (a === 'cid') { const v = await prompt({ title: 'Spotify Client ID', value: settings.get('spotifyClientId'), placeholder: '32 characters' }); if (v) { settings.set('spotifyClientId', v.trim()); draw(); } }
    if (a === 'connect') connect();
    if (a === 'disconnect') { if (await confirmDialog({ title: 'Disconnect Spotify?', text: 'Your imported library stays in TuneLab.', ok: 'Disconnect' })) { db.run("DELETE FROM kv WHERE key IN ('spotify.tokens','spotify.me','spotify.pkce')"); draw(); } }
    if (a === 'sync') { bridge.call('jobs.start', { job: 'spotifySync' }); toast('Import started in the background'); setTimeout(draw, 300); }
  };
  const connect = async () => {
    const clientId = settings.get('spotifyClientId');
    const verifier = randomString(64);
    const state = randomString(16);
    db.kvSetJson('spotify.pkce', { verifier, state, at: Date.now() });
    try {
      const r = bridge.call('oauth.start', { port: OAUTH_PORT, state });
      const url = authorizeUrl({ clientId, redirectUri: r.redirectUri, state, challenge: await pkceChallenge(verifier) });
      bridge.call('openUrl', { url });
    } catch (err) { toast('Could not start login: ' + err.message, { ms: 6000 }); }
  };
  draw();
  const offs = [
    bridge.on('spotify', () => ctx.alive() && draw()),
    bridge.on('job', (j) => j.job === 'spotifySync' && ctx.alive() && draw()),
  ];
  return () => offs.forEach((f) => f());
}

export async function finishOAuth(r) {
  const pk = db.kvGetJson('spotify.pkce');
  if (!r || !r.code) { toast('Spotify login cancelled or failed: ' + (r?.error || 'no code'), { ms: 6000 }); return; }
  if (!pk || pk.state !== r.state) { toast('Spotify login: state mismatch, please try again', { ms: 6000 }); return; }
  try {
    const tokens = await exchangeCode(nativeFetch, { clientId: settings.get('spotifyClientId'), code: r.code, redirectUri: r.redirectUri || REDIRECT_URI, verifier: pk.verifier });
    db.kvSetJson('spotify.tokens', tokens);
    db.run("DELETE FROM kv WHERE key='spotify.pkce'");
    const me = await (await nativeFetch('https://api.spotify.com/v1/me', { headers: { Authorization: `Bearer ${tokens.access}` } })).json();
    db.kvSetJson('spotify.me', { id: me.id, name: me.display_name || me.id });
    toast(`Connected as ${me.display_name || me.id}. Tap “Sync now”.`, { ms: 5000 });
  } catch (e) {
    toast('Spotify: ' + e.message, { ms: 7000 });
  }
}

// ------------------------------------------------------------------ CSV

function csvView(el, ctx) {
  ctx.setTitle('Import CSV');
  el.innerHTML = `<div class="card"><p class="muted">Supports exports from <b>Exportify</b> (one CSV per playlist) and <b>TuneMyMusic</b> (playlist name per row), and most other CSVs with title/artist columns.</p>
    <button class="btn primary" data-a="pick">${icon('folder')}Choose CSV file</button></div><div class="out"></div>`;
  el.onclick = async (e) => {
    if (e.target.closest('[data-a="pick"]')) {
      const f = await bridge.callAsync('pick.file', { mimes: ['text/csv', 'text/comma-separated-values', 'text/plain', 'application/vnd.ms-excel', 'application/octet-stream'] });
      if (!f) return;
      const out = el.querySelector('.out');
      out.innerHTML = '<div class="empty">Reading…</div>';
      try {
        const text = await bridge.callAsync('file.readText', { uri: f.uri });
        const parsed = parseTrackCsv(text);
        const groups = new Map();
        for (const t of parsed.tracks) {
          const k = t.playlist || '';
          if (!groups.has(k)) groups.set(k, []);
          groups.get(k).push(t);
        }
        const baseName = (f.name || 'Imported').replace(/\.csv$/i, '');
        out.innerHTML = `<div class="card"><p><b>${parsed.tracks.length}</b> songs (${esc(parsed.format)}${parsed.skipped ? `, ${parsed.skipped} rows skipped` : ''}).</p>
          ${[...groups.entries()].map(([k, v]) => `<p class="faint">${esc(k || baseName)}: ${v.length}</p>`).join('')}
          <div class="row-actions" style="padding:6px 0 0"><button class="btn primary" data-a="import">Import</button></div></div>`;
        out.querySelector('[data-a="import"]').onclick = async () => {
          let target = 'auto';
          if (groups.size === 1 && !/liked/i.test([...groups.keys()][0] || baseName)) {
            target = await choose({ title: 'Import into', options: [{ label: `New playlist “${[...groups.keys()][0] || baseName}”`, value: 'playlist' }, { label: 'Liked songs', value: 'likes' }] });
            if (!target) return;
          }
          const res = importTracks(groups, baseName, target);
          out.innerHTML = `<div class="card"><p>Imported ${res.tracks} songs into ${res.lists} list(s).</p><p class="muted">Matching to YouTube runs in the background.</p></div>`;
          if (settings.get('autoMatch')) bridge.call('jobs.start', { job: 'match' });
          emitLibraryChanged('import');
        };
      } catch (err) {
        out.innerHTML = `<div class="banner err">${esc(err.message)}</div>`;
      }
    }
  };
}

// ------------------------------------------------------------------ Spotify data package

function dataPkgView(el, ctx) {
  ctx.setTitle('Spotify data package');
  el.innerHTML = `<div class="card"><p class="muted">Request it at spotify.com → Account → Privacy → “Download your data” (account data and/or <b>extended streaming history</b>). Choose the ZIP file, or the unzipped folder.</p>
    <p class="faint">Only song, artist, album, time played, skip and shuffle are stored. IP address, country, device and other network data are ignored.</p>
    <div class="row-actions" style="padding:6px 0 0"><button class="btn primary" data-a="zip">${icon('folder')}Choose ZIP</button><button class="btn" data-a="folder">${icon('folder')}Choose folder</button></div></div><div class="out"></div>`;
  const out = el.querySelector('.out');
  const log = (html) => { out.innerHTML = `<div class="card">${html}</div>`; };
  el.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a !== 'zip' && a !== 'folder') return;
    let reader;
    if (a === 'zip') {
      const f = await bridge.callAsync('pick.file', { mimes: ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'] });
      if (!f) return;
      log('Reading the package…');
      const listing = await bridge.callAsync('file.readZip', { uri: f.uri, match: '^$', limit: 0 });
      const names = listing.names.filter((n) => /\.json$/i.test(n));
      reader = { names, read: async (name) => { const r = await bridge.callAsync('file.readZip', { uri: f.uri, match: '(^|/)' + escapeRe(name) + '$', limit: 1 }); return r.entries[0]?.text; } };
    } else {
      const t = await bridge.callAsync('pick.tree', { purpose: 'datapkg' });
      if (!t) return;
      log('Scanning the folder…');
      const files = await bridge.callAsync('tree.list', { treeUri: t.uri, match: '\\.json$' });
      const byName = new Map(files.map((x) => [x.path, x.uri]));
      reader = { names: [...byName.keys()], read: (name) => bridge.callAsync('file.readText', { uri: byName.get(name) }) };
    }
    try {
      const res = await importDataPackage(reader, (msg) => log(esc(msg)));
      log(`<h3>Done</h3><div class="kv"><b>Play events</b><span>${res.events} new (${res.dupes} already known)</span><b>Songs created</b><span>${res.newTracks}</span>
        <b>Likes</b><span>${res.likes}</span><b>Playlists</b><span>${res.playlists}</span><b>Fields seen</b><span>${esc(res.fields.join(', '))}</span></div>
        <div class="row-actions" style="padding:10px 0 0"><button class="btn primary small" data-go="stats">Stats</button><button class="btn small" data-go="lostlikes">Possibly lost likes</button></div>`);
      out.onclick = (ev) => { const g = ev.target.closest('[data-go]'); if (g) ctx.nav.go(g.dataset.go); };
      emitLibraryChanged('datapkg');
      if (settings.get('autoMatch')) bridge.call('jobs.start', { job: 'match' });
    } catch (err) {
      log(`<div class="banner err">${esc(err.message)}</div>`);
    }
  };
}

function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

// ------------------------------------------------------------------ local files

function localView(el, ctx) {
  ctx.setTitle('Local music');
  const draw = () => {
    const trees = settings.get('localTrees') || [];
    const last = db.kvGetJson('local.lastScan');
    const n = db.scalar("SELECT COUNT(DISTINCT track_id) FROM track_source WHERE kind='LOCAL_FILE' AND broken=0") || 0;
    el.innerHTML = `<div class="card"><p>${n} local songs in your library.</p>${last ? `<p class="faint">Last scan: ${last.found} files, ${last.added} new, ${last.linked} linked to existing songs, ${last.missing} missing.</p>` : ''}
        <p class="faint">Plays whatever your phone can decode: MP3, FLAC, WAV, AAC/M4A, OGG/Opus. Local files always win over streaming.</p>
        <button class="btn primary" data-a="scan">${icon('refresh')}Scan now</button></div>
      <div class="set-row"><div class="meta"><div class="t1">Phone music library (MediaStore)</div><div class="t2">Needs the “Music and audio” permission</div></div>
        <label class="switch"><input type="checkbox" data-s="localMediaStore" ${settings.get('localMediaStore') ? 'checked' : ''}><span></span></label></div>
      <div class="section"><h2>Folders <button class="btn small" data-a="add">${icon('add')}Add folder</button></h2></div>
      ${trees.map((t, i) => `<div class="set-row"><div class="meta"><div class="t1">${esc(t.name)}</div></div><button class="icon-btn" data-rm="${i}">${icon('close')}</button></div>`).join('') || '<p class="faint" style="padding:0 16px">No folders added.</p>'}`;
  };
  el.onchange = (e) => { if (e.target.dataset.s) settings.set(e.target.dataset.s, e.target.checked); };
  el.onclick = async (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    const rm = e.target.closest('[data-rm]');
    if (rm) { const t = [...settings.get('localTrees')]; t.splice(+rm.dataset.rm, 1); settings.set('localTrees', t); draw(); return; }
    if (a === 'add') {
      const t = await bridge.callAsync('pick.tree', { purpose: 'music' });
      if (t) { settings.set('localTrees', [...(settings.get('localTrees') || []), { uri: t.uri, name: t.name }]); draw(); }
    }
    if (a === 'scan') {
      let ms = settings.get('localMediaStore');
      if (ms && !bridge.call('permission.has', { name: 'android.permission.READ_MEDIA_AUDIO' })) {
        ms = await bridge.callAsync('permission.request', { name: 'android.permission.READ_MEDIA_AUDIO' });
        if (!ms) toast('Without the permission only the folders are scanned');
      }
      toast('Scanning…');
      try {
        const r = await bridge.callAsync('local.scan', { mediaStore: !!ms, trees: (settings.get('localTrees') || []).map((t) => t.uri) });
        toast(`Found ${r.found} files: ${r.added} new, ${r.linked} linked`);
        emitLibraryChanged('local');
      } catch (err) { toast('Scan failed: ' + err.message); }
      draw();
    }
  };
  draw();
}

function safe(fn, d) { try { return fn(); } catch { return d; } }
