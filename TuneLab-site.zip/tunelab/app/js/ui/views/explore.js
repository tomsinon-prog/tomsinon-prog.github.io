// Discovering music you don't have yet (0.10): YouTube Music's genres & moods, a genre page (its playlists, its
// artists, your own songs in it, genre radio), YouTube Music playlists, artists like yours, charts, followed artists.
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import { icon, art, esc } from '../dom.js';
import { trackRowHtml, toast } from '../components.js';
import { player } from '../player.js';
import { engineCall, radio, playCollection, emitLibraryChanged } from '../actions.js';
import { mainGenres } from '../../lib/genres.js';
import { fmtTotal } from '../../core/util.js';

const HOUR = 3600000, DAY = 24 * HOUR;
const inflight = new Map();
const attempted = new Map(); // key -> time of the last try (also failed ones: no retry loop)

/** kv cache of engine results; refreshed in the background when older than maxAge (at most every 10 min). */
function cached(key, maxAge, method, args, onFresh) {
  const v = db.kvGetJson(key);
  const stale = !v || Date.now() - (v.at || 0) > maxAge;
  const online = (() => { try { return bridge.call('net.state').online !== false; } catch { return true; } })();
  if (stale && online && !inflight.has(key) && Date.now() - (attempted.get(key) || 0) > 10 * 60000) {
    attempted.set(key, Date.now());
    const p = engineCall(method, args, 120000)
      .then((r) => { if (r) db.kvSetJson(key, { ...r, at: r.at || Date.now() }); onFresh?.(); })
      .catch((e) => bridge.log('W', 'explore', `${method}: ${e.message}`))
      .finally(() => inflight.delete(key));
    inflight.set(key, p);
  }
  return v;
}

export const artistTile = (a, i, list, sub = '') => `<button class="tile artist-tile" data-list="${list}" data-i="${i}">${art(a.thumb, { fallback: 'artist', round: true }).replace('>', a.isNew ? '><span class="badge acc">NEW</span>' : '>')}<div class="t1">${esc(a.title)}</div><div class="t2">${esc(sub)}</div></button>`;
const playlistTile = (pl, i, list) => `<button class="tile" data-list="${list}" data-i="${i}">${art(pl.thumb, { fallback: 'queue' })}<div class="t1">${esc(pl.title)}</div><div class="t2">${esc((pl.artists || []).join(', ') || (pl.kind === 'album' ? 'Album' : 'Playlist'))}</div></button>`;

/**
 * Search's start screen below "Your genres": artists for you, charts, and all of YouTube Music's genres and moods.
 * Returns {html, lists} (lists: data behind the tiles, for the click handler) and calls onFresh when new data came in.
 */
export function exploreStart({ chart = 'NL', onFresh }) {
  const lists = {};
  let html = '';
  const hasTaste = (db.countLikes() || 0) + (db.scalar('SELECT COUNT(*) FROM play_event WHERE ms_played>=30000') || 0) >= 3;
  const forYou = hasTaste ? cached('explore.forYou', DAY, 'artistsForYou', {}, onFresh) : null;
  if (forYou?.artists?.length) {
    lists.foryou = forYou.artists;
    html += `<div class="section"><h2>Artists for you</h2></div><div class="hscroll">${forYou.artists.map((a, i) => artistTile(a, i, 'foryou', a.because?.length ? `Like ${a.because[0]}` : '')).join('')}</div>`;
  }
  const ch = cached('explore.charts.' + chart, DAY, 'charts', { country: chart }, onFresh);
  if (ch?.artists?.length || inflight.has('explore.charts.' + chart)) {
    lists.chart = ch?.artists || [];
    html += `<div class="section"><h2>Top artists <span class="chips small inline"><button class="chip ${chart === 'NL' ? 'on' : ''}" data-chart="NL">Netherlands</button><button class="chip ${chart === 'ZZ' ? 'on' : ''}" data-chart="ZZ">World</button></span></h2></div>
      <div class="hscroll">${(ch?.artists || []).map((a, i) => artistTile(a, i, 'chart', `#${i + 1}`)).join('') || `<div class="faint" style="padding:20px 0">${icon('refresh', 'spin')} Loading…</div>`}</div>`;
  }
  const g = cached('explore.genres', 7 * DAY, 'exploreGenres', {}, onFresh);
  for (const sec of g?.sections || []) {
    const key = 'g' + Object.keys(lists).length;
    lists[key] = sec.buttons;
    const title = /genre/i.test(sec.title) ? 'Browse all genres' : sec.title;
    html += `<div class="section"><h2>${esc(title)}</h2></div><div class="genre-grid">${sec.buttons.map((b, i) => `<button class="genre-tile g${(i + 2) % 6}" data-list="${key}" data-i="${i}"><b>${esc(b.title)}</b></button>`).join('')}</div>`;
  }
  if (!g && inflight.has('explore.genres')) html += `<div class="faint" style="padding:12px 16px">${icon('refresh', 'spin')} Loading genres…</div>`;
  return { html, lists };
}

/** YouTube Music genre names -> the library's own genre ("Dutch" -> Nederlandstalig, "R&B & soul" -> R&B / Soul). */
export const libraryGenreFor = (title) => mainGenres([{ name: title, count: 1 }])[0] || null;

export function genreMatches(q) {
  const v = db.kvGetJson('explore.genres');
  const want = q.toLowerCase();
  return (v?.sections || []).flatMap((s) => s.buttons).filter((b) => b.title.toLowerCase().startsWith(want) || (want.length >= 3 && b.title.toLowerCase().includes(want)));
}

// ------------------------------------------------------------------ views

export async function render(el, p, ctx) {
  if (p.view === 'ytgenre') return genreView(el, p, ctx);
  if (p.view === 'ytplaylist') return playlistView(el, p, ctx);
  if (p.view === 'following') return followingView(el, p, ctx);
}

async function genreView(el, p, ctx) {
  ctx.setTitle(p.title || 'Genre');
  const libGenre = libraryGenreFor(p.title || '');
  const mine = libGenre ? (db.libraryGenres().find((g) => g.genre === libGenre)?.n || 0) : 0;
  const head = `<div class="coll-head"><div class="art liked" style="background:linear-gradient(135deg,#ff9f43,#ee5a6f)">${icon('note')}</div>
      <div><h2>${esc(p.title || 'Genre')}</h2><div class="faint">From YouTube Music</div></div></div>
    <div class="coll-actions"><button class="btn primary" data-a="radio">${icon('radio')}<span>Genre radio</span></button></div>
    ${mine ? `<button class="set-row" data-a="mine"><div class="art liked" style="width:46px;height:46px;border-radius:8px">${icon('heart')}</div><div class="meta"><div class="t1">Your songs in ${esc(libGenre)}</div><div class="t2">${mine} songs in your library</div></div></button>` : ''}`;
  el.innerHTML = head + `<div class="empty">${icon('refresh', 'spin')}Loading…</div>`;
  let data;
  const key = 'explore.genre.' + p.params;
  const c = db.kvGetJson(key);
  try {
    data = c && Date.now() - c.at < DAY ? c : await engineCall('genrePage', { params: p.params }, 90000);
    if (data !== c) db.kvSetJson(key, { ...data, at: Date.now() });
  } catch (e) {
    bridge.log('W', 'explore', 'genre page: ' + e.message);
    if (!ctx.alive()) return;
    el.innerHTML = head + `<div class="empty">${icon('warn')}This genre didn't load. Try again later.</div>`;
    bindGenre();
    return;
  }
  if (!ctx.alive()) return;
  const lists = { artists: data.artists || [] };
  el.innerHTML = head
    + (lists.artists.length ? `<div class="section"><h2>Artists</h2></div><div class="hscroll">${lists.artists.map((a, i) => artistTile(a, i, 'artists')).join('')}</div>` : '')
    + (data.shelves || []).map((sh, s) => { lists['s' + s] = sh.items; return `<div class="section"><h2>${esc(sh.title || 'Playlists')}</h2></div><div class="hscroll">${sh.items.map((pl, i) => playlistTile(pl, i, 's' + s)).join('')}</div>`; }).join('')
    + '<div style="height:12px"></div>';
  bindGenre(lists);

  function bindGenre(l = {}) {
    el.onclick = (e) => {
      const a = e.target.closest('[data-a]')?.dataset.a;
      if (a === 'radio') return radio({ mode: 'genre', params: p.params, name: p.title });
      if (a === 'mine') return ctx.nav.go('genre', { name: libGenre });
      const t = e.target.closest('.tile');
      if (!t) return;
      const it = l[t.dataset.list]?.[+t.dataset.i];
      if (!it) return;
      if (it.kind === 'artist') ctx.nav.go('artist', { browseId: it.browseId, name: it.title });
      else if (it.kind === 'album') ctx.nav.go('ytalbum', { browseId: it.browseId, title: it.title });
      else ctx.nav.go('ytplaylist', { id: it.browseId, title: it.title });
    };
  }
}

async function playlistView(el, p, ctx) {
  ctx.setTitle(p.title || 'Playlist');
  el.innerHTML = `<div class="empty">${icon('refresh', 'spin')}Loading…</div>`;
  let pl;
  try { pl = await engineCall('ytPlaylist', { id: p.id }, 60000); } catch (e) {
    bridge.log('W', 'explore', 'playlist: ' + e.message);
    if (ctx.alive()) el.innerHTML = `<div class="empty">${icon('warn')}This playlist didn't load. Try again later.</div>`;
    return;
  }
  if (!ctx.alive()) return;
  const rows = pl.tracks;
  const total = rows.reduce((n, r) => n + (r.durationMs || 0), 0);
  ctx.setTitle(pl.title || p.title || 'Playlist');
  el.innerHTML = `<div class="coll-head">${art(pl.thumb, { fallback: 'queue' })}<div><h2>${esc(pl.title || p.title || 'Playlist')}</h2><div class="faint">${esc(pl.author || 'YouTube Music')}<br>${rows.length} songs · ${fmtTotal(total)}</div></div></div>
    <div class="coll-actions"><button class="btn primary" data-a="play">${icon('play')}<span>Play</span></button>
      <button class="btn" data-a="shuffle">${icon('shuffle')}<span>Shuffle</span></button>
      <button class="btn" data-a="save">${icon('playlistAdd')}<span>Save playlist</span></button></div>
    ${rows.map((r, i) => trackRowHtml({ ...r, artists: (r.artists || []).join(', ') || r.channel }, i, { staticRow: true })).join('')}`;
  el.querySelectorAll('.trow .more').forEach((b) => b.remove());
  let ids = null;
  const toLibrary = () => ids || (ids = rows.map((r) => db.ensureYoutubeTrack(r)));
  const name = pl.title || p.title || 'Playlist';
  el.onclick = (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'play') return player.cmd('playTracks', { trackIds: toLibrary(), index: 0, context: { type: 'ytplaylist', name } });
    if (a === 'shuffle') return playCollection(toLibrary(), { shuffle: true, context: { type: 'ytplaylist', name } });
    if (a === 'save') {
      const id = db.createPlaylist(name);
      db.addToPlaylist(id, toLibrary());
      emitLibraryChanged('playlists');
      toast(`Saved “${name}” to your playlists`);
      return;
    }
    const r = e.target.closest('.trow');
    if (r) player.cmd('playTracks', { trackIds: toLibrary(), index: +r.dataset.i, context: { type: 'ytplaylist', name } });
  };
}

function followingView(el, p, ctx) {
  ctx.setTitle('Following');
  const draw = () => {
    const list = db.listFollowed();
    el.innerHTML = list.length
      ? `<p class="faint" style="margin:0 16px 8px">New albums and singles of these artists show up in New releases.</p>${list.map((a, i) => `<div class="set-row follow-row" data-i="${i}">${art(a.thumb, { fallback: 'artist', round: true })}<div class="meta"><div class="t1">${esc(a.name)}</div></div><button class="btn small" data-unfollow="${i}">Following</button></div>`).join('')}`
      : `<div class="empty">${icon('artist')}No artists followed yet.<br><span class="faint">Open an artist and tap Follow.</span></div>`;
    el.onclick = (e) => {
      const u = e.target.closest('[data-unfollow]');
      if (u) { const a = list[+u.dataset.unfollow]; db.unfollowArtist(a.name); toast(`Unfollowed ${a.name}`); return draw(); }
      const r = e.target.closest('.follow-row');
      if (r) { const a = list[+r.dataset.i]; if (a.browse_id) ctx.nav.go('artist', { browseId: a.browse_id, name: a.name }); }
    };
  };
  draw();
}
