// New releases (albums, singles, EPs) from the artists you listen to most, found on their YouTube Music pages.
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import { icon, art, esc } from '../dom.js';
import { sheet, toast } from '../components.js';
import { fmtAgo } from '../../core/util.js';

export function render(el, p, ctx) {
  ctx.setTitle('New releases');
  const draw = () => {
    const items = db.listReleases({ limit: 200 });
    const st = db.kvGetJson('releases.state', {}) || {};
    const n = db.scalar('SELECT COUNT(*) FROM artist_follow WHERE score>0 AND muted=0') || 0;
    const checked = db.scalar('SELECT COUNT(*) FROM artist_follow WHERE score>0 AND muted=0 AND checked_at IS NOT NULL') || 0;
    const job = safe(() => bridge.call('jobs.status'), {}).newReleases;
    const running = job && (job.state === 'running' || job.state === 'queued');
    el.innerHTML = `<div class="card"><p class="muted" style="margin:0">New albums and singles from the ${n} artists you play and like most. A few artists are checked each day${st.checkedAt ? ` (last check ${fmtAgo(st.checkedAt)})` : ''}; ${checked} of ${n} checked so far.</p>
        <div class="row-actions" style="padding:10px 0 0"><button class="btn small" data-a="check" ${running ? 'disabled' : ''}>${icon('refresh', running ? 'spin' : '')}${running ? esc(job.message || 'Checking…') : 'Check now'}</button></div></div>
      ${items.map((r, i) => `<div class="trow static" data-i="${i}">${art(r.thumb, { fallback: 'album' })}<div class="meta"><div class="t1">${esc(r.title)}</div>
        <div class="t2">${r.baseline ? '' : '<span class="badge acc">NEW</span>'}<span class="badge">${esc(r.kind.toUpperCase())}</span><span>${esc(r.artist)}${r.year ? ' · ' + r.year : ''}</span></div></div>
        <button class="icon-btn more" data-m="${i}">${icon('more')}</button></div>`).join('')
        || `<div class="empty">${icon('album')}Nothing new yet. New releases show up here as soon as your artists publish them.</div>`}`;
    el.onclick = (e) => {
      if (e.target.closest('[data-a="check"]')) { bridge.call('jobs.start', { job: 'newReleases', args: { force: true, maxArtists: 25 } }); toast('Checking your artists…'); setTimeout(draw, 300); return; }
      const m = e.target.closest('[data-m]');
      if (m) { menu(items[+m.dataset.m]); return; }
      const row = e.target.closest('.trow');
      if (row) open(items[+row.dataset.i]);
    };
  };
  const open = (r) => ctx.nav.go('ytalbum', { browseId: r.browse_id, title: r.title });
  const menu = (r) => sheet({ head: { title: r.title, sub: r.artist, art: r.thumb }, items: [
    { icon: 'album', label: 'Open', run: () => open(r) },
    { icon: 'close', label: 'Hide this release', run: () => { db.dismissRelease(r.browse_id); draw(); } },
    { icon: 'close', label: `Stop checking ${r.artist}`, danger: true, run: () => { db.run('UPDATE artist_follow SET muted=1 WHERE key=?', [r.artist_key]); db.run('UPDATE artist_release SET dismissed=1 WHERE artist_key=?', [r.artist_key]); toast(`${r.artist} is no longer checked`); draw(); } },
  ] });
  draw();
  const offs = [bridge.on('job', (j) => j.job === 'newReleases' && ctx.alive() && draw()), bridge.on('library', () => ctx.alive() && draw())];
  return () => offs.forEach((f) => f());
}

function safe(fn, d) { try { return fn(); } catch { return d; } }
