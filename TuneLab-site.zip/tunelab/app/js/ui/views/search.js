import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import { icon, esc } from '../dom.js';
import { trackRowHtml, toast } from '../components.js';
import { player } from '../player.js';
import { engineCall, trackMenu, playCollection } from '../actions.js';
import { debounce } from '../../core/util.js';
import { exploreStart, genreMatches } from './explore.js';
import { isDesktop, hasEngine } from '../../core/platform.js';

const state = { q: '', filter: 'all', lib: null, yt: null, error: null, loading: false, seq: 0, chart: 'NL' };
const FILTERS = [['all', 'All'], ['songs', 'Songs'], ['videos', 'Videos'], ['albums', 'Albums'], ['artists', 'Artists'], ['library', 'Library']];

export function render(el, p, ctx) {
  ctx.setTitle('Search');
  const eng = hasEngine();
  el.innerHTML = `<div class="searchbar">${icon('search')}<input type="search" enterkeyhint="search" placeholder="${eng ? 'Songs, live versions, artists…' : 'Search your library'}" value="${esc(state.q)}">
      <button class="icon-btn clear ${state.q ? '' : 'hidden'}">${icon('close')}</button></div>
    <div class="chips" ${eng ? '' : 'hidden'}>${FILTERS.map(([k, l]) => `<button class="chip ${state.filter === k ? 'on' : ''}" data-f="${k}">${l}</button>`).join('')}</div>
    <div class="results"></div>`;
  const input = el.querySelector('input');
  const res = el.querySelector('.results');
  const clear = el.querySelector('.clear');
  let rows = [];
  let exLists = {}, ytGenres = [];

  const withStatus = (items) => {
    const st = db.youtubeStatus(items.map((x) => x.videoId));
    return items.map((x) => {
      const s = st.get(x.videoId);
      if (!s) return x;
      return { ...x, liked: s.liked, best_source: s.dl === 'DONE' ? 'DOWNLOADED' : undefined, state: s.dl && s.dl !== 'DONE' ? s.dl : undefined, progress: s.progress };
    });
  };
  const draw = () => {
    rows = [];
    const add = (title, items, kind) => {
      if (!items || !items.length) return '';
      const start = rows.length;
      rows.push(...items.map((x) => ({ ...x, _kind: kind })));
      return `<div class="section"><h2>${title}</h2></div>` + items.map((x, i) => trackRowHtml(x.kind === 'artist' ? { ...x, title: x.title, artists: 'Artist' } : x.kind === 'album' ? { ...x, artists: `Album · ${(x.artists || []).join(', ')}${x.year ? ' · ' + x.year : ''}` } : { ...x, artists: Array.isArray(x.artists) ? (x.artists.join(', ') || x.channel) : (x.artists || x.channel) }, start + i, { staticRow: true })).join('');
    };
    if (!state.q) {
      const genres = safeGenres();
      const ex = eng ? exploreStart({ chart: state.chart, onFresh: () => { if (ctx.alive() && !state.q) draw(); } }) : { html: '', lists: {} };
      exLists = ex.lists;
      res.innerHTML = (genres.length ? `<div class="section"><h2>Your genres</h2></div><div class="genre-grid">${genres.slice(0, 12).map((g, i) => `<button class="genre-tile g${i % 6}" data-genre="${esc(g.genre)}"><b>${esc(g.genre)}</b><small>${g.n} songs</small></button>`).join('')}</div>` : '')
        + ex.html
        + (ex.html ? '' : !eng ? `<div class="empty">${icon('search')}Search your likes, playlists and albums.</div>` : `<div class="empty">${icon('search')}Search YouTube Music and YouTube.<br><span class="faint">Try “Dire Straits Private Investigations live”${genres.length ? ', or a genre like “' + esc(genres[0].genre.toLowerCase()) + '”' : ''}.</span></div>`);
      return;
    }
    const f = state.filter;
    let html = '';
    // a genre name finds that genre in your library
    const gq = state.q.toLowerCase();
    const gm = (f === 'all' || f === 'library') ? safeGenres().filter((g) => g.genre.toLowerCase().startsWith(gq) || (gq.length >= 3 && g.genre.toLowerCase().includes(gq))) : [];
    ytGenres = (f === 'all' || f === 'artists') ? genreMatches(state.q).slice(0, 3) : [];
    if (gm.length || ytGenres.length) {
      html += `<div class="section"><h2>Genres</h2></div>${gm.slice(0, 3).map((g) => `<button class="set-row" data-genre="${esc(g.genre)}"><div class="art liked" style="width:46px;height:46px;border-radius:8px;background:linear-gradient(135deg,#ff9f43,#ee5a6f)">${icon('note')}</div><div class="meta"><div class="t1">${esc(g.genre)}</div><div class="t2">${g.n} songs in your library</div></div></button>`).join('')}`
        + ytGenres.map((b, i) => `<button class="set-row" data-ytg="${i}"><div class="art liked" style="width:46px;height:46px;border-radius:8px;background:linear-gradient(135deg,#2e86de,#4834d4)">${icon('note')}</div><div class="meta"><div class="t1">${esc(b.title)}</div><div class="t2">Browse playlists and artists on YouTube Music</div></div></button>`).join('');
    }
    if ((f === 'all' || f === 'library') && state.lib) {
      html += add('In your library', state.lib.tracks.slice(0, f === 'all' && eng ? 5 : 50), 'lib');
      if (state.lib.playlists.length) html += add('Playlists', state.lib.playlists.map((pl) => ({ ...pl, title: pl.name, artists: 'Playlist', kind: 'playlist' })), 'pl');
    }
    if (state.yt) {
      if (f === 'all' || f === 'songs') html += add('Songs', withStatus(state.yt.songs.slice(0, f === 'all' ? 6 : 30)), 'yt');
      if (f === 'all' || f === 'videos') html += add('Videos · live, covers, sessions', withStatus(state.yt.videos.slice(0, f === 'all' ? 6 : 30)), 'yt');
      if (f === 'all' || f === 'albums') html += add('Albums', state.yt.albums, 'album');
      if (f === 'all' || f === 'artists') html += add('Artists', state.yt.artists, 'artist');
    }
    if (state.loading) html += `<div class="empty">${icon('refresh', 'spin')}Searching YouTube…</div>`;
    if (state.error) html += `<div class="banner err">${esc(state.error)} <button class="btn small" data-retry>Retry</button></div>`;
    if (!html) html = '<div class="empty">No results.</div>';
    res.innerHTML = html;
  };

  const run = async (q) => {
    state.q = q.trim();
    clear.classList.toggle('hidden', !state.q);
    if (!state.q) { state.lib = state.yt = state.error = null; draw(); return; }
    const seq = ++state.seq;
    state.lib = db.searchLibrary(state.q, 50);
    state.error = null; state.yt = null;
    if (!eng) { state.loading = false; draw(); return; } // browser version: your library only
    state.loading = true;
    draw();
    try {
      const r = await engineCall('search', { q: state.q, limit: 30 }, 30000);
      if (seq !== state.seq) return;
      state.yt = r;
      if (r.errors?.length) console.warn('partial search errors', r.errors);
    } catch (e) {
      if (seq !== state.seq) return;
      state.error = 'YouTube search failed: ' + e.message;
    }
    state.loading = false;
    if (ctx.alive()) draw();
  };
  const debounced = debounce((v) => { if (v.trim().length >= 3 && v.trim() !== state.q) run(v); }, 600);
  input.addEventListener('input', () => debounced(input.value));
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { input.blur(); run(input.value); } });
  clear.onclick = () => { input.value = ''; run(''); input.focus(); };
  el.querySelector('.chips').onclick = (e) => {
    const c = e.target.closest('.chip');
    if (!c) return;
    state.filter = c.dataset.f;
    el.querySelectorAll('.chip').forEach((x) => x.classList.toggle('on', x === c));
    draw();
  };
  res.onclick = (e) => {
    if (e.target.closest('[data-retry]')) return run(state.q);
    const gb = e.target.closest('[data-genre]');
    if (gb) return ctx.nav.go('genre', { name: gb.dataset.genre });
    const yg = e.target.closest('[data-ytg]');
    if (yg) { const b = ytGenres[+yg.dataset.ytg]; return ctx.nav.go('ytgenre', { title: b.title, params: b.params }); }
    const chartBtn = e.target.closest('[data-chart]');
    if (chartBtn) { state.chart = chartBtn.dataset.chart; return draw(); }
    const tile = e.target.closest('[data-list]');
    if (tile && exLists[tile.dataset.list]) {
      const it = exLists[tile.dataset.list][+tile.dataset.i];
      if (!it) return;
      if (tile.dataset.list === 'foryou' || tile.dataset.list === 'chart') return ctx.nav.go('artist', { browseId: it.browseId, name: it.title });
      return ctx.nav.go('ytgenre', { title: it.title, params: it.params });
    }
    const row = e.target.closest('.trow');
    if (!row) return;
    const it = rows[+row.dataset.i];
    if (e.target.closest('.more')) {
      if (it._kind === 'yt' || it._kind === 'lib') trackMenu(it._kind === 'lib' ? it : it);
      return;
    }
    if (it._kind === 'lib') {
      const libTracks = state.lib.tracks;
      playCollection(libTracks.map((t) => t.id), { index: libTracks.indexOf(it), context: { type: 'search', name: `Search “${state.q}”` } });
    } else if (it._kind === 'pl') ctx.nav.go('playlist', { id: it.id });
    else if (it._kind === 'album') ctx.nav.go('ytalbum', { browseId: it.browseId, title: it.title });
    else if (it._kind === 'artist') ctx.nav.go('artist', { browseId: it.browseId, name: it.title });
    else {
      const id = db.ensureYoutubeTrack(it);
      player.cmd('playTracks', { trackIds: [id], index: 0, context: { type: 'search', name: `Search “${state.q}”` } });
      toast(`Playing ${it.title}`, { ms: 1500 });
    }
  };
  draw();
  if (isDesktop() && !state.q) setTimeout(() => input.focus(), 120); // phones: no keyboard over the genres
  const offs = [bridge.on('library', () => ctx.alive() && draw()), bridge.on('downloads', () => ctx.alive() && draw())];
  return () => offs.forEach((f) => f());
}

let genreCache = null, genreAt = 0;
/** Library genres, cached for a minute (counting runs over the whole library). */
function safeGenres() {
  if (genreCache && Date.now() - genreAt < 60000) return genreCache;
  try { genreCache = db.libraryGenres(); } catch { genreCache = []; }
  genreAt = Date.now();
  return genreCache;
}
