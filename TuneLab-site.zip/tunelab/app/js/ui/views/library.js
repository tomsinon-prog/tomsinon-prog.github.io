// Library overview + History, Needs review, Possibly lost likes, Stats.
import { isDesktop, hasEngine } from '../../core/platform.js';
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import { icon, art, esc } from '../dom.js';
import { VirtualList, trackRowHtml, prompt, sheet, toast } from '../components.js';
import { player } from '../player.js';
import { trackMenu, playCollection, chooseSource, engineCall, emitLibraryChanged } from '../actions.js';
import { fmtAgo, fmtTotal, fmtDur } from '../../core/util.js';

export function render(el, p, ctx) {
  switch (p.view) {
    case 'history': return history(el, p, ctx);
    case 'review': return review(el, p, ctx);
    case 'lostlikes': return lostLikes(el, p, ctx);
    case 'stats': return stats(el, p, ctx);
    default: return overview(el, p, ctx);
  }
}

function row(iconName, title, sub, attrs, artHtml = null) {
  return `<button class="set-row" ${attrs}>${artHtml || `<div class="art" style="width:48px;height:48px;border-radius:8px">${icon(iconName)}</div>`}<div class="meta"><div class="t1">${esc(title)}</div>${sub ? `<div class="t2">${esc(sub)}</div>` : ''}</div></button>`;
}

function overview(el, p, ctx) {
  ctx.setTitle('Library');
  const draw = () => {
    const pls = db.listPlaylists();
    const albums = db.listAlbums();
    const smart = db.listSmart();
    const rel = db.listReleases({ limit: 200 });
    const relNew = rel.filter((r) => !r.baseline).length;
    const counts = db.matchCounts();
    const lost = db.possiblyLostLikes(5).length;
    const plays = db.scalar('SELECT COUNT(*) FROM play_event') || 0;
    const missing = db.scalar('SELECT COUNT(*) FROM likes l JOIN track t ON t.id=l.track_id WHERE t.missing_on_spotify=1') || 0;
    el.innerHTML = `
      ${row('heart', 'Liked songs', `${db.countLikes()} songs${missing ? ` · ${missing} gone on Spotify (kept here)` : ''}`, 'data-go="likes"', `<div class="art liked" style="width:48px;height:48px;border-radius:8px">${icon('heart')}</div>`)}
      ${row('history', 'History', `${plays} plays`, 'data-go="history"')}
      ${row('stats', 'Stats', 'Top songs and artists per year', 'data-go="stats"')}
      ${(() => { const n = db.listFollowed().length; return n ? row('artist', 'Following', `${n} artists · their new releases come to Home`, 'data-go="following"') : ''; })()}
      ${!hasEngine() ? '' : row('album', 'New releases', rel.length ? `${rel.length} from artists you listen to${relNew ? ` · ${relNew} new` : ''}` : 'New albums and singles from your artists', 'data-go="releases"')}
      ${isDesktop() ? '' : row('lyrics', 'Karaoke recordings', `${db.scalar('SELECT COUNT(*) FROM recording') || 0} recordings · sing via a song's ⋮ menu`, 'data-go="recordings"')}
      ${counts.REVIEW || counts.FAILED ? row('warn', 'Needs review', `${counts.REVIEW} to check · ${counts.FAILED} not found`, 'data-go="review"') : ''}
      ${lost ? row('heartO', 'Possibly lost likes', `${lost} songs you played often but are not liked`, 'data-go="lostlikes"') : ''}
      <div class="section"><h2>Playlists <small>${pls.length}</small><button class="btn small" data-a="newpl">${icon('add')}New</button></h2></div>
      ${pls.map((pl) => row('queue', pl.name, `${pl.n} songs${pl.origin === 'MIX' ? ' · new every Monday' : ''}${pl.offline ? ' · offline' : ''}${pl.origin === 'SPOTIFY' ? ' · Spotify' : ''}${!pl.importable ? ' · not importable' : ''}${pl.missing_on_spotify ? ' · gone on Spotify' : ''}`, `data-pl="${pl.id}"`, art(pl.cover || pl.artwork_url, { fallback: 'queue' }).replace('class="art ', 'style="width:48px;height:48px;border-radius:8px" class="art '))).join('') || '<p class="faint" style="padding:0 16px">No playlists yet.</p>'}
      <div class="section"><h2>Smart playlists <small>${smart.length}</small><button class="btn small" data-go="smartnew">${icon('add')}New</button></h2></div>
      ${smart.map((sp) => row('sparkle', sp.name, 'Updates itself from your rules', `data-sp="${sp.id}"`, `<div class="art liked" style="width:48px;height:48px;border-radius:8px;background:linear-gradient(135deg,#7a5cff,#1e9bd6)">${icon('sparkle')}</div>`)).join('') || '<p class="faint" style="padding:0 16px">Playlists that fill themselves, e.g. “Forgotten favourites” or “On repeat”.</p>'}
      <div class="section"><h2>My Albums <small>${albums.length}</small><button class="btn small" data-a="newal">${icon('add')}New</button></h2></div>
      ${albums.map((a) => row('album', a.name, `${a.n} songs`, `data-al="${a.id}"`, art(a.cover, { fallback: 'album' }).replace('class="art ', 'style="width:48px;height:48px;border-radius:8px" class="art '))).join('') || '<p class="faint" style="padding:0 16px">Collect songs into your own albums from any song menu.</p>'}
      <div class="section"><h2>Import</h2></div>
      ${row('download', 'Spotify', 'Liked songs and your playlists', 'data-go="spotify"')}
      ${row('lyrics', 'CSV file', 'Exportify or TuneMyMusic export', 'data-go="csv"')}
      ${row('history', 'Spotify data package', 'Streaming history, library, playlists (ZIP or folder)', 'data-go="datapkg"')}
      ${row('folder', 'Local files', 'Music on this phone', 'data-go="local"')}
      <div style="height:12px"></div>`;
  };
  el.onclick = async (e) => {
    const t = e.target.closest('[data-go],[data-pl],[data-al],[data-sp],[data-a]');
    if (!t) return;
    if (t.dataset.go) return ctx.nav.go(t.dataset.go);
    if (t.dataset.sp) return ctx.nav.go('smart', { id: +t.dataset.sp });
    if (t.dataset.pl) return ctx.nav.go('playlist', { id: +t.dataset.pl });
    if (t.dataset.al) return ctx.nav.go('myalbum', { id: +t.dataset.al });
    if (t.dataset.a === 'newpl') { const n = await prompt({ title: 'New playlist', placeholder: 'Name', ok: 'Create' }); if (n) { const id = db.createPlaylist(n); ctx.nav.go('playlist', { id }); } }
    if (t.dataset.a === 'newal') { const n = await prompt({ title: 'New album', placeholder: 'Name', ok: 'Create' }); if (n) { const id = db.createAlbum(n); ctx.nav.go('myalbum', { id }); } }
  };
  draw();
  const off = bridge.on('library', () => ctx.alive() && draw());
  return off;
}

function history(el, p, ctx) {
  ctx.setTitle('History');
  const items = db.historyEvents({ limit: 2000 });
  el.innerHTML = `<div class="faint" style="padding:0 16px 8px">${items.length} most recent plays (app and Spotify imports)</div><div class="vlist"></div>${items.length ? '' : '<div class="empty">Nothing played yet.</div>'}`;
  const list = new VirtualList(el.querySelector('.vlist'), {
    items,
    renderRow: (t, i) => trackRowHtml({ ...t, liked: 0 }, i, { sub: `${t.artists || ''} · ${fmtAgo(t.ts)} · ${fmtDur(t.ms_played)}${t.origin === 'SPOTIFY_IMPORT' ? ' · Spotify' : ''}${t.skipped ? ' · skipped' : ''}` }),
    onTap: (t) => { if (t.track_id) player.cmd('playTracks', { trackIds: [t.track_id], index: 0, context: { type: 'history', name: 'History' } }); },
    onMore: (t) => { if (t.track_id) trackMenu({ id: t.track_id, title: t.title, artists: t.artists, artwork_url: t.artwork_url }); },
  });
  return () => list.destroy();
}

function review(el, p, ctx) {
  ctx.setTitle('Needs review');
  let list = null;
  const draw = () => {
    const items = db.reviewList();
    const c = db.matchCounts();
    el.innerHTML = `<div class="card"><p class="muted" style="margin:0">Songs where the YouTube match is uncertain (<b>CHECK</b>) or nothing was found (<b>NO MATCH</b>). Tap a song to pick the right version; your choice is remembered.</p>
      <div class="row-actions" style="padding:10px 0 0"><button class="btn small" data-a="retry">Retry not found (${c.FAILED})</button><button class="btn small" data-a="acceptall">Accept all CHECK (${c.REVIEW})</button></div></div><div class="vlist"></div>
      ${items.length ? '' : '<div class="empty">Nothing to review. 🎉</div>'}`;
    list?.destroy();
    list = new VirtualList(el.querySelector('.vlist'), {
      items,
      renderRow: (t, i) => trackRowHtml(t, i, { sub: `${t.artists} · ${t.match_state === 'REVIEW' ? `match ${Math.round((t.match_score || 0) * 100)}%` : 'not found'}` }),
      onTap: (t) => chooseSource(t.id),
      onMore: (t) => sheet({ head: { title: t.title, sub: t.artists }, items: [
        { icon: 'play', label: 'Play current match', run: () => player.cmd('playTracks', { trackIds: [t.id], index: 0 }) },
        { icon: 'check', label: 'Accept current match', run: () => { db.acceptMatch(t.id); draw(); } },
        { icon: 'swap', label: 'Choose another source', run: () => chooseSource(t.id) },
        { icon: 'refresh', label: 'Match again', run: async () => { toast('Matching…'); try { const r = await engineCall('matchOne', { trackId: t.id, force: true }); toast(`Result: ${r.state}`); } catch (e) { toast(e.message); } draw(); } },
      ] }),
    });
  };
  el.onclick = (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'retry') { db.retryFailedMatches(); bridge.call('jobs.start', { job: 'match' }); toast('Matching again in the background'); draw(); }
    if (a === 'acceptall') { db.run("UPDATE track SET match_state='MANUAL' WHERE match_state='REVIEW' AND EXISTS(SELECT 1 FROM track_source s WHERE s.track_id=track.id AND s.kind='YOUTUBE')"); draw(); }
  };
  draw();
  const off = bridge.on('library', () => ctx.alive() && draw());
  return () => { off(); list?.destroy(); };
}

function lostLikes(el, p, ctx) {
  ctx.setTitle('Possibly lost likes');
  const items = db.possiblyLostLikes(5);
  const sel = new Set();
  const draw = () => {
    el.innerHTML = `<div class="card"><p class="muted" style="margin:0">Songs you played at least 5 times (over 30 s each) that are not in your likes. Spotify may have dropped them. Select and like them in one go.</p>
      <div class="row-actions" style="padding:10px 0 0"><button class="btn small primary" data-a="likesel" ${sel.size ? '' : 'disabled'}>Like selected (${sel.size})</button><button class="btn small" data-a="likeall">Like all ${items.length}</button><button class="btn small" data-a="selall">${sel.size === items.length ? 'Select none' : 'Select all'}</button></div></div><div class="vlist"></div>
      ${items.length ? '' : '<div class="empty">No candidates. Import your Spotify data package (Library → Import) to find them.</div>'}`;
    new VirtualList(el.querySelector('.vlist'), {
      items,
      renderRow: (t, i) => trackRowHtml(t, i, { sub: `${sel.has(t.id) ? '✓ selected · ' : ''}${t.artists} · ${t.plays} plays` }).replace('class="trow', `class="trow${sel.has(t.id) ? ' current' : ''}`),
      onTap: (t) => { if (sel.has(t.id)) sel.delete(t.id); else sel.add(t.id); draw(); },
      onMore: (t) => trackMenu(t),
    });
  };
  el.onclick = (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'likesel') { db.likeMany([...sel]); toast(`Liked ${sel.size} songs`); emitLibraryChanged('likes'); ctx.nav.back(); }
    if (a === 'likeall') { db.likeMany(items.map((t) => t.id)); toast(`Liked ${items.length} songs`); emitLibraryChanged('likes'); ctx.nav.back(); }
    if (a === 'selall') { if (sel.size === items.length) sel.clear(); else items.forEach((t) => sel.add(t.id)); draw(); }
  };
  draw();
}

function stats(el, p, ctx) {
  ctx.setTitle('Stats');
  let year = null;
  const draw = () => {
    const s = db.stats({ year });
    el.innerHTML = `<div class="chips"><button class="chip ${year == null ? 'on' : ''}" data-y="">All time</button>${s.years.map((y) => `<button class="chip ${y.year === year ? 'on' : ''}" data-y="${y.year}">${y.year}</button>`).join('')}</div>
      <div class="card"><div class="kv"><b>Plays (≥ 30 s)</b><span>${s.totals.plays}</span><b>Listening time</b><span>${fmtTotal(s.totals.ms)}</span><b>Different songs</b><span>${s.totals.tracks}</span></div></div>
      <div class="section"><h2>Top songs</h2></div>
      ${s.topTracks.map((t, i) => trackRowHtml({ ...t, liked: 0 }, i, { staticRow: true, sub: `${i + 1}. ${t.artists || ''} · ${t.plays} plays` })).join('') || '<p class="faint" style="padding:0 16px">No plays yet.</p>'}
      <div class="section"><h2>Top artists</h2></div>
      <table class="mini" style="margin:0 16px;width:calc(100% - 32px)">${s.topArtists.map((a, i) => `<tr><td>${i + 1}</td><td>${esc(a.artist || '?')}</td><td style="text-align:right">${a.plays}</td><td style="text-align:right" class="faint">${fmtTotal(a.ms)}</td></tr>`).join('')}</table>
      <div style="height:16px"></div>`;
    el.querySelectorAll('.trow').forEach((r) => r.querySelector('.more')?.remove());
  };
  el.onclick = (e) => {
    const c = e.target.closest('[data-y]');
    if (c) { year = c.dataset.y ? +c.dataset.y : null; draw(); return; }
    const r = e.target.closest('.trow');
    if (r) {
      const s = db.stats({ year });
      const t = s.topTracks[+r.dataset.i];
      if (t?.track_id) player.cmd('playTracks', { trackIds: [t.track_id], index: 0 });
    }
  };
  draw();
}
