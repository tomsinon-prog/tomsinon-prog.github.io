// A playlist someone shared with you (from a TuneLab link): listen right away, or save it as your own playlist.
import * as db from '../../core/db.js';
import { icon, esc } from '../dom.js';
import { trackRowHtml, toast } from '../components.js';
import { player } from '../player.js';
import { emitLibraryChanged } from '../actions.js';
import { fmtTotal } from '../../core/util.js';

export function render(el, p, ctx) {
  const item = p.item || { n: 'Shared playlist', s: [] };
  ctx.setTitle(item.n);
  const rows = item.s.map(([v, t, a, d]) => ({ videoId: v, title: t, artists: a, durationMs: d, kind: 'song', thumb: `https://i.ytimg.com/vi/${v}/mqdefault.jpg` }));
  let ids = null;
  const toLibrary = () => ids || (ids = rows.map((r) => db.ensureYoutubeTrack({ ...r, artists: r.artists ? [r.artists] : [], channel: r.artists })));
  const total = rows.reduce((n, r) => n + (r.durationMs || 0), 0);
  el.innerHTML = `<div class="coll-head"><div class="art liked" style="background:linear-gradient(135deg,#2e86de,#9b8cff)">${icon('share')}</div>
      <div><h2>${esc(item.n)}</h2><div class="faint">${rows.length} songs · ${fmtTotal(total)}<br>Shared with you</div></div></div>
    <div class="coll-actions"><button class="btn primary" data-a="play">${icon('play')}<span>Play</span></button>
      <button class="btn" data-a="shuffle">${icon('shuffle')}<span>Shuffle</span></button>
      <button class="btn" data-a="save">${icon('playlistAdd')}<span>Save playlist</span></button></div>
    ${rows.map((r, i) => trackRowHtml(r, i, { staticRow: true })).join('')}`;
  el.querySelectorAll('.trow .more').forEach((b) => b.remove());
  const play = (index, shuffle = false) => player.cmd('playTracks', { trackIds: toLibrary(), index, shuffle, context: { type: 'shared', name: item.n } });
  el.onclick = (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'play') return play(0);
    if (a === 'shuffle') return play(Math.floor(Math.random() * rows.length), true);
    if (a === 'save') {
      const id = db.createPlaylist(item.n);
      db.addToPlaylist(id, toLibrary());
      emitLibraryChanged('playlists');
      toast(`Saved “${item.n}” to your playlists`);
      return;
    }
    const r = e.target.closest('.trow');
    if (r) play(+r.dataset.i);
  };
}
