// Karaoke screen: prepare -> ready (backing, key, sync, effects) -> sing (lyrics + pitch lane + live score)
// -> review (mix, score, save, duet). Plus the list of saved recordings.
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import { icon, art, esc } from '../dom.js';
import { toast, sheet, confirmDialog } from '../components.js';
import { player } from '../player.js';
import { KaraokeSession } from '../../karaoke/session.js';
import { midiName, pcDistance } from '../../lib/karaoke-dsp.js';
import { VOICE_PRESETS, PRESET_ORDER } from '../../karaoke/effects.js';
import { MixPlayer } from '../../karaoke/mix-player.js';
import { fmtDur, fmtAgo } from '../../core/util.js';

// What the user sees while a song gets ready: one friendly line and one progress bar (details go to the log).
const PHASES = { lyrics: ['Finding the lyrics', 0.05], original: ['Getting the song', 0.35], melody: ['Learning the melody', 0.2],
  backing: ['Getting the karaoke version', 0.3], sync: ['Syncing the lyrics', 0.05], key: ['Changing the key', 0.05] };

export function render(el, p, ctx) {
  if (p.view === 'recordings') return recordings(el, ctx);
  const track = db.getTrack(p.trackId);
  if (!track) { el.innerHTML = '<div class="empty">Song not found.</div>'; return; }
  ctx.setTitle('Karaoke');
  try { if (player.state.playWhenReady) player.cmd('pause'); } catch { /* ignore */ }
  const s = new KaraokeSession(track);
  let phase = 'prep', monitor = false, lastRaw = null, raf = 0, saved = false, leaving = false, curT = 0;
  document.body.classList.add('kara-open'); // no mini player here: music is paused and the screen needs the room
  ctx.setBackHandler(() => {
    if (phase === 'sing') { s.stopSinging(); return true; } // Back while singing = stop and review the take
    if (phase === 'review' && !saved && !leaving && s.takes.length) {
      confirmDialog({ title: 'Leave without saving?', text: 'Your take is not saved yet.', ok: 'Leave', danger: true }).then((yes) => { if (yes) { leaving = true; ctx.nav.back(); } });
      return true;
    }
    return false;
  });
  const steps = {};
  let player2 = null, ticker = 0;

  const head = () => `<div class="coll-head">${art(track.artwork_url)}<div><h2>${esc(track.title)}</h2><div class="faint">${esc(track.artists)}</div></div></div>`;

  const progress = () => {
    let done = 0, label = 'Getting ready';
    for (const [k, st] of Object.entries(steps)) {
      const w = PHASES[k]?.[1] || 0;
      if (st.state === 'run') { label = PHASES[k]?.[0] || label; const m = /(\d+)%/.exec(st.detail || ''); done += w * (m ? +m[1] / 100 : 0.1); }
      else done += w;
    }
    return { pct: Math.min(97, Math.round(done * 100)), label };
  };
  const drawPrep = (err) => {
    if (err) {
      el.innerHTML = head() + `<div class="card kara-prep"><h3>Couldn't get this song ready</h3><p class="muted">${esc(friendly(err))}</p>
        <div class="row-actions" style="padding:8px 0 0"><button class="btn primary" data-a="retry">${icon('refresh')}Try again</button></div></div>`;
      return;
    }
    if (!el.querySelector('.kara-prep .progress')) {
      el.innerHTML = head() + `<div class="card kara-prep"><h3 class="lbl">Getting ready…</h3><div class="progress"><div></div></div>
        <p class="faint">The first time takes a little longer. After that this song starts right away.</p></div>`;
    }
    const pr = progress();
    el.querySelector('.kara-prep .lbl').textContent = pr.label + '…';
    el.querySelector('.kara-prep .progress > div').style.width = pr.pct + '%';
  };
  const step = (k, state, detail) => {
    steps[k] = { state, detail };
    if (state !== 'run') bridge.log(state === 'ok' ? 'I' : 'W', 'karaoke', `${k}: ${state}${detail ? ' · ' + detail : ''}`);
    if (phase === 'prep' && ctx.alive()) drawPrep();
  };

  const prepare = async () => {
    phase = 'prep';
    drawPrep();
    try {
      await s.prepare(step);
      if (!ctx.alive()) return;
      phase = 'ready';
      drawReady();
    } catch (e) {
      bridge.log('W', 'karaoke', 'prepare failed: ' + e.message);
      drawPrep(e.message);
    }
  };

  // ---------------------------------------------------------------- ready
  const drawReady = () => {
    const k = s.prefs.keyShift;
    const b = s.backingInfo || {};
    el.innerHTML = head() + `
      ${s.takes.length ? `<div class="banner">Voice 1 is recorded. Now sing the second voice: you will hear the first one.</div>` : ''}
      <div class="card">
        <div class="set-row" style="padding:0;min-height:0"><div class="meta"><div class="t1">Backing track</div><div class="t2">${b.kind === 'filter' ? 'Vocal filter on the original' : esc(b.title || '')}</div></div><button class="btn small" data-a="backing">Change</button></div>
        <div class="set-row" style="padding:12px 0 0;min-height:0"><div class="meta"><div class="t1">Key</div><div class="t2">${k ? (k > 0 ? '+' : '') + k + ' semitones' : 'Original key'}</div></div>
          <button class="icon-btn" data-a="keydown" aria-label="Lower">−</button><b style="width:28px;text-align:center">${k > 0 ? '+' : ''}${k}</b><button class="icon-btn" data-a="keyup" aria-label="Higher">+</button></div>
        ${s.lines.length ? `<div class="set-row" data-offset="${s.offsetSec.toFixed(1)}" style="padding:12px 0 0;min-height:0"><div class="meta"><div class="t1">Lyrics timing</div><div class="t2">${s.alignScore != null && s.alignScore <= 0.12 ? 'Check while singing: early or late?' : 'Synced automatically'}</div></div>
          <button class="btn small" data-a="earlier">−0.5 s</button>&nbsp;<button class="btn small" data-a="later">+0.5 s</button></div>` : `<p class="faint">${s.lyricsPlain ? 'Only unsynced lyrics are available; they scroll with the song.' : 'No lyrics found for this song.'}</p>`}
        <div class="set-row" style="padding:12px 0 0;min-height:0"><div class="meta"><div class="t1">Hear myself</div><div class="t2">Only with wired headphones (Bluetooth adds delay)</div></div>
          <label class="switch"><input type="checkbox" data-s="monitor" ${monitor ? 'checked' : ''}><span></span></label></div>
      </div>
      <div class="row-actions" style="justify-content:center;padding-top:8px"><button class="btn primary" data-a="sing" style="height:52px;padding:0 32px;font-size:16px">${icon('play')}${s.takes.length ? 'Sing voice 2' : 'Start singing'}</button></div>
      <p class="faint" style="padding:0 16px;text-align:center">Use headphones so the microphone only hears you.</p>
      <div class="row-actions" style="justify-content:center"><button class="btn small" data-a="recs">${icon('history')}My recordings</button></div>`;
  };

  const chooseBacking = () => {
    const items = s.candidates.map((c) => ({ icon: c.videoId === s.prefs.backing ? 'check' : 'note', label: c.title, sub: `${c.channel || ''} · ${fmtDur(c.durationMs)} · ${Math.round(c.score * 100)}%`, run: () => switchBacking(c.videoId) }));
    items.push({ icon: s.prefs.backing === 'filter' ? 'check' : 'tune', label: 'Vocal filter on the original', sub: 'Removes centre-panned vocals; quality varies per song', run: () => switchBacking('filter') });
    if (!s.candidates.length) items.unshift({ icon: 'search', label: 'Search YouTube for karaoke versions', run: async () => { s.prefs.backing = null; await reloadBacking(); } });
    sheet({ head: { title: 'Backing track' }, items });
  };
  const switchBacking = async (choice) => { s.prefs.backing = choice; s.prefs.offsetMs = null; await reloadBacking(); };
  const reloadBacking = async () => {
    phase = 'prep';
    for (const k of Object.keys(steps)) delete steps[k];
    el.innerHTML = '';
    drawPrep();
    try { await s.loadBacking(step); s.buildTimeline(); phase = 'ready'; drawReady(); } catch (e) { drawPrep(e.message); }
  };
  const changeKey = async (d) => {
    const k = Math.max(-6, Math.min(6, s.prefs.keyShift + d));
    phase = 'prep';
    for (const x of Object.keys(steps)) delete steps[x];
    el.innerHTML = '';
    drawPrep();
    try { await s.applyKey(k, step); phase = 'ready'; drawReady(); } catch (e) { drawPrep(e.message); }
  };

  // ---------------------------------------------------------------- sing
  const drawSing = () => {
    el.innerHTML = `<div class="kara">
      <div class="kara-top"><span class="kara-score">–</span><span class="kara-time faint"></span></div>
      <div class="kara-lyrics"><p class="prev"></p><p class="cur"></p><p class="next"></p></div>
      <canvas class="kara-lane"></canvas>
      <div class="kara-count"></div>
      <div class="kara-seek"><button class="btn small" data-a="rw">−10 s</button><input type="range" class="kseek" min="0" max="${Math.floor(s.backing.duration)}" step="1" value="0" aria-label="Position"><button class="btn small" data-a="ff">+10 s</button></div>
      <div class="kara-stop"><button class="btn primary" data-a="stop">${icon('pause')}Stop &amp; review</button></div>
    </div>`;
    // also in the top bar, so it can never end up off-screen
    ctx.setActions(`<button class="btn small" data-a="stop">Stop</button>`, (e) => { if (e.target.closest('[data-a="stop"]')) s.stopSinging(); });
  };

  const sing = async () => {
    phase = 'sing';
    saved = false;
    document.body.classList.add('kara-sing');
    drawSing();
    const lane = el.querySelector('.kara-lane');
    const g = lane.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    lane.width = lane.clientWidth * dpr;
    lane.height = lane.clientHeight * dpr;
    let trail = [];
    let lastScoreAt = 0;
    const seekEl = el.querySelector('.kseek');
    let dragging = false;
    seekEl.addEventListener('input', () => { dragging = true; el.querySelector('.kara-time').textContent = `${fmtDur(+seekEl.value * 1000) || '0:00'} / ${fmtDur(s.backing.duration * 1000)}`; });
    seekEl.addEventListener('change', () => { dragging = false; s.seekSinging(+seekEl.value); trail = []; });
    const onTick = ({ t, pitch, countdown }) => {
      if (!ctx.alive()) return;
      curT = t;
      el.querySelector('.kara-count').textContent = countdown ? String(countdown) : '';
      if (!dragging) {
        el.querySelector('.kara-time').textContent = `${fmtDur(t * 1000) || '0:00'} / ${fmtDur(s.backing.duration * 1000)}`;
        seekEl.value = String(Math.floor(t));
      }
      seekEl.disabled = !!countdown;
      drawLyrics(t);
      if (pitch) trail.push({ t: t - s.running.lat, m: pitch });
      trail = trail.filter((x) => x.t > t - 3 && x.t < t + 0.5); // seeking jumps the timeline
      drawLane(g, lane.width, lane.height, dpr, t, trail);
      const now = performance.now();
      if (now - lastScoreAt > 1000) { lastScoreAt = now; const sc = s.liveScore(); if (sc != null) el.querySelector('.kara-score').textContent = sc; }
    };
    try {
      lastRaw = await s.startSinging({ monitor, onTick });
    } catch (e) {
      endSingUi();
      toast(e.message, { ms: 6000 });
      phase = 'ready';
      drawReady();
      return;
    }
    endSingUi();
    if (!ctx.alive()) return;
    el.innerHTML = head() + '<div class="empty">Scoring your take…</div>';
    const take = await s.finishTake(lastRaw);
    s.takes.push(take);
    phase = 'review';
    drawReview();
  };

  const endSingUi = () => { document.body.classList.remove('kara-sing'); if (ctx.alive()) ctx.setActions('', null); };

  /** Current line as word spans: each word fills left to right in turn, so wrapped lines fill in reading order. */
  const setLineWords = (ce, text) => {
    const words = text.split(/\s+/).filter(Boolean);
    let pos = 0;
    const total = words.reduce((n, w) => n + w.length, 0) || 1;
    ce._words = words.map((w) => { const a = pos / total; pos += w.length; return { a, b: pos / total }; });
    ce.innerHTML = words.map((w) => `<span class="w">${esc(w)}</span>`).join(' ');
  };
  const fillWords = (ce, frac) => {
    const spans = ce.children;
    (ce._words || []).forEach((w, i) => {
      const f = frac <= w.a ? 0 : frac >= w.b ? 1 : (frac - w.a) / (w.b - w.a);
      spans[i].style.setProperty('--p', (f * 100).toFixed(1) + '%');
    });
  };

  const drawLyrics = (t) => {
    const ls = s.lines;
    const box = el.querySelector('.kara-lyrics');
    if (!box) return;
    if (!ls.length) {
      if (s.lyricsPlain && !box.dataset.plain) { box.dataset.plain = 1; box.innerHTML = `<div class="kara-plain">${esc(s.lyricsPlain).replace(/\n/g, '<br>')}</div>`; }
      const pl = box.querySelector('.kara-plain');
      if (pl) pl.style.transform = `translateY(${-Math.max(0, t / s.backing.duration) * (pl.scrollHeight - 120)}px)`;
      return;
    }
    let i = ls.findIndex((l) => t < l.end) ;
    if (i < 0) i = ls.length - 1;
    const cur = ls[i];
    const active = t >= cur.start;
    const frac = active ? Math.min(1, (t - cur.start) / Math.max(0.5, Math.min(cur.end - cur.start, 6))) : 0;
    const [pe, ce, ne] = box.children;
    pe.textContent = i > 0 && active ? ls[i - 1].text : '';
    if (ce.dataset.i !== String(i)) { ce.dataset.i = String(i); setLineWords(ce, cur.text); }
    fillWords(ce, active ? frac : 0);
    ce.classList.toggle('on', active);
    ne.textContent = active ? (ls[i + 1] ? ls[i + 1].text : '') : (ls[i + 1] ? '' : '');
    if (!active && cur.start - t < 8 && cur.start - t > 0) pe.textContent = `♪ ${Math.ceil(cur.start - t)}`;
  };

  const drawLane = (g, W, H, dpr, t, trail) => {
    g.clearRect(0, 0, W, H);
    const t0 = t - 2, t1 = t + 4;
    const x = (tt) => ((tt - t0) / (t1 - t0)) * W;
    const lo = 45, hi = 84;
    const y = (m) => H - ((m - lo) / (hi - lo)) * H;
    const css = getComputedStyle(document.documentElement);
    g.fillStyle = css.getPropertyValue('--bg3').trim() || '#222';
    for (let m = lo; m <= hi; m += 12) g.fillRect(0, y(m), W, 1 * dpr);
    const ref = s.ref;
    const key = s.prefs.keyShift;
    g.fillStyle = 'rgba(155,140,255,.55)';
    if (ref) {
      const shownRef = smoothOctaves(ref);
      const j0 = Math.max(0, Math.floor(t0 / ref.hopSec)), j1 = Math.min(ref.midi.length - 1, Math.ceil(t1 / ref.hopSec));
      for (let j = j0; j <= j1; j++) {
        const m = shownRef[j];
        if (!m) continue;
        const mm = foldInto(m + key, lo, hi);
        g.fillRect(x(j * ref.hopSec), y(mm) - 3 * dpr, Math.max(1, (ref.hopSec / (t1 - t0)) * W + 1), 6 * dpr);
      }
    }
    for (const p of trail) {
      const r = ref ? smoothOctaves(ref)[Math.round(p.t / ref.hopSec)] : 0;
      const target = r ? r + key : null;
      const shown = target ? foldInto(nearestOctave(p.m, target), lo, hi) : foldInto(p.m, lo, hi);
      const hit = target != null && pcDistance(p.m, target) <= 1;
      g.fillStyle = hit ? (css.getPropertyValue('--acc').trim() || '#1ed6a0') : '#ffb74d';
      g.beginPath();
      g.arc(x(p.t), y(shown), 3.5 * dpr, 0, Math.PI * 2);
      g.fill();
    }
    g.fillStyle = css.getPropertyValue('--fg').trim() || '#fff';
    g.fillRect(x(t), 0, 2 * dpr, H);
    const last = trail[trail.length - 1];
    if (last && last.t > t - 0.3) { g.font = `${12 * dpr}px system-ui`; g.fillText(midiName(last.m), x(t) + 6 * dpr, 14 * dpr); }
  };

  // ---------------------------------------------------------------- review
  const drawReview = () => {
    const scores = s.takes.map((t) => t.score);
    const last = s.takes[s.takes.length - 1];
    player2 = s.player(() => updatePlayer());
    const [a, b] = s.mixRange;
    el.innerHTML = head() + `
      <div class="card" style="text-align:center"><div class="faint">${s.takes.length > 1 ? 'Duet' : 'Your score'}</div>
        <div class="kara-big">${scores.map((x) => (x == null ? '–' : x)).join(' + ')}</div>
        <div class="faint">${s.lines.length ? 'Compared with the melody of the original singer.' : 'No synced lyrics: scored over the whole recording.'}</div></div>
      <div class="kara-player card">
        <button class="kp-play" data-a="pp" aria-label="Play">${icon('play')}</button>
        <div class="kp-bar"><input type="range" class="kp-seek" min="${a.toFixed(1)}" max="${b.toFixed(1)}" step="0.1" value="${a.toFixed(1)}" aria-label="Position">
          <div class="kp-time faint"><span class="kp-cur">${fmtDur((0) * 1000) || '0:00'}</span><span>${fmtDur((b - a) * 1000)}</span></div></div>
      </div>
      <div class="section"><h2>Voice effect</h2></div>
      <div class="chips kara-fx">${PRESET_ORDER.map((k) => `<button class="chip ${s.mix.preset === k ? 'on' : ''}" data-fx="${k}">${esc(VOICE_PRESETS[k].name)}</button>`).join('')}</div>
      <details class="card kara-tune"><summary>Fine-tune</summary>
        ${slider('voice', s.takes.length > 1 ? 'Voice 1' : 'Voice', s.mix.voice, 0, 2)}
        ${s.takes.length > 1 ? slider('voice2', 'Voice 2', s.mix.voice2, 0, 2) : ''}
        ${slider('backing', 'Music', s.mix.backing, 0, 1.5)}
        ${slider('amount', 'Effect amount', s.mix.amount, 0, 1.5)}
        <div class="set-row" style="padding:10px 0 0;min-height:0"><div class="meta"><div class="t1">Voice timing</div><div class="t2"><span class="lat">${Math.round(last.latency * 1000)}</span> ms · move it if your voice sounds early or late</div></div></div>
        <input type="range" min="-100" max="600" step="10" value="${Math.round(last.latency * 1000)}" data-lat="1">
      </details>
      <div class="row-actions" style="justify-content:center"><button class="btn primary" data-a="save">${icon('download')}Save</button>
        ${s.takes.length === 1 ? `<button class="btn" data-a="duet">${icon('add')}Add 2nd voice</button>` : ''}
        <button class="btn" data-a="again">${icon('refresh')}Sing again</button></div>
      <div class="save-status faint" style="text-align:center;padding:0 16px"></div>`;
    const seek = el.querySelector('.kp-seek');
    let dragging = false;
    seek.addEventListener('input', () => { dragging = true; el.querySelector('.kp-cur').textContent = fmtDur((+seek.value - a) * 1000) || '0:00'; });
    seek.addEventListener('change', () => { dragging = false; player2.seek(+seek.value); updatePlayer(); });
    const loop = () => {
      if (!ctx.alive() || phase !== 'review' || !player2) return;
      if (!dragging) { seek.value = String(player2.pos.toFixed(1)); el.querySelector('.kp-cur').textContent = fmtDur((player2.pos - a) * 1000) || '0:00'; }
      ticker = requestAnimationFrame(loop);
    };
    cancelAnimationFrame(ticker);
    ticker = requestAnimationFrame(loop);
  };
  const updatePlayer = () => {
    const b = el.querySelector('.kp-play');
    if (!b || !player2) return;
    b.innerHTML = icon(player2.playing ? 'pause' : 'play');
    b.setAttribute('aria-label', player2.playing ? 'Pause' : 'Play');
  };
  const slider = (k, label, v, min, max) => `<div class="set-row" style="padding:6px 0 0;min-height:0"><div class="meta"><div class="t1">${label}</div></div>
    <input type="range" min="${min}" max="${max}" step="0.05" value="${v}" data-mix="${k}" style="max-width:60%"></div>`;
  const leaveReview = () => { cancelAnimationFrame(ticker); s.closePlayer(); player2 = null; };

  // ---------------------------------------------------------------- events
  el.oninput = (e) => {
    const t = e.target;
    if (t.dataset.mix) { s.mix[t.dataset.mix] = +t.value; }
    if (t.dataset.lat) {
      const v = +t.value / 1000;
      s.takes[s.takes.length - 1].latency = v;
      el.querySelector('.lat').textContent = Math.round(v * 1000);
    }
  };
  el.onchange = (e) => {
    const t = e.target;
    if (t.dataset.s === 'monitor') monitor = t.checked;
    if ((t.dataset.mix || t.dataset.lat) && player2) player2.refresh();
    if (t.dataset.lat) s.latencySec = +t.value / 1000; // remember the calibration for next time
  };
  el.onclick = async (e) => {
    const fx = e.target.closest('[data-fx]');
    if (fx) {
      s.mix.preset = fx.dataset.fx;
      db.kvSet('karaoke.preset', s.mix.preset); // remembered for next time
      el.querySelectorAll('.kara-fx .chip').forEach((c) => c.classList.toggle('on', c === fx));
      if (player2) { if (!player2.playing) player2.play(); else player2.refresh(); updatePlayer(); }
      return;
    }
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (!a) return;
    switch (a) {
      case 'retry': prepare(); break;
      case 'backing': chooseBacking(); break;
      case 'keyup': changeKey(1); break;
      case 'keydown': changeKey(-1); break;
      case 'earlier': s.nudge(-500); drawReady(); break;
      case 'later': s.nudge(500); drawReady(); break;
      case 'sing': sing(); break;
      case 'stop': s.stopSinging(); break;
      case 'rw': s.seekSinging(curT - 10); break;
      case 'ff': s.seekSinging(curT + 10); break;
      case 'pp': if (player2) { player2.toggle(); updatePlayer(); } break;
      case 'again': leaveReview(); s.takes.pop(); saved = false; phase = 'ready'; drawReady(); break;
      case 'duet': leaveReview(); phase = 'ready'; drawReady(); break;
      case 'recs': leaveReview(); ctx.nav.go('recordings'); break;
      case 'save': {
        if (player2) { player2.pause(); updatePlayer(); }
        const st = el.querySelector('.save-status');
        el.querySelectorAll('.btn').forEach((b) => { b.disabled = true; });
        try {
          const r = await s.save((m) => { st.textContent = m; });
          saved = true;
          st.innerHTML = `Saved as <b>${esc(r.name)}</b> in Music/TuneLab Karaoke.<div class="row-actions" style="justify-content:center;padding:8px 0 0"><button class="btn small" data-a="recs">${icon('history')}All recordings</button></div>`;
          toast('Recording saved', { action: 'Share', onAction: () => bridge.call('rec.share', { recId: r.recId }), ms: 6000 });
        } catch (err) {
          st.textContent = 'Saving failed: ' + err.message;
        }
        el.querySelectorAll('.btn').forEach((b) => { b.disabled = false; });
        break;
      }
      default: break;
    }
  };

  prepare();
  return () => { cancelAnimationFrame(raf); cancelAnimationFrame(ticker); document.body.classList.remove('kara-open', 'kara-sing'); s.close(); };
}

/** Error text for people, not developers. */
function friendly(msg) {
  const m = String(msg || '');
  if (/permission/i.test(m)) return 'TuneLab needs the microphone to record you.';
  if (/network|timeout|timed out|HTTP|fetch|offline|unreachable/i.test(m)) return 'The song could not be downloaded. Check your internet connection and try again.';
  if (/No playable source|no YouTube match|nothing to prepare/i.test(m)) return 'TuneLab could not find this song on YouTube. Try “Choose another source” in the song menu.';
  return 'Something went wrong while preparing. Try again; if it keeps happening, Settings → Advanced → Diagnostics has the details.';
}

/** Display-only: pitch trackers jump octaves on full mixes; keep each note in the octave closest to the previous one. */
const smoothed = new WeakMap();
function smoothOctaves(ref) {
  let out = smoothed.get(ref);
  if (out) return out;
  const voiced = Array.from(ref.midi).filter((m) => m > 0).sort((a, b) => a - b);
  let prev = voiced.length ? voiced[voiced.length >> 1] : 60;
  out = new Float32Array(ref.midi.length);
  for (let j = 0; j < ref.midi.length; j++) {
    const m = ref.midi[j];
    if (!m) continue;
    out[j] = nearestOctave(m, prev);
    prev = out[j];
  }
  smoothed.set(ref, out);
  return out;
}
function foldInto(m, lo, hi) {
  while (m < lo) m += 12;
  while (m > hi) m -= 12;
  return m;
}
function nearestOctave(m, target) {
  let x = m;
  while (x - target > 6) x -= 12;
  while (target - x > 6) x += 12;
  return x;
}

// ------------------------------------------------------------------ recordings list
function recordings(el, ctx) {
  ctx.setTitle('Karaoke recordings');
  let actx = null, mp = null, playingId = null, raf = 0, dragging = false;
  const stop = () => { cancelAnimationFrame(raf); try { mp && mp.close(); } catch { /* ignore */ } try { actx && actx.close(); } catch { /* ignore */ } mp = null; actx = null; playingId = null; };
  const draw = () => {
    const rows = db.q('SELECT r.*, t.artwork_url FROM recording r LEFT JOIN track t ON t.id=r.track_id ORDER BY r.created_at DESC');
    const cur = rows.find((r) => r.id === playingId);
    el.innerHTML = (cur && mp ? `<div class="kara-player card"><button class="kp-play" data-a="pp" aria-label="${mp.playing ? 'Pause' : 'Play'}">${icon(mp.playing ? 'pause' : 'play')}</button>
        <div class="kp-bar"><div class="t1" style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(cur.title)}</div>
        <input type="range" class="kp-seek" min="0" max="${mp.end.toFixed(1)}" step="0.1" value="${mp.pos.toFixed(1)}" aria-label="Position">
        <div class="kp-time faint"><span class="kp-cur">${fmtDur(mp.pos * 1000) || '0:00'}</span><span>${fmtDur(mp.end * 1000)}</span></div></div></div>` : '')
      + (rows.length ? `<p class="faint" style="padding:0 16px">${rows.length} recording${rows.length > 1 ? 's' : ''} · saved in Music/TuneLab Karaoke</p>` + rows.map((r) => `<div class="trow static${playingId === r.id ? ' current' : ''}" data-id="${r.id}">${art(r.artwork_url, { fallback: 'note' })}<div class="meta"><div class="t1">${esc(r.title)}</div>
      <div class="t2">${r.voices > 1 ? '<span class="badge rec">DUET</span>' : ''}${r.score != null ? `<span class="badge acc">${r.score}</span>` : ''}<span>${esc(r.artists || '')} · ${fmtDur(r.duration_ms)} · ${fmtAgo(r.created_at)}${r.key_shift ? ` · key ${r.key_shift > 0 ? '+' : ''}${r.key_shift}` : ''}</span></div></div>
      <button class="icon-btn more">${icon('more')}</button></div>`).join('')
        : `<div class="empty">${icon('note')}No recordings yet. Open a song's ⋮ menu and choose “Sing karaoke”.</div>`);
    const seek = el.querySelector('.kp-seek');
    if (seek) {
      seek.addEventListener('input', () => { dragging = true; el.querySelector('.kp-cur').textContent = fmtDur(+seek.value * 1000) || '0:00'; });
      seek.addEventListener('change', () => { dragging = false; mp.seek(+seek.value); });
    }
  };
  const loop = () => {
    if (!ctx.alive() || !mp) return;
    const seek = el.querySelector('.kp-seek');
    if (seek && !dragging) { seek.value = String(mp.pos.toFixed(1)); el.querySelector('.kp-cur').textContent = fmtDur(mp.pos * 1000) || '0:00'; }
    const b = el.querySelector('.kp-play');
    if (b && b.dataset.state !== String(mp.playing)) { b.dataset.state = String(mp.playing); b.innerHTML = icon(mp.playing ? 'pause' : 'play'); }
    raf = requestAnimationFrame(loop);
  };
  el.onclick = async (e) => {
    if (e.target.closest('[data-a="pp"]')) { if (mp) mp.toggle(); return; }
    const row = e.target.closest('.trow');
    if (!row) return;
    const id = +row.dataset.id;
    if (e.target.closest('.more')) {
      const rec = db.one('SELECT * FROM recording WHERE id=?', [id]);
      sheet({ head: { title: rec?.title || 'Recording', sub: rec?.artists }, items: [
        { icon: 'share', label: 'Share', run: () => { try { bridge.call('rec.share', { recId: id }); } catch (err) { toast(err.message); } } },
        ...(rec?.track_id ? [{ icon: 'lyrics', label: 'Sing this song again', run: () => { stop(); ctx.nav.go('karaoke', { trackId: rec.track_id }); } }] : []),
        { icon: 'trash', label: 'Delete', danger: true, run: async () => { if (await confirmDialog({ title: 'Delete this recording?', ok: 'Delete', danger: true })) { if (playingId === id) stop(); bridge.call('rec.delete', { recId: id }); draw(); } } },
      ] });
      return;
    }
    if (playingId === id && mp) { mp.toggle(); return; } // tapping the playing one pauses / resumes
    stop();
    try {
      actx = new AudioContext();
      const buf = await actx.decodeAudioData(await (await fetch('/media/rec/' + id)).arrayBuffer());
      mp = new MixPlayer(actx, (c, when, from, out) => { const src = c.createBufferSource(); src.buffer = buf; src.connect(out); src.start(when, from); return [src]; }, { start: 0, end: buf.duration });
      playingId = id;
      try { if (player.state.playWhenReady) player.cmd('pause'); } catch { /* ignore */ }
      mp.play(0);
      draw();
      raf = requestAnimationFrame(loop);
    } catch (err) { stop(); toast('Cannot play this recording: ' + err.message); }
  };
  draw();
  return stop;
}
