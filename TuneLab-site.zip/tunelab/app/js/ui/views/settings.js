// Settings and the Equalizer screen.
import * as db from '../../core/db.js';
import * as bridge from '../../core/bridge.js';
import * as settings from '../../core/settings.js';
import { icon, esc } from '../dom.js';
import { toast, prompt, sheet, confirmDialog, panel } from '../components.js';
import { applyTheme, ACCENTS } from '../main.js';
import { WHATS_NEW } from '../../core/whatsnew.js';
import { APP } from '../../core/app-info.js';
import { fmtAgo, fmtBytes } from '../../core/util.js';
import { carSummary } from './car.js';
import { isDesktop, isWeb, hasEngine, platform } from '../../core/platform.js';

export function render(el, p, ctx) {
  if (p.view === 'equalizer') return equalizer(el, ctx);
  if (p.view === 'advanced') return advancedView(el, ctx);
  if (p.view === 'offlinesets') return offlineSets(el, ctx);
  return settingsView(el, ctx);
}

const QUAL = [['high', 'High', 'Best quality (~160 kbps)'], ['normal', 'Normal', '~128 kbps'], ['low', 'Low', 'Data saver (~50 kbps)']];
const CHOICES = {
  theme: ['Theme', [['dark', 'Dark'], ['light', 'Light'], ['system', 'Same as phone']]],
  qualityWifi: ['Quality on Wi-Fi', QUAL],
  qualityMobile: ['Quality on mobile data', QUAL],
  downloadQuality: ['Download quality', QUAL],
  crossfadeSec: ['Crossfade', [[0, 'Off', 'Gapless'], [2, '2 s'], [4, '4 s'], [6, '6 s'], [8, '8 s'], [12, '12 s']]],
  smartShuffleEvery: ['Smart shuffle', [[3, 'After every 3 songs'], [4, 'After every 4 songs'], [5, 'After every 5 songs'], [8, 'After every 8 songs']]],
  backupSchedule: ['Automatic backup', [['off', 'Off'], ['daily', 'Daily'], ['weekly', 'Weekly']]],
  cacheSizeMb: ['Stream cache size', [[512, '512 MB'], [1024, '1 GB'], [2048, '2 GB'], [4096, '4 GB'], [8192, '8 GB']]],
  prefetchWifi: ['Prefetch on Wi-Fi', [[1, 'Next song'], [2, 'Next 2 songs'], [3, 'Next 3 songs']]],
  prefetchMobile: ['Prefetch on mobile data', [[0, 'Off'], [1, 'Next song'], [2, 'Next 2 songs']]],
  poToken: ['PO tokens (web clients)', [['auto', 'When needed'], ['off', 'Off']]],
};

const chev = () => `<svg class="chev" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2"/></svg>`;

function toggle(name, title, sub = '') {
  return `<div class="set-row"><div class="meta"><div class="t1">${esc(title)}</div>${sub ? `<div class="t2">${esc(sub)}</div>` : ''}</div>
    <label class="switch"><input type="checkbox" data-s="${name}" ${settings.get(name) ? 'checked' : ''}><span></span></label></div>`;
}
function select(name, title, opts, sub = '') {
  const v = String(settings.get(name));
  return `<div class="set-row"><div class="meta"><div class="t1">${esc(title)}</div>${sub ? `<div class="t2">${esc(sub)}</div>` : ''}</div>
    <select data-sel="${name}">${opts.map(([k, l]) => `<option value="${esc(k)}" ${String(k) === v ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>`;
}
/** A setting with a few options: shows the current value, opens a bottom sheet. */
function choice(name, sub = '') {
  const [title, opts] = CHOICES[name];
  const cur = opts.find(([k]) => String(k) === String(settings.get(name)));
  return `<button class="set-row" data-choice="${name}"><div class="meta"><div class="t1">${esc(title)}</div>${sub ? `<div class="t2">${esc(sub)}</div>` : ''}</div>
    <span class="val">${esc(cur ? cur[1] : String(settings.get(name)))}</span>${chev()}</button>`;
}
function link(attr, title, sub = '', val = '') {
  return `<button class="set-row" ${attr}><div class="meta"><div class="t1">${esc(title)}</div>${sub ? `<div class="t2">${esc(sub)}</div>` : ''}</div>${val ? `<span class="val">${esc(val)}</span>` : ''}${chev()}</button>`;
}
const accentRow = () => `<div class="set-row accent-row"><div class="meta"><div class="t1">Accent colour</div></div>
  <div class="swatches">${Object.entries(ACCENTS).map(([k, a]) => `<button class="swatch ${settings.get('accent') === k ? 'on' : ''}" data-accent="${k}" style="--c:${a[1]}" aria-label="${a[0]}"></button>`).join('')}</div></div>`;
const group = (title, rows) => `<div class="set-group"><h3>${esc(title)}</h3><div class="set-card">${rows.join('')}</div></div>`;

function pickChoice(name, after) {
  const [title, opts] = CHOICES[name];
  const cur = String(settings.get(name));
  sheet({ head: { title }, items: opts.map(([k, label, sub]) => ({ icon: String(k) === cur ? 'check' : 'blank', label, sub, run: () => { settings.set(name, typeof k === 'number' ? k : String(k)); after(name); } })) });
}

function settingsView(el, ctx) {
  ctx.setTitle('Settings');
  const draw = () => {
    const backup = db.kvGetJson('backup.last');
    const lfm = safe(() => bridge.call('scrobble.status'), {});
    const offlinePls = db.listPlaylists().filter((x) => x.offline).length;
    const sp = db.kvGetJson('spotify.lastSync');
    const pc = isDesktop();
    if (pc) {
      el.innerHTML = desktopSettings({ backup });
      return;
    }
    el.innerHTML = `
    ${group('Playback', [
    choice('qualityWifi'), choice('qualityMobile'), choice('crossfadeSec'),
    link('data-go="equalizer"', 'Equalizer', '', settings.get('eqEnabled') ? settings.get('eqPreset') : 'Off'),
    toggle('normalize', 'Same volume for every song'),
    toggle('autoRadio', 'Autoplay', 'Keep playing similar music when the queue ends'),
    link('data-go="car"', 'Play in the car', 'Starts when your car connects', carSummary()),
  ])}
    ${group('Downloads & offline', [
    choice('downloadQuality'),
    toggle('downloadWifiOnly', 'Download on Wi-Fi only'),
    toggle('likesOffline', 'Keep liked songs offline', 'New likes download automatically'),
    link('data-go="offlinesets"', 'Playlists kept offline', 'Songs you add download automatically', offlinePls ? String(offlinePls) : 'None'),
    toggle('offlineMode', 'Offline mode', 'Only show songs that play without internet'),
  ])}
    ${group('Discover', [
    toggle('mixEnabled', 'Weekly Discovery', 'New songs for you every Monday'),
    toggle('mixOffline', 'Download Weekly Discovery', 'Off: only the songs you like are downloaded'),
    toggle('releasesEnabled', 'New releases from your artists'),
    toggle('genresEnabled', 'Genres', 'Genre filters; looks up artist names on MusicBrainz'),
    choice('smartShuffleEvery', 'How often smart shuffle adds a new song'),
  ])}
    ${group('Library', [
    link('data-go="spotify"', 'Spotify', settings.get('spotifyClientId') ? (sp ? `Last sync ${fmtAgo(sp.at)}` : 'Not synced yet') : 'Import likes and playlists'),
    link('data-go="csv"', 'Import a CSV file', 'Exportify or TuneMyMusic'),
    link('data-go="datapkg"', 'Spotify data package', 'Streaming history and stats'),
    link('data-go="local"', 'Music on this phone'),
  ])}
    ${group('Backup', [
    link('data-go="transfer"', 'Move library to another phone', 'With a code, over your Wi-Fi'),
    link('data-a="backupFolder"', 'Backup folder', '', settings.get('backupTreeName') || 'Not chosen'),
    choice('backupSchedule'),
    link('data-a="backupNow"', 'Back up now', backup ? `Last backup ${fmtAgo(backup.at)}` : ''),
    link('data-a="restore"', 'Restore a backup'),
  ])}
    ${group('Last.fm', [
    toggle('lastfmEnabled', 'Scrobble to Last.fm', lfm.user ? `Connected as ${lfm.user}${lfm.queued ? ` · ${lfm.queued} waiting` : ''}` : 'Not connected'),
    link('data-a="lastfm"', lfm.user ? 'Reconnect' : 'Connect'),
  ])}
    ${group('Appearance', [choice('theme'), accentRow()])}
    ${group('About', [
    link('data-a="whatsnew"', "What's new", '', APP.versionName),
    link('data-a="update"', 'Check for updates'),
    link('data-go="advanced"', 'Advanced', 'Cache, YouTube, matching, diagnostics'),
  ])}
    <p class="faint" style="text-align:center;margin:4px 16px 20px">${esc(APP.name)} ${esc(APP.versionName)} · no accounts, no trackers, no ads</p>`;
  };
  bindCommon(el, ctx, draw);
  draw();
}

/** Windows: the phone's settings minus downloads, car, equalizer, Spotify login, Last.fm and backup folders. */
function desktopSettings({ backup }) {
  return `
    ${group('Playback', [choice('qualityWifi'), toggle('normalize', 'Same volume for every song'), toggle('autoRadio', 'Autoplay', 'Keep playing similar music when the queue ends')])}
    ${hasEngine() ? group('Discover', [
    toggle('mixEnabled', 'Weekly Discovery', 'New songs for you every Monday'),
    toggle('releasesEnabled', 'New releases from your artists'),
    toggle('genresEnabled', 'Genres', 'Genre filters; looks up artist names on MusicBrainz'),
    choice('smartShuffleEvery', 'How often smart shuffle adds a new song'),
  ]) : ''}
    ${group('Library', [
    platform() === 'desktop' ? link('data-go="transfer"', 'Get my library from the phone', 'With the code from the phone, over the network') : '',
    link('data-a="restore"', 'Open a backup file', 'A TuneLab backup from the phone (Settings → Backup → Back up now)'),
    link('data-a="backupNow"', 'Save a backup file', backup ? `Last ${fmtAgo(backup.at)} · restore it on the phone to take changes back` : 'Goes to Downloads; restore it on the phone to take changes back'),
    link('data-go="csv"', 'Import a CSV file', 'Exportify or TuneMyMusic'),
  ])}
    ${group('Appearance', [choice('theme'), accentRow()])}
    ${group('About', [
    link('data-a="whatsnew"', "What's new", '', APP.versionName),
    hasEngine() ? link('data-go="advanced"', 'Advanced', 'YouTube, matching, diagnostics') : '',
  ])}
    <p class="faint" style="text-align:center;margin:4px 16px 20px">${esc(APP.name)} ${esc(APP.versionName)} ${isWeb() ? 'in your browser · your library stays in this browser' : 'for Windows · your library stays on this computer'} · no accounts, no trackers, no ads</p>`;
}

function advancedView(el, ctx) {
  ctx.setTitle('Advanced');
  const draw = () => {
    const cache = safe(() => bridge.call('cache.stats'), {});
    el.innerHTML = `
    ${isDesktop() ? '' : group('Storage', [choice('cacheSizeMb', `${fmtBytes(cache.cacheBytes)} used`), choice('prefetchWifi'), choice('prefetchMobile')])}
    ${group('Radio', [toggle('radioFilterLibrary', 'Mostly new music', 'Skip songs already in your library'), toggle('radioLastfm', 'Blend in Last.fm similar tracks')])}
    ${group('YouTube', [
    link('data-go="review"', 'Matching', matchSummary()),
    link('data-a="clients"', 'Client order', settings.get('ytClients')),
    choice('poToken'),
  ])}
    ${group('Help', [link('data-go="diagnostics"', 'Diagnostics', 'Log, YouTube test, background test')])}
    <p class="faint" style="text-align:center;margin:4px 16px 20px">Build ${esc(APP.buildTime || 'dev')}</p>`;
  };
  bindCommon(el, ctx, draw);
  draw();
}

function offlineSets(el, ctx) {
  ctx.setTitle('Playlists kept offline');
  const draw = () => {
    const pls = db.listPlaylists().filter((x) => x.n > 0 || x.offline);
    el.innerHTML = `<p class="faint" style="margin:0 16px 8px">Switched-on playlists stay downloaded: songs you add later download by themselves${settings.get('downloadWifiOnly') ? ' (on Wi-Fi)' : ''}.</p>
      <div class="set-card">${pls.map((pl) => {
    const st = pl.offline ? db.playlistOfflineState(pl.id) : null;
    return `<div class="set-row"><div class="meta"><div class="t1">${esc(pl.name)}</div><div class="t2">${pl.n} songs${st ? ` · ${st.done} downloaded` : ''}</div></div>
          <label class="switch"><input type="checkbox" data-pl="${pl.id}" ${pl.offline ? 'checked' : ''}><span></span></label></div>`;
  }).join('') || '<div class="set-row"><div class="meta"><div class="t2">No playlists yet.</div></div></div>'}</div>`;
  };
  el.onchange = async (e) => {
    const id = +e.target.dataset.pl;
    if (!id) return;
    const actions = await import('../actions.js');
    if (e.target.checked) {
      db.setPlaylistOffline(id, true);
      const n = actions.offlineSync();
      toast(n ? `${n} songs will download` : 'Everything is already downloaded');
    } else {
      db.setPlaylistOffline(id, false);
      const orphans = db.offlineOrphans(db.playlistEntries(id).map((t) => t.id), { exceptPlaylistId: id, likes: !!settings.get('likesOffline') });
      if (orphans.length && await confirmDialog({ title: 'Remove the downloads too?', text: `${orphans.length} downloaded songs of this playlist are not needed offline elsewhere. They stay in your library and stream again.`, ok: 'Remove downloads' })) {
        bridge.call('downloads.delete', { trackIds: orphans });
        toast(`${orphans.length} downloads removed`);
      }
    }
    actions.emitLibraryChanged('downloads');
    draw();
  };
  draw();
  const off = bridge.on('downloads', () => ctx.alive() && draw());
  return off;
}

/** Shared handlers for the settings pages. */
function bindCommon(el, ctx, draw) {
  el.onchange = (e) => {
    const t = e.target;
    if (t.dataset.s) { settings.set(t.dataset.s, t.checked); afterChange(t.dataset.s); }
  };
  const afterChange = (name) => {
    if (name === 'theme') applyTheme();
    if (name === 'offlineMode') bridge.emitLocal('library', { what: 'settings' });
    if (name === 'likesOffline' && settings.get('likesOffline')) import('../actions.js').then((m) => { const n = m.offlineSync(); toast(n ? `${n} liked songs will download` : 'All liked songs are already downloaded'); });
    if (name === 'mixEnabled' && settings.get('mixEnabled')) bridge.call('jobs.start', { job: 'weeklyMix' });
    if (name === 'releasesEnabled' && settings.get('releasesEnabled')) bridge.call('jobs.start', { job: 'newReleases' });
    if (name === 'genresEnabled' && settings.get('genresEnabled')) bridge.call('jobs.start', { job: 'genres' });
    if (name === 'mixOffline') {
      const mix = db.mixPlaylist();
      if (mix) db.setPlaylistOffline(mix.id, settings.get('mixOffline'));
      if (settings.get('mixOffline')) import('../actions.js').then((m) => m.offlineSync());
    }
    if (name === 'backupSchedule') { if (!settings.get('backupTreeUri') && settings.get('backupSchedule') !== 'off') toast('Choose a backup folder first'); bridge.call('backup.schedule'); }
    draw();
  };
  el.onclick = async (e) => {
    const go = e.target.closest('[data-go]');
    if (go) return ctx.nav.go(go.dataset.go);
    const ch = e.target.closest('[data-choice]');
    if (ch) return pickChoice(ch.dataset.choice, afterChange);
    const ac = e.target.closest('[data-accent]');
    if (ac) { settings.set('accent', ac.dataset.accent); applyTheme(); draw(); return; }
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (!a) return;
    if (a === 'backupFolder') {
      const r = await bridge.callAsync('pick.tree', { purpose: 'backup' });
      if (r) { settings.set('backupTreeUri', r.uri); settings.set('backupTreeName', r.name); bridge.call('backup.schedule'); draw(); }
    }
    if (a === 'backupNow') {
      toast('Backing up…');
      try {
        const r = await bridge.callAsync('backup.run', { treeUri: settings.get('backupTreeUri') || null });
        toast(`Saved: ${r.file}`, { ms: 5000 });
        if (!settings.get('backupTreeUri') && !isDesktop()) toast('Tip: choose a backup folder so the backup survives uninstalling', { ms: 6000 });
        draw();
      } catch (err) { toast('Backup failed: ' + err.message, { ms: 6000 }); }
    }
    if (a === 'restore') {
      const { restoreBackupFlow } = await import('../actions.js');
      if (await restoreBackupFlow()) draw();
    }
    if (a === 'lastfm') lastfmConnect(draw);
    if (a === 'clients') {
      const v = await prompt({ title: 'YouTube client order', value: settings.get('ytClients'), ok: 'Save' });
      if (v) { settings.set('ytClients', v.toUpperCase().replace(/\s+/g, '')); draw(); toast('Saved. Test it in Diagnostics.'); }
    }
    if (a === 'whatsnew') {
      panel(WHATS_NEW.map((w) => `<h3 style="margin:8px 0 4px">${esc(w.version)} <small class="faint">${esc(w.date)}</small></h3><ul style="margin:0 0 12px;padding-left:20px">${w.items.map((i) => `<li style="margin:4px 0">${esc(i)}</li>`).join('')}</ul>`).join(''));
    }
    if (a === 'update') checkUpdate(draw);
  };
}

function matchSummary() {
  const c = db.matchCounts();
  return `${c.MATCHED + c.MANUAL} matched · ${c.REVIEW} to check · ${c.FAILED} not found · ${c.pending} waiting`;
}

async function lastfmConnect(done) {
  const apiKey = await prompt({ title: 'Last.fm API key', value: settings.get('lastfmApiKey'), placeholder: 'from last.fm/api/account/create' });
  if (!apiKey) return;
  const secret = await prompt({ title: 'Last.fm shared secret', value: settings.get('lastfmSecret'), type: 'password' });
  if (!secret) return;
  const user = await prompt({ title: 'Last.fm username', value: db.kvGet('lastfm.user') || '' });
  if (!user) return;
  const pass = await prompt({ title: 'Last.fm password', type: 'password', ok: 'Connect' });
  if (!pass) return;
  settings.set('lastfmApiKey', apiKey);
  settings.set('lastfmSecret', secret);
  try {
    const r = await bridge.callAsync('lastfm.auth', { apiKey, secret, user, pass });
    settings.set('lastfmEnabled', true);
    toast(`Connected as ${r.user}. Your password was not stored.`);
  } catch (e) { toast('Last.fm: ' + e.message, { ms: 6000 }); }
  done();
}

async function checkUpdate(done) {
  if (!settings.get('githubToken')) {
    const t = await prompt({ title: 'GitHub token (read-only, contents:read)', type: 'password', placeholder: 'github_pat_…' });
    if (!t) return;
    settings.set('githubToken', t);
  }
  try {
    const r = await bridge.callAsync('update.check', { repo: settings.get('githubRepo') });
    const latest = String(r.tag || '').replace(/^v/, '');
    const newer = latest && latest !== APP.versionName && cmpVersion(latest, APP.versionName) > 0;
    sheet({ head: { title: newer ? `Update available: ${latest}` : `You're up to date (${APP.versionName})`, sub: r.name },
      body: `<pre class="log" style="padding:0">${esc((r.body || '').slice(0, 1500))}</pre>`,
      items: newer ? [{ icon: 'download', label: 'Open the release page', run: () => bridge.call('openUrl', { url: r.htmlUrl }) }] : [] });
  } catch (e) { toast('Update check failed: ' + e.message, { ms: 6000 }); }
  done();
}

function cmpVersion(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d; }
  return 0;
}

// ------------------------------------------------------------------ equalizer

const FREQ_LABELS = ['31', '62', '125', '250', '500', '1k', '2k', '4k', '8k', '16k'];
export const PRESETS = {
  Flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  'Bass boost': [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
  'Treble boost': [0, 0, 0, 0, 0, 1, 2, 4, 5, 6],
  Vocal: [-2, -2, -1, 1, 3, 4, 3, 1, 0, -1],
  Rock: [4, 3, 2, 0, -1, -1, 1, 2, 3, 4],
  Pop: [-1, 0, 2, 3, 3, 2, 0, -1, -1, -1],
  Classical: [3, 2, 1, 0, 0, 0, -1, 1, 2, 3],
  Jazz: [3, 2, 1, 2, -1, -1, 0, 1, 2, 3],
  Electronic: [5, 4, 1, 0, -2, 1, 0, 1, 4, 5],
  Loudness: [5, 3, 0, 0, -1, 0, 0, 0, 3, 5],
};

function equalizer(el, ctx) {
  ctx.setTitle('Equalizer');
  const draw = () => {
    const bands = settings.get('eqBands');
    el.innerHTML = `${toggle('eqEnabled', 'Equalizer', '10 bands (DynamicsProcessing) with a limiter against clipping')}
      ${select('eqPreset', 'Preset', [...Object.keys(PRESETS), 'Custom'].map((k) => [k, k]))}
      <div class="eq">${bands.map((g, i) => `<div class="band"><b>${g > 0 ? '+' : ''}${g}</b><input type="range" min="-12" max="12" step="1" value="${g}" data-band="${i}"><small>${FREQ_LABELS[i]}</small></div>`).join('')}</div>
      <div class="set-row"><div class="meta"><div class="t1">Preamp</div><div class="t2">${settings.get('eqPreamp')} dB</div></div><input type="range" min="-12" max="6" step="1" value="${settings.get('eqPreamp')}" data-range="eqPreamp" style="max-width:50%"></div>
      <div class="set-row"><div class="meta"><div class="t1">Bass boost</div><div class="t2">${Math.round(settings.get('bassBoost') / 10)}%</div></div><input type="range" min="0" max="1000" step="50" value="${settings.get('bassBoost')}" data-range="bassBoost" style="max-width:50%"></div>
      <p class="faint" style="padding:0 16px">Changes apply immediately to everything you play.</p>`;
  };
  el.onchange = (e) => {
    const t = e.target;
    if (t.dataset.s) settings.set(t.dataset.s, t.checked);
    if (t.dataset.sel === 'eqPreset' && PRESETS[t.value]) { settings.set('eqPreset', t.value); settings.set('eqBands', PRESETS[t.value]); if (!settings.get('eqEnabled')) settings.set('eqEnabled', true); draw(); }
    if (t.dataset.band != null) {
      const b = [...settings.get('eqBands')];
      b[+t.dataset.band] = +t.value;
      settings.set('eqBands', b);
      settings.set('eqPreset', 'Custom');
      if (!settings.get('eqEnabled')) settings.set('eqEnabled', true);
      draw();
    }
    if (t.dataset.range) { settings.set(t.dataset.range, +t.value); draw(); }
  };
  draw();
}

function safe(fn, d) { try { return fn(); } catch { return d; } }
