// Smart playlists: template picker ("smartnew") and rule editor ("smartedit").
import * as db from '../../core/db.js';
import { icon, esc } from '../dom.js';
import { sheet, toast } from '../components.js';
import { emitLibraryChanged } from '../actions.js';
import { FIELDS, SORTS, TEMPLATES, fromTemplate } from '../../lib/smart.js';

export function render(el, p, ctx) {
  if (p.view === 'smartnew') return picker(el, ctx);
  return editor(el, p, ctx);
}

function picker(el, ctx) {
  ctx.setTitle('New smart playlist');
  el.innerHTML = `<p class="faint" style="padding:0 16px">A smart playlist fills itself from your library using rules (likes, plays, dates, artists…) and stays up to date.</p>
    ${TEMPLATES.map((t, i) => `<button class="set-row" data-t="${i}"><div class="art liked" style="width:48px;height:48px;border-radius:8px;background:linear-gradient(135deg,#7a5cff,#1e9bd6)">${icon('sparkle')}</div>
      <div class="meta"><div class="t1">${esc(t.name.replace('{year}', '…'))}</div><div class="t2">${esc(t.sub)}</div></div></button>`).join('')}
    <button class="set-row" data-t="custom"><div class="art" style="width:48px;height:48px;border-radius:8px">${icon('edit')}</div><div class="meta"><div class="t1">Start from scratch</div><div class="t2">Write your own rules</div></div></button>`;
  const create = (name, spec) => {
    const id = db.createSmart(name, spec);
    emitLibraryChanged('playlists');
    ctx.nav.back();
    ctx.nav.go('smart', { id });
  };
  el.onclick = (e) => {
    const b = e.target.closest('[data-t]');
    if (!b) return;
    if (b.dataset.t === 'custom') { ctx.nav.go('smartedit', { id: 0 }); return; }
    const tpl = TEMPLATES[+b.dataset.t];
    if (!tpl.year) { const { name, spec } = fromTemplate(tpl); create(name, spec); return; }
    const years = db.stats().years.map((y) => y.year).filter(Boolean);
    if (!years.length) years.push(new Date().getUTCFullYear());
    sheet({ head: { title: 'Which year?' }, items: years.map((y) => ({ icon: 'stats', label: String(y), run: () => { const { name, spec } = fromTemplate(tpl, y); create(name, spec); } })) });
  };
}

const DEFAULT_RULE = { field: 'liked', op: 'is' };

function editor(el, p, ctx) {
  const existing = p.id ? db.getSmart(p.id) : null;
  ctx.setTitle(existing ? 'Edit smart playlist' : 'New smart playlist');
  const st = existing
    ? { name: existing.name, spec: JSON.parse(JSON.stringify(existing.spec)) }
    : { name: '', spec: { match: 'all', rules: [{ ...DEFAULT_RULE }], sort: 'random', limit: 100 } };
  const playlists = db.listPlaylists();

  const valsHtml = (r, i) => {
    const f = FIELDS[r.field];
    const parts = [];
    if (f.text) parts.push(`<input data-k="value" data-i="${i}" placeholder="text" value="${esc(r.value ?? '')}">`);
    else if (f.playlist) parts.push(`<select data-k="value" data-i="${i}">${playlists.map((pl) => `<option value="${pl.id}" ${+r.value === pl.id ? 'selected' : ''}>${esc(pl.name)}</option>`).join('')}</select>`);
    else if (f.unit && r.op !== 'never') {
      parts.push(`<input type="number" inputmode="numeric" min="0" data-k="value" data-i="${i}" value="${esc(r.value ?? '')}"><span class="faint">${f.unit}</span>`);
      if (f.days) parts.push(`<span class="faint">in</span><input type="number" inputmode="numeric" min="1" data-k="days" data-i="${i}" value="${esc(r.days ?? 30)}"><span class="faint">days</span>`);
      if (f.year) parts.push(`<span class="faint">in</span><input type="number" inputmode="numeric" min="2000" max="2100" data-k="year" data-i="${i}" value="${esc(r.year || new Date().getUTCFullYear())}">`);
    }
    parts.push(`<button class="icon-btn" data-del="${i}" aria-label="Remove rule">${icon('close')}</button>`);
    return parts.join('');
  };

  const count = () => {
    try { return db.smartTracks({ ...st.spec, limit: 5000 }).length; } catch (e) { return '?'; }
  };

  const draw = () => {
    const sp = st.spec;
    el.innerHTML = `<div class="card">
        <input class="nm" placeholder="Name" value="${esc(st.name)}">
        <div class="set-row" style="padding:10px 0 0;min-height:0"><div class="meta"><div class="t1">Songs must match</div></div>
          <select data-top="match"><option value="all" ${sp.match !== 'any' ? 'selected' : ''}>all rules</option><option value="any" ${sp.match === 'any' ? 'selected' : ''}>any rule</option></select></div>
        ${sp.rules.map((r, i) => `<div class="rule">
          <select data-k="field" data-i="${i}">${Object.entries(FIELDS).map(([k, f]) => `<option value="${k}" ${k === r.field ? 'selected' : ''}>${esc(f.label)}</option>`).join('')}</select>
          <select data-k="op" data-i="${i}">${Object.entries(FIELDS[r.field].ops).map(([k, l]) => `<option value="${k}" ${k === r.op ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>
          <div class="vals">${valsHtml(r, i)}</div></div>`).join('')}
        <div class="row-actions" style="padding:10px 0 0"><button class="btn small" data-a="add">${icon('add')}Add rule</button></div>
        <div class="set-row" style="padding:10px 0 0;min-height:0"><div class="meta"><div class="t1">Order</div></div>
          <select data-top="sort">${Object.entries(SORTS).map(([k, l]) => `<option value="${k}" ${k === sp.sort ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
        <div class="set-row" style="padding:10px 0 0;min-height:0"><div class="meta"><div class="t1">At most</div></div>
          <select data-top="limit">${[25, 50, 100, 200, 500, 1000, 5000].map((n) => `<option value="${n}" ${+sp.limit === n ? 'selected' : ''}>${n === 5000 ? 'no limit' : n + ' songs'}</option>`).join('')}</select></div>
      </div>
      <p class="faint count" style="padding:0 16px">${count()} songs match right now</p>
      <div class="row-actions"><button class="btn primary" data-a="save">${icon('check')}Save</button><button class="btn" data-a="cancel">Cancel</button></div>`;
  };

  const refreshCount = () => { const c = el.querySelector('.count'); if (c) c.textContent = `${count()} songs match right now`; };

  el.oninput = (e) => {
    const t = e.target;
    if (t.classList.contains('nm')) { st.name = t.value; return; }
    if (t.dataset.k && t.dataset.k !== 'field' && t.dataset.k !== 'op') {
      const r = st.spec.rules[+t.dataset.i];
      r[t.dataset.k] = t.type === 'number' ? (t.value === '' ? '' : +t.value) : t.value;
      refreshCount();
    }
  };
  el.onchange = (e) => {
    const t = e.target;
    if (t.dataset.top) { st.spec[t.dataset.top] = t.dataset.top === 'limit' ? +t.value : t.value; refreshCount(); return; }
    if (t.dataset.k === 'field') {
      const f = FIELDS[t.value];
      const op = Object.keys(f.ops)[0];
      st.spec.rules[+t.dataset.i] = { field: t.value, op, value: f.unit ? (t.value === 'lastPlayed' || t.value === 'likedAt' ? 90 : 3) : f.playlist ? playlists[0]?.id : '' };
      draw();
    } else if (t.dataset.k === 'op') { st.spec.rules[+t.dataset.i].op = t.value; draw(); }
    else if (t.tagName === 'SELECT' && t.dataset.k === 'value') { st.spec.rules[+t.dataset.i].value = +t.value; refreshCount(); }
  };
  el.onclick = (e) => {
    const del = e.target.closest('[data-del]');
    if (del) { st.spec.rules.splice(+del.dataset.del, 1); draw(); return; }
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'add') { st.spec.rules.push({ ...DEFAULT_RULE }); draw(); }
    if (a === 'cancel') ctx.nav.back();
    if (a === 'save') {
      const name = st.name.trim() || 'Smart playlist';
      if (existing) db.updateSmart(existing.id, { name, spec: st.spec });
      const id = existing ? existing.id : db.createSmart(name, st.spec);
      emitLibraryChanged('playlists');
      toast('Smart playlist saved');
      ctx.nav.back();
      if (!existing) {
        if (ctx.nav.current()?.view === 'smartnew') ctx.nav.back();
        ctx.nav.go('smart', { id });
      }
    }
  };
  draw();
}
