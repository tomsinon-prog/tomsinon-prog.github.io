// Track actions shared by all views: overflow menus, add to playlist/album, choose source, downloads, radio.
import * as bridge from '../core/bridge.js';
import * as db from '../core/db.js';
import * as settings from '../core/settings.js';
import { sheet, toast, prompt, panel, confirmDialog } from './components.js';
import { icon, art, esc } from './dom.js';
import { player } from './player.js';
import { fmtDur } from '../core/util.js';
import { syncOffline } from '../core/offline.js';
import { shareUrl, shareText, parseLink } from '../lib/share-link.js';
import { APP } from '../core/app-info.js';
import { isDesktop, hasEngine } from '../core/platform.js';

export function engineCall(method, args = {}, timeoutMs = 45000) {
  if (!hasEngine()) return Promise.reject(new Error('Needs the app or TuneLab for Windows'));
  return bridge.callAsync('engine.call', { method, args, timeoutMs });
}

/** Library track id for a row: library rows have .id, YouTube results have .videoId. */
export function idOf(t) {
  if (t.id && !t.videoId) return t.id;
  if (t.trackId) return t.trackId;
  return db.ensureYoutubeTrack(t);
}

export function emitLibraryChanged(what) { bridge.emitLocal('library', { what }); }

export async function trackMenu(t, ctx = {}) {
  const isYt = !!t.videoId && !t.id;
  const libId = isYt ? null : (t.id || t.trackId);
  const liked = libId ? db.isLiked(libId) : false;
  const dl = libId ? db.one('SELECT state FROM download WHERE track_id=?', [libId]) : null;
  const items = [
    { icon: 'playNext', label: 'Play next', run: () => { player.cmd('playNext', { trackIds: [idOf(t)] }); toast('Plays next'); } },
    { icon: 'queue', label: 'Add to queue', run: () => { player.cmd('enqueue', { trackIds: [idOf(t)] }); toast('Added to queue'); } },
    { icon: liked ? 'heart' : 'heartO', label: liked ? 'Remove from Liked songs' : 'Like', run: () => toggleLike(idOf(t)) },
    { icon: 'playlistAdd', label: 'Add to playlist', run: () => addToPlaylistFlow([idOf(t)]) },
    { icon: 'album', label: 'Add to My Albums', run: () => addToAlbumFlow([idOf(t)]) },
    dl && dl.state === 'DONE'
      ? { icon: 'trash', label: 'Remove download', run: () => { bridge.call('downloads.delete', { trackIds: [libId] }); toast('Download removed'); emitLibraryChanged('downloads'); } }
      : { icon: 'download', label: dl ? `Download (${dl.state.toLowerCase()})` : 'Download', run: () => download([idOf(t)]) },
    { icon: 'radio', label: 'Start radio', run: () => startRadio(idOf(t)) },
    { icon: 'lyrics', label: 'Sing karaoke', run: () => openKaraoke(idOf(t)) },
  ].filter((x) => !(isDesktop() && /download|karaoke/i.test(x.label)) && !(!hasEngine() && /radio/i.test(x.label)));
  if (!isYt && hasEngine()) items.push({ icon: 'swap', label: 'Choose another source', run: () => chooseSource(libId) });
  if (ctx.entryId && ctx.playlistId) items.push({ icon: 'trash', label: 'Remove from this playlist', danger: true, run: () => { db.removeEntries([ctx.entryId]); emitLibraryChanged('playlist'); } });
  if (ctx.albumEntryId) items.push({ icon: 'trash', label: 'Remove from this album', danger: true, run: () => { db.removeAlbumEntries([ctx.albumEntryId]); emitLibraryChanged('album'); } });
  if (ctx.queueIndex != null) items.push({ icon: 'close', label: 'Remove from queue', danger: true, run: () => player.cmd('remove', { index: ctx.queueIndex }) });
  if (!isYt) items.push({ icon: 'edit', label: 'Edit title / artist', run: () => editTrack(libId) });
  if (t.videoId || libId) items.push({ icon: 'share', label: 'Share', run: () => shareTrack(t, libId) });
  return sheet({ head: { title: t.title || t.name, sub: t.artists || (t.artistsArr || []).join(', ') || t.channel, art: t.artwork_url || t.thumb || t.artwork || null }, items });
}

/** "Restore a backup" / "Open a backup file": pick, confirm, replace the library (a safety copy is kept first). */
export async function restoreBackupFlow() {
  const f = await bridge.callAsync('pick.file', { mimes: ['application/json', 'application/octet-stream', 'text/plain'] });
  if (!f) return false;
  if (!(await confirmDialog({ title: 'Restore this backup?', text: `${f.name}\n\nYour current library is replaced. A safety backup of the current state is saved first.`, ok: 'Restore', danger: true }))) return false;
  try {
    const r = await bridge.callAsync('backup.restore', { uri: f.uri });
    settings.invalidate();
    toast(`Restored: ${Object.entries(r.counts).filter(([k, v]) => v && ['track', 'likes', 'playlist', 'user_album'].includes(k)).map(([k, v]) => `${v} ${{ track: 'songs', likes: 'likes', playlist: 'playlists', user_album: 'albums' }[k]}`).join(', ')}`, { ms: 7000 });
    bridge.emitLocal('library', { what: 'restore' });
    return true;
  } catch (err) { toast('Restore failed: ' + err.message, { ms: 7000 }); return false; }
}

export function toggleLike(trackId) {
  if (db.isLiked(trackId)) { db.unlike(trackId); toast('Removed from Liked songs', { action: 'Undo', onAction: () => { db.like(trackId); emitLibraryChanged('likes'); } }); }
  else { db.like(trackId); toast('Added to Liked songs'); if (settings.get('likesOffline')) offlineSync(); }
  emitLibraryChanged('likes');
  try { player.cmd('refreshMeta', { trackId }); } catch { /* ignore */ }
}

/** Downloads whatever an offline set (offline playlist, liked songs) is still missing. */
export function offlineSync() {
  try { const n = syncOffline(); if (n) emitLibraryChanged('downloads'); return n; } catch (e) { console.warn('offline sync', e); return 0; }
}

export async function addToPlaylistFlow(trackIds) {
  const pls = db.listPlaylists().filter((p) => p.origin === 'APP' || (p.origin === 'SPOTIFY' && p.importable));
  const items = [{ icon: 'add', label: 'New playlist', run: async () => {
    const name = await prompt({ title: 'New playlist', placeholder: 'Name', ok: 'Create' });
    if (!name) return;
    const id = db.createPlaylist(name);
    db.addToPlaylist(id, trackIds);
    toast(`Added to ${name}`);
    emitLibraryChanged('playlists');
  } }];
  for (const p of pls) items.push({ icon: p.offline ? 'downloaded' : 'queue', label: p.name, sub: `${p.n} songs${p.offline ? ' · kept offline' : ''}`, run: () => {
    db.addToPlaylist(p.id, trackIds);
    toast(`Added to ${p.name}`);
    if (p.offline) offlineSync();
    emitLibraryChanged('playlist');
  } });
  return sheet({ head: { title: 'Add to playlist', sub: `${trackIds.length} song${trackIds.length > 1 ? 's' : ''}` }, items });
}

export async function addToAlbumFlow(trackIds) {
  const albums = db.listAlbums();
  const items = [{ icon: 'add', label: 'New album', run: async () => {
    const name = await prompt({ title: 'New album', placeholder: 'Name', ok: 'Create' });
    if (!name) return;
    const id = db.createAlbum(name);
    db.addToAlbum(id, trackIds);
    toast(`Added to ${name}`);
    emitLibraryChanged('albums');
  } }];
  for (const a of albums) items.push({ icon: 'album', label: a.name, sub: `${a.n} songs`, run: () => { db.addToAlbum(a.id, trackIds); toast(`Added to ${a.name}`); emitLibraryChanged('albums'); } });
  return sheet({ head: { title: 'Add to My Albums' }, items });
}

export function download(trackIds) {
  try {
    const r = bridge.call('downloads.enqueue', { trackIds });
    const wifi = settings.get('downloadWifiOnly');
    toast(r.queued ? `${r.queued} download${r.queued > 1 ? 's' : ''} queued${wifi ? ' (Wi-Fi only)' : ''}` : 'Already downloaded');
    emitLibraryChanged('downloads');
  } catch (e) { toast(e.message); }
}

export async function openKaraoke(trackId) {
  const { closeNowPlaying } = await import('./player.js');
  closeNowPlaying();
  globalThis.__tlNav.go('karaoke', { trackId });
}

export function startRadio(trackId) {
  radio({ seedTrackId: trackId, mode: 'track' });
}

/** Starts a radio (track / playlist / artist). It replaces the queue, so offer Undo once it is running. */
export function radio(args) {
  toast('Starting radio…');
  const v0 = player.state.queueVersion;
  let off = null;
  const timer = setTimeout(() => off && off(), 90000);
  off = player.on((s) => {
    if (s.queueVersion === v0 || s.context?.type !== 'radio') return;
    off();
    clearTimeout(timer);
    if (s.canUndo) toast(`${s.context.name || 'Radio'} is playing`, { action: 'Undo', onAction: () => { player.cmd('restoreQueue'); toast('Your queue is back'); } });
  });
  player.cmd('radio', args);
}

async function editTrack(id) {
  const t = db.getTrack(id);
  const title = await prompt({ title: 'Title', value: t.title });
  if (!title) return;
  const artists = await prompt({ title: 'Artist(s)', value: t.artists });
  if (artists == null) return;
  db.updateTrackMeta(id, { title, artists, album: t.album });
  player.cmd('refreshMeta', { trackId: id });
  emitLibraryChanged('track');
}

// ------------------------------------------------------------------ sharing (links that open TuneLab)

function bestVideo(trackId) {
  return db.one("SELECT ref FROM track_source WHERE track_id=? AND kind='YOUTUBE' AND broken=0 ORDER BY chosen DESC, score DESC LIMIT 1", [trackId])?.ref || null;
}

/** Opens Android's share sheet with a link that opens TuneLab for people who have it (YouTube Music for others). */
export async function shareItem(item) {
  try {
    const url = await shareUrl(item, APP.shareBase);
    bridge.call('share', { text: shareText(item, url), subject: item.t || item.n || 'TuneLab' });
  } catch (e) { toast('Could not share: ' + e.message); }
}

async function shareTrack(t, libId) {
  const vid = t.videoId || (libId && bestVideo(libId));
  if (!vid) { toast('This song has no YouTube version yet'); return; }
  const tr = libId ? db.getTrack(libId) : null;
  shareItem({ k: 't', v: vid, t: tr?.title || t.title, a: tr?.artists || t.artists || (t.artistsArr || []).join(', ') || t.channel || '', d: tr?.duration_ms || t.durationMs || 0 });
}

/** Shares a list of library tracks as a playlist link (songs without a YouTube version are left out). */
export function sharePlaylist(name, tracks) {
  const s = [];
  for (const t of tracks) {
    const v = bestVideo(t.id);
    if (v) s.push([v, t.title, t.artists || '', t.duration_ms || 0]);
    if (s.length >= 150) break;
  }
  if (!s.length) { toast('Nothing to share yet'); return; }
  if (tracks.length > 150) toast('The first 150 songs are shared');
  shareItem({ k: 'p', n: name, s });
}

/** A link someone shared (TuneLab link, YouTube / YouTube Music link): play it or open its page. */
export async function openShared(raw) {
  const item = await parseLink(raw, APP.shareBase);
  if (!item) { toast("This link can't be opened in TuneLab"); return; }
  const nav = globalThis.__tlNav;
  if (item.k === 't') {
    let it = item;
    if (!it.t) { try { const d = await engineCall('details', { videoId: it.v }, 20000); it = { ...it, t: d.title, a: d.channel, d: d.durationMs }; } catch { /* play anyway */ } }
    const id = db.ensureYoutubeTrack({ videoId: it.v, title: it.t || 'Shared song', artists: it.a ? [it.a] : [], channel: it.a || '', durationMs: it.d || 0, kind: 'song', thumb: `https://i.ytimg.com/vi/${it.v}/mqdefault.jpg` });
    player.cmd('playTracks', { trackIds: [id], index: 0, context: { type: 'shared', name: 'Shared with you' } });
    toast(`Playing ${it.t || 'the shared song'}`);
    const { openNowPlaying } = await import('./player.js');
    setTimeout(openNowPlaying, 300);
  } else if (item.k === 'a') nav.go('ytalbum', { browseId: item.b, title: item.t || 'Album' });
  else if (item.k === 'r') nav.go('artist', { browseId: item.b, name: item.n || 'Artist' });
  else if (item.k === 'p') nav.go('shared', { item });
}

/** "Choose another source": YouTube alternatives with scores; the choice is remembered (pinned). */
export async function chooseSource(trackId) {
  const t = db.getTrack(trackId);
  if (!t) return;
  const { el, close } = panel(`<div class="sh-head" style="padding:0 0 10px">${art(t.artwork_url)}<div class="meta"><div class="t1">${esc(t.title)}</div><div class="t2">${esc(t.artists)} · ${fmtDur(t.duration_ms)}</div></div></div>
    <div style="display:flex;gap:8px;margin-bottom:8px"><input class="q" placeholder="Search YouTube" value=""><button class="btn small go">${icon('search')}</button></div>
    <div class="res"><p class="muted">Searching YouTube…</p></div>`);
  const res = el.querySelector('.res');
  const q = el.querySelector('.q');
  const load = async (query) => {
    res.innerHTML = '<p class="muted">Searching YouTube…</p>';
    try {
      const r = await engineCall('alternatives', { trackId, query: query || undefined });
      q.value = r.query;
      const cur = new Set(r.current.filter((c) => c.chosen).map((c) => c.ref));
      const best = r.current.slice().sort((a, b) => (b.chosen - a.chosen) || ((b.score || 0) - (a.score || 0)))[0];
      if (best) cur.add(best.ref);
      res.innerHTML = r.candidates.length ? r.candidates.map((c, i) => `<div class="trow static" data-i="${i}">${art(c.thumb)}<div class="meta"><div class="t1">${cur.has(c.videoId) ? '✓ ' : ''}${esc(c.title)}</div>
        <div class="t2">${c.official ? '<span class="badge acc">SONG</span>' : '<span class="badge">VIDEO</span>'}${c.variants?.length ? `<span class="badge warn">${esc(c.variants.join(', ').toUpperCase())}</span>` : ''}<span>${esc(c.channel || (c.artists || []).join(', '))}</span><span class="sep">·</span><span>${fmtDur(c.durationMs)}</span><span class="sep">·</span><span>${Math.round(c.score * 100)}%</span></div></div></div>`).join('')
        : '<p class="muted">No results. Try another search.</p>';
      res.onclick = (e) => {
        const row = e.target.closest('.trow');
        if (!row) return;
        const c = r.candidates[+row.dataset.i];
        db.chooseYoutubeSource(trackId, c);
        player.cmd('reloadSource', { trackId });
        toast('Source saved for this song');
        emitLibraryChanged('track');
        close();
      };
    } catch (e) {
      res.innerHTML = `<div class="banner err">${esc(e.message)}</div>`;
    }
  };
  el.querySelector('.go').addEventListener('click', () => load(q.value.trim()));
  q.addEventListener('keydown', (e) => { if (e.key === 'Enter') load(q.value.trim()); });
  load('');
}

/**
 * Plays a list. Shuffle / smart shuffle start at a random song (unless a row was tapped). Smart shuffle mixes a
 * recommendation in after every N songs; PlaybackService fetches them in the background as the queue plays.
 */
export async function playCollection(ids, { index, shuffle = false, context, smart = false } = {}) {
  if (!ids.length) { toast('Nothing to play'); return; }
  const start = index ?? (shuffle || smart ? Math.floor(Math.random() * ids.length) : 0);
  if (smart) toast(`Smart shuffle: a new song after every ${Math.max(2, settings.get('smartShuffleEvery') || 4)}`);
  player.cmd('playTracks', { trackIds: ids, index: start, shuffle: shuffle || smart, smart, context });
}

export async function confirmDanger(title, text, ok = 'Delete') {
  return confirmDialog({ title, text, ok, danger: true });
}
