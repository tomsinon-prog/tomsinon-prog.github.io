// UI entry: tabs, navigation stack per tab, back handling, theme, insets.
import * as bridge from '../core/bridge.js';
import * as settings from '../core/settings.js';
import { icon, esc, $ } from './dom.js';
import { closeTopOverlay, closeAllOverlays, toast, enhanceSelects } from './components.js';
import { initPlayer, closeNowPlaying, openNowPlaying } from './player.js';
import { isDesktop } from '../core/platform.js';

const VIEWS = {
  home: () => import('./views/home.js'),
  search: () => import('./views/search.js'),
  library: () => import('./views/library.js'),
  downloads: () => import('./views/downloads.js'),
  settings: () => import('./views/settings.js'),
  likes: () => import('./views/collection.js'),
  playlist: () => import('./views/collection.js'),
  myalbum: () => import('./views/collection.js'),
  smart: () => import('./views/collection.js'),
  genre: () => import('./views/collection.js'),
  smartedit: () => import('./views/smart.js'),
  smartnew: () => import('./views/smart.js'),
  releases: () => import('./views/releases.js'),
  shared: () => import('./views/shared.js'),
  history: () => import('./views/library.js'),
  review: () => import('./views/library.js'),
  lostlikes: () => import('./views/library.js'),
  stats: () => import('./views/library.js'),
  ytalbum: () => import('./views/remote.js'),
  artist: () => import('./views/remote.js'),
  diagnostics: () => import('./views/diagnostics.js'),
  equalizer: () => import('./views/settings.js'),
  advanced: () => import('./views/settings.js'),
  offlinesets: () => import('./views/settings.js'),
  spotify: () => import('./views/imports.js'),
  csv: () => import('./views/imports.js'),
  datapkg: () => import('./views/imports.js'),
  local: () => import('./views/imports.js'),
  karaoke: () => import('./views/karaoke.js'),
  recordings: () => import('./views/karaoke.js'),
  transfer: () => import('./views/transfer.js'),
  ytgenre: () => import('./views/explore.js'),
  ytplaylist: () => import('./views/explore.js'),
  following: () => import('./views/explore.js'),
  car: () => import('./views/car.js'),
};

const TABS = [
  { id: 'home', label: 'Home', icon: 'home' },
  { id: 'search', label: 'Search', icon: 'search' },
  { id: 'library', label: 'Library', icon: 'library' },
  { id: 'downloads', label: 'Downloads', icon: 'download' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
].filter((t) => !(t.id === 'downloads' && isDesktop()));

const stacks = Object.fromEntries(TABS.map((t) => [t.id, [{ view: t.id, params: {} }]]));
let tab = 'home';
let cleanup = null;
let backHandler = null;
let renderSeq = 0;

export const nav = {
  go(view, params = {}) {
    const top = stacks[tab][stacks[tab].length - 1];
    top.scroll = $('#view').scrollTop;
    stacks[tab].push({ view, params });
    render();
  },
  back() {
    if (closeTopOverlay()) return true;
    if (closeNowPlaying()) return true;
    if (backHandler && backHandler()) return true; // a view can claim Back (karaoke: stop singing first)
    if (stacks[tab].length > 1) { stacks[tab].pop(); render(true); return true; }
    if (tab !== 'home') { switchTab('home'); return true; }
    return false;
  },
  tab: (id) => switchTab(id),
  refresh: () => render(true),
  current: () => stacks[tab][stacks[tab].length - 1],
};
globalThis.__tlBack = () => nav.back();
globalThis.__tlNav = nav;

function switchTab(id) {
  if (id === tab) {
    if (stacks[tab].length > 1) { stacks[tab].length = 1; render(); }
    else $('#view').scrollTop = 0;
    return;
  }
  stacks[tab][stacks[tab].length - 1].scroll = $('#view').scrollTop;
  tab = id;
  closeAllOverlays();
  render(true);
}

function renderTabs() {
  $('#tabs').innerHTML = TABS.map((t) => `<button data-tab="${t.id}" class="${t.id === tab ? 'on' : ''}">${icon(t.icon)}<span>${t.label}</span></button>`).join('');
}

async function render(restoreScroll = false) {
  const seq = ++renderSeq;
  renderTabs();
  if (cleanup) { try { cleanup(); } catch (e) { console.error(e); } cleanup = null; }
  backHandler = null;
  const entry = stacks[tab][stacks[tab].length - 1];
  const view = $('#view');
  const top = $('#topbar');
  const depth = stacks[tab].length;
  top.innerHTML = `${depth > 1 ? `<button class="icon-btn" id="nav-back">${icon('back')}</button>` : ''}<h1></h1><div id="top-actions"></div>`;
  if (depth > 1) $('#nav-back').onclick = () => nav.back();
  view.innerHTML = '';
  // Views put handlers on #view itself (el.onclick = …). Clear them, or a previous view's handler keeps firing:
  // after Back from an album, tapping a search result also played the album's song at the same row index.
  view.onclick = view.oninput = view.onchange = view.onkeydown = null;
  const ctx = {
    nav,
    setTitle: (t) => { if (seq === renderSeq) top.querySelector('h1').textContent = t; },
    setActions: (html, onClick) => { const a = $('#top-actions'); a.innerHTML = html; a.onclick = onClick; },
    alive: () => seq === renderSeq,
    /** fn() returning true consumes Back (system back, the ← button, tapping the tab again is not affected). */
    setBackHandler: (fn) => { if (seq === renderSeq) backHandler = fn; },
  };
  try {
    const mod = await VIEWS[entry.view]();
    if (seq !== renderSeq) return;
    cleanup = (await mod.render(view, { ...entry.params, view: entry.view }, ctx)) || null;
  } catch (e) {
    console.error(e);
    bridge.log('E', 'ui', `view ${entry.view} failed: ${e.stack || e}`);
    view.innerHTML = `<div class="banner err" style="margin:16px">Something went wrong: ${esc(e.message || e)}</div>`;
  }
  if (seq === renderSeq) view.scrollTop = restoreScroll && entry.scroll ? entry.scroll : 0;
}

// ------------------------------------------------------------------ theme & insets

// Accent colours: [dark theme, light theme (darker, for contrast on white), text on the accent]
export const ACCENTS = {
  mint: ['Mint', '#1ed6a0', '#0a9e74', '#03140d'],
  blue: ['Blue', '#4c9eff', '#1f6fd6', '#04121f'],
  purple: ['Purple', '#a78bfa', '#7c5cdb', '#120a24'],
  pink: ['Pink', '#ff6fae', '#d63a83', '#1f0711'],
  red: ['Red', '#ff5c5c', '#d63333', '#1f0505'],
  orange: ['Orange', '#ff9f43', '#d9770b', '#1f1002'],
  yellow: ['Yellow', '#ffd43b', '#a87d00', '#1a1400'],
  teal: ['Teal', '#2ec4d6', '#108a99', '#021a1d'],
};

function applyTheme() {
  const t = settings.get('theme');
  const dark = t === 'dark' || (t === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const a = ACCENTS[settings.get('accent')] || ACCENTS.mint;
  const st = document.documentElement.style;
  st.setProperty('--acc', dark ? a[1] : a[2]);
  st.setProperty('--acc-fg', dark ? a[3] : '#ffffff');
  st.setProperty('--acc-dark', a[2]); // readable on light surfaces (toasts in the dark theme)
  try { bridge.call('theme', { dark }); } catch { /* tests */ }
}
export { applyTheme };
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

bridge.on('insets', (i) => {
  const s = document.documentElement.style;
  s.setProperty('--top', (i.top || 0) + 'px');
  s.setProperty('--bottom', (i.bottom || 0) + 'px');
});

bridge.on('deeplink', async (url) => {
  if (String(url).startsWith('tunelab://nowplaying')) { openNowPlaying(); return; }
  (await import('./actions.js')).openShared(url); // share links, YouTube links, text shared to TuneLab
});

bridge.on('oauth', async (r) => {
  const m = await import('./views/imports.js');
  await m.finishOAuth(r);
  bridge.emitLocal('spotify', {});
});

bridge.on('job', (j) => {
  if (j.state === 'done' && j.job === 'spotifySync') toast('Spotify import finished: ' + (j.message || ''), { ms: 6000 });
  // background jobs fail quietly (details in the log); only things you started yourself get a message
  if (j.state === 'failed' && ['spotifySync', 'match', 'downloads'].includes(j.job)) toast(`${{ spotifySync: 'Spotify import', match: 'Matching', downloads: 'Downloading' }[j.job]} stopped: ${j.message}`, { ms: 6000 });
});

window.addEventListener('error', (e) => bridge.log('E', 'ui', `${e.message} @${e.filename}:${e.lineno}`));
window.addEventListener('unhandledrejection', (e) => bridge.log('E', 'ui', 'unhandled: ' + (e.reason?.stack || e.reason)));

// ------------------------------------------------------------------ boot

$('#tabs').addEventListener('click', (e) => {
  const b = e.target.closest('[data-tab]');
  if (b) switchTab(b.dataset.tab);
});

applyTheme();
initPlayer();
// every <select> anywhere in the app gets the in-app dropdown instead of Android's picker dialog
new MutationObserver(() => enhanceSelects(document.body)).observe(document.body, { childList: true, subtree: true });
render();
try { bridge.call('ui.ready', {}); } catch { /* tests */ }

// Resume interrupted background work (process killed, Wi-Fi wait expired, ...).
setTimeout(async () => {
  try {
    const db = await import('../core/db.js');
    // Android 13+: job/download progress notifications need this (media controls are exempt). Ask once.
    if (!db.kvGet('ui.askedNotifications') && !bridge.call('permission.has', { name: 'android.permission.POST_NOTIFICATIONS' })) {
      db.kvSet('ui.askedNotifications', '1');
      await bridge.callAsync('permission.request', { name: 'android.permission.POST_NOTIFICATIONS' });
    }
    const net = bridge.call('net.state');
    const queued = db.scalar("SELECT COUNT(*) FROM download WHERE state IN ('QUEUED','RUNNING')") || 0;
    if (queued && (net.wifi || !settings.get('downloadWifiOnly'))) bridge.call('jobs.start', { job: 'downloads' });
    if (settings.get('autoMatch') && db.matchCounts().pending > 0 && db.kvGetJson('spotify.lastSync')) bridge.call('jobs.start', { job: 'match' });
    // Offline playlists / likes: queue whatever is still missing (e.g. songs added on another path).
    (await import('../core/offline.js')).syncOffline();
    // Weekly Discovery (new every Monday) and new releases (a few artists per day), only with some library.
    const { mixDue } = await import('../lib/discover.js');
    const hasLibrary = db.countLikes() + (db.scalar('SELECT COUNT(*) FROM play_event WHERE track_id IS NOT NULL') || 0) >= 5;
    if (hasLibrary && net.online && settings.get('mixEnabled') && mixDue(db.kvGetJson('mix.state', {})?.builtAt)) bridge.call('jobs.start', { job: 'weeklyMix' });
    const rel = db.kvGetJson('releases.state', {}) || {};
    if (hasLibrary && net.online && settings.get('releasesEnabled') && Date.now() - (rel.checkedAt || 0) > 12 * 3600000) bridge.call('jobs.start', { job: 'newReleases' });
    if (hasLibrary && net.online && settings.get('genresEnabled') && db.genresTodo(1).length) bridge.call('jobs.start', { job: 'genres' });
  } catch (e) { bridge.log('W', 'ui', 'resume jobs: ' + e.message); }
}, 4000);
