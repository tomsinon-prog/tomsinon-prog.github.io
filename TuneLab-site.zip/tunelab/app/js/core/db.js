// Library data layer on top of the native SQLite bridge. Synchronous by design (bridge calls are sync).
// The same module runs in the UI WebView, the engine WebView and in Node tests (with a test bridge).
import { call } from './bridge.js';
import { fold, matchKey, sortKey, splitArtists, primaryArtist } from './text.js';
import { compile as compileSmart } from '../lib/smart.js';
import { artistKey, firstArtistName } from '../lib/genres.js';

let impl = {
  query: (sql, args) => call('db.query', { sql, args }),
  exec: (sql, args) => call('db.exec', { sql, args }),
  batch: (ops) => call('db.batch', { ops }),
};

/** Tests swap in a node:sqlite implementation. */
export function setDbImpl(i) { impl = i; }

export const q = (sql, args = []) => impl.query(sql, args);
export const one = (sql, args = []) => impl.query(sql, args)[0] || null;
export const run = (sql, args = []) => impl.exec(sql, args);
export const batch = (ops) => (ops.length ? impl.batch(ops) : []);
export const scalar = (sql, args = []) => { const r = one(sql, args); return r ? Object.values(r)[0] : null; };

const now = () => Date.now();
const placeholders = (n) => new Array(n).fill('?').join(',');

// ------------------------------------------------------------------ settings / kv

export function kvGet(key, def = null) {
  const r = one('SELECT value FROM kv WHERE key=?', [key]);
  return r ? r.value : def;
}
export function kvSet(key, value) {
  run('INSERT OR REPLACE INTO kv(key,value) VALUES(?,?)', [key, value == null ? null : String(value)]);
}
export function kvGetJson(key, def = null) {
  const v = kvGet(key);
  if (v == null) return def;
  try { return JSON.parse(v); } catch { return def; }
}
export function kvSetJson(key, obj) { kvSet(key, JSON.stringify(obj)); }

// ------------------------------------------------------------------ tracks

export const TRACK_COLS = 't.id, t.title, t.artists, t.album, t.duration_ms, t.artwork_url, t.spotify_uri, t.match_state, t.missing_on_spotify';

function trackRowValues(m, origin) {
  const artists = splitArtists(m.artists);
  const artistStr = artists.join(', ');
  return {
    title: m.title || 'Unknown',
    artists: artistStr,
    artists_json: JSON.stringify(artists),
    album: m.album || '',
    duration_ms: Math.round(m.durationMs || 0),
    isrc: m.isrc || null,
    spotify_uri: m.spotifyUri || null,
    artwork_url: m.artwork || null,
    match_key: matchKey(artistStr, m.title || ''),
    sort_title: sortKey(m.title || ''),
    sort_artist: sortKey(artistStr),
    origin: origin || m.origin || 'APP',
  };
}

/**
 * Insert or update tracks keyed by Spotify URI (idempotent). Returns Map(spotifyUri -> trackId).
 * Existing metadata is refreshed; local data (likes, sources, match state) is never touched.
 */
export function upsertSpotifyTracks(metas, origin = 'SPOTIFY', seenAt = now()) {
  const out = new Map();
  const list = metas.filter((m) => m && m.spotifyUri);
  for (let i = 0; i < list.length; i += 200) {
    const part = list.slice(i, i + 200);
    const ops = part.map((m) => {
      const v = trackRowValues(m, origin);
      const t = now();
      return {
        sql: `INSERT INTO track(title,artists,artists_json,album,duration_ms,isrc,spotify_uri,artwork_url,match_key,sort_title,sort_artist,origin,spotify_seen_at,missing_on_spotify,created_at,updated_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?)
              ON CONFLICT(spotify_uri) DO UPDATE SET title=excluded.title, artists=excluded.artists, artists_json=excluded.artists_json,
                album=excluded.album, duration_ms=CASE WHEN excluded.duration_ms>0 THEN excluded.duration_ms ELSE track.duration_ms END,
                isrc=COALESCE(excluded.isrc, track.isrc), artwork_url=COALESCE(excluded.artwork_url, track.artwork_url),
                match_key=excluded.match_key, sort_title=excluded.sort_title, sort_artist=excluded.sort_artist,
                spotify_seen_at=excluded.spotify_seen_at, missing_on_spotify=0, updated_at=excluded.updated_at`,
        args: [v.title, v.artists, v.artists_json, v.album, v.duration_ms, v.isrc, v.spotify_uri, v.artwork_url, v.match_key, v.sort_title, v.sort_artist, v.origin, seenAt, t, t],
      };
    });
    batch(ops);
    const uris = part.map((m) => m.spotifyUri);
    for (const r of q(`SELECT id, spotify_uri FROM track WHERE spotify_uri IN (${placeholders(uris.length)})`, uris)) out.set(r.spotify_uri, r.id);
  }
  return out;
}

/** Track without Spotify URI (CSV without URI, data package without URI, manual): dedupe on match key + duration. */
export function ensureTrackByMeta(m, origin = 'APP') {
  if (m.spotifyUri) return upsertSpotifyTracks([m], origin).get(m.spotifyUri);
  const v = trackRowValues(m, origin);
  const ex = one('SELECT id FROM track WHERE match_key=? AND (duration_ms=0 OR ?=0 OR ABS(duration_ms-?)<6000) ORDER BY id LIMIT 1', [v.match_key, v.duration_ms, v.duration_ms]);
  if (ex) return ex.id;
  const t = now();
  return run(`INSERT INTO track(title,artists,artists_json,album,duration_ms,isrc,artwork_url,match_key,sort_title,sort_artist,origin,created_at,updated_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
  [v.title, v.artists, v.artists_json, v.album, v.duration_ms, v.isrc, v.artwork_url, v.match_key, v.sort_title, v.sort_artist, v.origin, t, t]).lastId;
}

/** A YouTube result the user played/liked/added: reuse the track that already has this video, else create one. */
export function ensureYoutubeTrack(it) {
  const ex = one("SELECT track_id FROM track_source WHERE kind='YOUTUBE' AND ref=? ORDER BY chosen DESC, score DESC LIMIT 1", [it.videoId]);
  if (ex) return ex.track_id;
  const v = trackRowValues({ title: it.title, artists: it.artists?.length ? it.artists : [it.channel || ''], album: it.album, durationMs: it.durationMs, artwork: it.thumb }, 'YOUTUBE');
  const t = now();
  const id = run(`INSERT INTO track(title,artists,artists_json,album,duration_ms,artwork_url,match_key,sort_title,sort_artist,origin,match_state,match_score,created_at,updated_at)
                  VALUES(?,?,?,?,?,?,?,?,?,?,'MATCHED',1,?,?)`,
  [v.title, v.artists, v.artists_json, v.album, v.duration_ms, v.artwork_url, v.match_key, v.sort_title, v.sort_artist, 'YOUTUBE', t, t]).lastId;
  addYoutubeSource(id, it, { chosen: 1, score: 1 });
  return id;
}

export function addYoutubeSource(trackId, it, { chosen = 0, score = null } = {}) {
  run(`INSERT INTO track_source(track_id,kind,ref,title,channel,duration_ms,thumb,score,is_topic,chosen,created_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?)
       ON CONFLICT(track_id,kind,ref) DO UPDATE SET score=COALESCE(excluded.score, track_source.score), chosen=MAX(track_source.chosen, excluded.chosen), broken=0`,
  [trackId, 'YOUTUBE', it.videoId, it.title || null, it.channel || (it.artists || []).join(', ') || null, Math.round(it.durationMs || 0) || null,
    it.thumb || null, score, it.isTopic || it.kind === 'song' ? 1 : 0, chosen, now()]);
}

/** "Choose another source": pin this video for the track and remember it. */
export function chooseYoutubeSource(trackId, it) {
  batch([
    { sql: "UPDATE track_source SET chosen=0 WHERE track_id=? AND kind='YOUTUBE'", args: [trackId] },
  ]);
  addYoutubeSource(trackId, it, { chosen: 1, score: it.score ?? null });
  run("UPDATE track_source SET chosen=1, broken=0 WHERE track_id=? AND kind='YOUTUBE' AND ref=?", [trackId, it.videoId]);
  run("UPDATE track SET match_state='MANUAL', match_score=?, updated_at=? WHERE id=?", [it.score ?? 1, now(), trackId]);
  run('DELETE FROM resolved_url WHERE video_id=?', [it.videoId]);
}

export function getTrack(id) {
  return one(`SELECT ${TRACK_COLS}, t.isrc, t.match_score, t.origin, t.match_key,
      EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) liked,
      (SELECT kind FROM track_source s WHERE s.track_id=t.id AND s.broken=0 ORDER BY CASE kind WHEN 'LOCAL_FILE' THEN 0 WHEN 'DOWNLOADED' THEN 1 ELSE 2 END LIMIT 1) best_source
      FROM track t WHERE t.id=?`, [id]);
}

export function getSources(trackId) {
  return q('SELECT * FROM track_source WHERE track_id=? ORDER BY CASE kind WHEN \'LOCAL_FILE\' THEN 0 WHEN \'DOWNLOADED\' THEN 1 ELSE 2 END, chosen DESC, score DESC', [trackId]);
}

export function updateTrackMeta(id, { title, artists, album }) {
  const v = trackRowValues({ title, artists, album }, 'APP');
  run('UPDATE track SET title=?, artists=?, artists_json=?, album=?, match_key=?, sort_title=?, sort_artist=?, updated_at=? WHERE id=?',
    [v.title, v.artists, v.artists_json, v.album, v.match_key, v.sort_title, v.sort_artist, now(), id]);
}

// ------------------------------------------------------------------ list queries (shared shape)

const SORTS = {
  added: 'added_at DESC',
  title: 't.sort_title COLLATE NOCASE ASC',
  artist: 't.sort_artist COLLATE NOCASE ASC, t.sort_title ASC',
  album: 't.album COLLATE NOCASE ASC',
  duration: 't.duration_ms DESC',
  position: 'position ASC',
};

function filterSql(filter, args) {
  if (!filter) return '';
  const f = '%' + fold(filter) + '%';
  args.push(f, f, f);
  return ' AND (t.sort_title LIKE ? OR t.sort_artist LIKE ? OR t.match_key LIKE ?)';
}

function availabilitySql(offline) {
  if (!offline) return '';
  return " AND (EXISTS(SELECT 1 FROM track_source s WHERE s.track_id=t.id AND s.kind IN ('LOCAL_FILE','DOWNLOADED') AND s.broken=0)"
    + " OR EXISTS(SELECT 1 FROM track_source s JOIN audio_cache c ON c.key='yt_'||s.ref WHERE s.track_id=t.id AND s.kind='YOUTUBE'))";
}

const EXTRA = `,(SELECT kind FROM track_source s WHERE s.track_id=t.id AND s.broken=0 ORDER BY CASE kind WHEN 'LOCAL_FILE' THEN 0 WHEN 'DOWNLOADED' THEN 1 ELSE 2 END LIMIT 1) best_source`;

export function listLikes({ sort = 'added', filter = '', offline = false } = {}) {
  const args = [];
  const sql = `SELECT ${TRACK_COLS}, l.liked_at added_at, 1 liked ${EXTRA} FROM likes l JOIN track t ON t.id=l.track_id WHERE 1=1`
    + filterSql(filter, args) + availabilitySql(offline) + ` ORDER BY ${SORTS[sort] || SORTS.added}`;
  return q(sql, args);
}

export function countLikes() { return scalar('SELECT COUNT(*) n FROM likes') || 0; }

export function like(trackId, origin = 'APP') {
  run('INSERT OR IGNORE INTO likes(track_id,liked_at,origin) VALUES(?,?,?)', [trackId, now(), origin]);
}
export function unlike(trackId) { run('DELETE FROM likes WHERE track_id=?', [trackId]); }
export function isLiked(trackId) { return !!one('SELECT 1 x FROM likes WHERE track_id=?', [trackId]); }
export function likeMany(ids) {
  const t = now();
  batch(ids.map((id, i) => ({ sql: "INSERT OR IGNORE INTO likes(track_id,liked_at,origin) VALUES(?,?,'APP')", args: [id, t + i] })));
}

// ------------------------------------------------------------------ playlists

export function listPlaylists() {
  return q(`SELECT p.*, (SELECT COUNT(*) FROM playlist_entry e WHERE e.playlist_id=p.id) n,
      (SELECT COALESCE(SUM(t.duration_ms),0) FROM playlist_entry e JOIN track t ON t.id=e.track_id WHERE e.playlist_id=p.id) total_ms,
      (SELECT t.artwork_url FROM playlist_entry e JOIN track t ON t.id=e.track_id WHERE e.playlist_id=p.id AND t.artwork_url IS NOT NULL ORDER BY e.position LIMIT 1) cover
      FROM playlist p ORDER BY p.importable DESC, p.position, p.name COLLATE NOCASE`);
}

export function getPlaylist(id) { return one('SELECT * FROM playlist WHERE id=?', [id]); }

export function createPlaylist(name, description = '') {
  const t = now();
  const pos = (scalar('SELECT COALESCE(MAX(position),0) FROM playlist') || 0) + 1;
  return run('INSERT INTO playlist(name,description,origin,position,created_at,updated_at) VALUES(?,?,?,?,?,?)', [name, description, 'APP', pos, t, t]).lastId;
}
export function renamePlaylist(id, name) { run('UPDATE playlist SET name=?, updated_at=? WHERE id=?', [name, now(), id]); }
export function deletePlaylist(id) {
  batch([{ sql: 'DELETE FROM playlist_entry WHERE playlist_id=?', args: [id] }, { sql: 'DELETE FROM playlist WHERE id=?', args: [id] }]);
}
export function reorderPlaylists(ids) {
  batch(ids.map((id, i) => ({ sql: 'UPDATE playlist SET position=? WHERE id=?', args: [i + 1, id] })));
}

export function playlistEntries(id, { sort = 'position', filter = '', offline = false } = {}) {
  const args = [id];
  const sql = `SELECT ${TRACK_COLS}, e.id entry_id, e.position, e.added_at, e.missing_on_spotify entry_missing,
      EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) liked ${EXTRA}
      FROM playlist_entry e JOIN track t ON t.id=e.track_id WHERE e.playlist_id=?`
    + filterSql(filter, args) + availabilitySql(offline) + ` ORDER BY ${sort === 'added' ? 'e.added_at DESC' : (SORTS[sort] || SORTS.position)}`;
  return q(sql, args);
}

export function addToPlaylist(playlistId, trackIds) {
  let pos = (scalar('SELECT COALESCE(MAX(position),0) FROM playlist_entry WHERE playlist_id=?', [playlistId]) || 0);
  const t = now();
  batch(trackIds.map((tid) => ({ sql: 'INSERT INTO playlist_entry(playlist_id,track_id,position,added_at) VALUES(?,?,?,?)', args: [playlistId, tid, ++pos, t] })));
  run('UPDATE playlist SET updated_at=? WHERE id=?', [t, playlistId]);
}

export function removeEntries(entryIds) {
  batch(entryIds.map((id) => ({ sql: 'DELETE FROM playlist_entry WHERE id=?', args: [id] })));
}

/** Moves an entry so it ends up at index `to` in the position-ordered list (renumbers the playlist). */
export function moveEntry(playlistId, entryId, to) {
  const ids = q('SELECT id FROM playlist_entry WHERE playlist_id=? ORDER BY position, id', [playlistId]).map((r) => r.id);
  const from = ids.indexOf(entryId);
  if (from < 0) return;
  ids.splice(from, 1);
  ids.splice(Math.max(0, Math.min(ids.length, to)), 0, entryId);
  batch(ids.map((id, i) => ({ sql: 'UPDATE playlist_entry SET position=? WHERE id=?', args: [i + 1, id] })));
}

// ------------------------------------------------------------------ My Albums (user collections)

export function listAlbums() {
  return q(`SELECT a.*, (SELECT COUNT(*) FROM user_album_entry e WHERE e.album_id=a.id) n,
      COALESCE(a.artwork_url, (SELECT t.artwork_url FROM user_album_entry e JOIN track t ON t.id=e.track_id WHERE e.album_id=a.id AND t.artwork_url IS NOT NULL ORDER BY e.position LIMIT 1)) cover
      FROM user_album a ORDER BY a.name COLLATE NOCASE`);
}
export function getAlbum(id) { return one('SELECT * FROM user_album WHERE id=?', [id]); }
export function createAlbum(name) {
  const t = now();
  return run('INSERT INTO user_album(name,created_at,updated_at) VALUES(?,?,?)', [name, t, t]).lastId;
}
export function renameAlbum(id, name) { run('UPDATE user_album SET name=?, updated_at=? WHERE id=?', [name, now(), id]); }
export function deleteAlbum(id) {
  batch([{ sql: 'DELETE FROM user_album_entry WHERE album_id=?', args: [id] }, { sql: 'DELETE FROM user_album WHERE id=?', args: [id] }]);
}
export function albumEntries(id, { filter = '', offline = false } = {}) {
  const args = [id];
  return q(`SELECT ${TRACK_COLS}, e.id entry_id, e.position, EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) liked ${EXTRA}
      FROM user_album_entry e JOIN track t ON t.id=e.track_id WHERE e.album_id=?` + filterSql(filter, args) + availabilitySql(offline)
      + ' ORDER BY e.position', args);
}
export function addToAlbum(albumId, trackIds) {
  let pos = scalar('SELECT COALESCE(MAX(position),0) FROM user_album_entry WHERE album_id=?', [albumId]) || 0;
  const t = now();
  batch(trackIds.map((tid) => ({ sql: 'INSERT INTO user_album_entry(album_id,track_id,position,added_at) VALUES(?,?,?,?)', args: [albumId, tid, ++pos, t] })));
}
export function removeAlbumEntries(entryIds) {
  batch(entryIds.map((id) => ({ sql: 'DELETE FROM user_album_entry WHERE id=?', args: [id] })));
}
export function moveAlbumEntry(albumId, entryId, to) {
  const ids = q('SELECT id FROM user_album_entry WHERE album_id=? ORDER BY position, id', [albumId]).map((r) => r.id);
  const from = ids.indexOf(entryId);
  if (from < 0) return;
  ids.splice(from, 1);
  ids.splice(Math.max(0, Math.min(ids.length, to)), 0, entryId);
  batch(ids.map((id, i) => ({ sql: 'UPDATE user_album_entry SET position=? WHERE id=?', args: [i + 1, id] })));
}

// ------------------------------------------------------------------ history & stats

export function recentlyPlayed(limit = 50) {
  return q(`SELECT ${TRACK_COLS}, r.last_ts added_at, EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) liked ${EXTRA}
      FROM (SELECT track_id, MAX(ts) last_ts FROM play_event WHERE track_id IS NOT NULL GROUP BY track_id ORDER BY last_ts DESC LIMIT ?) r
      JOIN track t ON t.id=r.track_id ORDER BY r.last_ts DESC`, [limit]);
}

export function historyEvents({ limit = 300, offset = 0 } = {}) {
  return q(`SELECT e.id, e.ts, e.ms_played, e.skipped, e.origin, COALESCE(t.title, e.track_name) title, COALESCE(t.artists, e.artist_name) artists,
      t.id track_id, t.artwork_url, t.duration_ms FROM play_event e LEFT JOIN track t ON t.id=e.track_id ORDER BY e.ts DESC LIMIT ? OFFSET ?`, [limit, offset]);
}

export function stats({ year = null } = {}) {
  const range = year ? [Date.UTC(year, 0, 1), Date.UTC(year + 1, 0, 1)] : [0, 8.64e15];
  const where = 'e.ts>=? AND e.ts<? AND e.ms_played>=30000';
  const totals = one(`SELECT COUNT(*) plays, COALESCE(SUM(e.ms_played),0) ms, COUNT(DISTINCT COALESCE(e.track_id, e.spotify_track_uri, e.artist_name||'|'||e.track_name)) tracks
      FROM play_event e WHERE ${where}`, range);
  const topTracks = q(`SELECT COALESCE(t.title,e.track_name) title, COALESCE(t.artists,e.artist_name) artists, t.id track_id, t.artwork_url,
      COUNT(*) plays, SUM(e.ms_played) ms FROM play_event e LEFT JOIN track t ON t.id=e.track_id WHERE ${where}
      GROUP BY COALESCE(CAST(e.track_id AS TEXT), e.spotify_track_uri, e.artist_name||'|'||e.track_name) ORDER BY plays DESC LIMIT 50`, range);
  const topArtists = q(`SELECT COALESCE(e.artist_name, t.artists) artist, COUNT(*) plays, SUM(e.ms_played) ms
      FROM play_event e LEFT JOIN track t ON t.id=e.track_id WHERE ${where} GROUP BY LOWER(COALESCE(e.artist_name, t.artists)) ORDER BY plays DESC LIMIT 50`, range);
  const years = q(`SELECT CAST(strftime('%Y', e.ts/1000, 'unixepoch') AS INTEGER) year, COUNT(*) plays FROM play_event e
      WHERE e.ms_played>=30000 GROUP BY year ORDER BY year DESC`);
  return { totals, topTracks, topArtists, years };
}

/** Tracks played often (>= minPlays plays of >= 30 s) that are not liked: candidates for "possibly lost likes". */
export function possiblyLostLikes(minPlays = 5) {
  return q(`SELECT ${TRACK_COLS}, x.plays, x.last_ts FROM
      (SELECT track_id, COUNT(*) plays, MAX(ts) last_ts FROM play_event WHERE ms_played>=30000 AND track_id IS NOT NULL GROUP BY track_id HAVING COUNT(*)>=?) x
      JOIN track t ON t.id=x.track_id WHERE NOT EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) ORDER BY x.plays DESC`, [minPlays]);
}

// ------------------------------------------------------------------ matching / review

export function matchCounts() {
  const rows = q('SELECT match_state s, COUNT(*) n FROM track GROUP BY match_state');
  const o = { NONE: 0, MATCHED: 0, REVIEW: 0, FAILED: 0, MANUAL: 0, NOT_NEEDED: 0, DEFERRED: 0 };
  for (const r of rows) o[r.s] = r.n;
  o.pending = scalar("SELECT COUNT(*) FROM track t WHERE t.match_state='NONE' AND NOT EXISTS(SELECT 1 FROM track_source s WHERE s.track_id=t.id)") || 0;
  return o;
}

export function reviewList() {
  return q(`SELECT ${TRACK_COLS}, t.match_score,
      (SELECT ref FROM track_source s WHERE s.track_id=t.id AND s.kind='YOUTUBE' ORDER BY chosen DESC, score DESC LIMIT 1) video_id
      FROM track t WHERE t.match_state IN ('REVIEW','FAILED') ORDER BY t.match_state DESC, t.sort_artist, t.sort_title`);
}

export function candidates(trackId) {
  return q('SELECT * FROM match_candidate WHERE track_id=? ORDER BY score DESC', [trackId]);
}

export function acceptMatch(trackId) {
  run("UPDATE track SET match_state='MANUAL', updated_at=? WHERE id=?", [now(), trackId]);
}

export function retryFailedMatches() {
  run("UPDATE track SET match_state='NONE' WHERE match_state IN ('FAILED','DEFERRED') AND NOT EXISTS(SELECT 1 FROM track_source s WHERE s.track_id=track.id)");
}

// ------------------------------------------------------------------ search in library

export function searchLibrary(query, limit = 25) {
  const f = '%' + fold(query) + '%';
  const words = fold(query).split(' ').filter(Boolean);
  if (!words.length) return { tracks: [], playlists: [] };
  // every word must appear in title or artist
  const cond = words.map(() => "(t.sort_title || ' ' || t.sort_artist || ' ' || LOWER(t.album)) LIKE ?").join(' AND ');
  const args = words.map((w) => `%${w}%`);
  const tracks = q(`SELECT ${TRACK_COLS}, EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) liked ${EXTRA},
      (EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) OR EXISTS(SELECT 1 FROM playlist_entry e WHERE e.track_id=t.id)
       OR EXISTS(SELECT 1 FROM track_source s WHERE s.track_id=t.id AND s.kind IN ('LOCAL_FILE','DOWNLOADED'))) in_lib
      FROM track t WHERE ${cond} ORDER BY in_lib DESC, (t.sort_title LIKE ?) DESC, t.sort_title LIMIT ?`, [...args, f, limit]);
  const playlists = q('SELECT id, name FROM playlist WHERE LOWER(name) LIKE ? LIMIT 5', ['%' + String(query).toLowerCase() + '%']);
  return { tracks: tracks.filter((t) => t.in_lib), playlists };
}

/** Sets used by radio filtering. */
export function libraryKeys() {
  return new Set(q(`SELECT t.match_key k FROM track t WHERE EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id)
      OR EXISTS(SELECT 1 FROM playlist_entry e WHERE e.track_id=t.id) OR EXISTS(SELECT 1 FROM play_event p WHERE p.track_id=t.id AND p.ms_played>=30000)`).map((r) => r.k));
}

/** For search results: which videos are already in the library, liked or downloaded. Map(videoId -> info). */
export function youtubeStatus(videoIds) {
  const out = new Map();
  const ids = [...new Set(videoIds.filter(Boolean))];
  if (!ids.length) return out;
  const rows = q(`SELECT s.ref, s.track_id, EXISTS(SELECT 1 FROM likes l WHERE l.track_id=s.track_id) liked,
      (SELECT d.state FROM download d WHERE d.track_id=s.track_id) dl, (SELECT d.progress FROM download d WHERE d.track_id=s.track_id) progress
      FROM track_source s WHERE s.kind='YOUTUBE' AND s.ref IN (${placeholders(ids.length)})`, ids);
  for (const r of rows) {
    const prev = out.get(r.ref);
    if (!prev || r.liked || r.dl) out.set(r.ref, r);
  }
  return out;
}

// ------------------------------------------------------------------ offline sets (playlists / likes kept downloaded)

export function setPlaylistOffline(id, on) { run('UPDATE playlist SET offline=?, updated_at=? WHERE id=?', [on ? 1 : 0, now(), id]); }

/** Tracks that should be downloaded (offline playlists, likes when likesOffline) but have no download row yet. */
export function offlineMissing({ likes = false } = {}) {
  return q(`SELECT DISTINCT x.track_id id FROM (
      SELECT e.track_id FROM playlist_entry e JOIN playlist p ON p.id=e.playlist_id WHERE p.offline=1
      UNION SELECT track_id FROM likes WHERE ?=1) x
    WHERE NOT EXISTS(SELECT 1 FROM download d WHERE d.track_id=x.track_id)
      AND NOT EXISTS(SELECT 1 FROM track_source s WHERE s.track_id=x.track_id AND s.kind='LOCAL_FILE' AND s.broken=0)
    ORDER BY x.track_id`, [likes ? 1 : 0]).map((r) => r.id);
}

/**
 * Of `trackIds`, the downloaded ones no other offline set needs (used when an offline playlist is switched off).
 * strict: also keep songs that are liked or in any other playlist / My Album (used when the weekly mix is replaced).
 */
export function offlineOrphans(trackIds, { exceptPlaylistId = 0, likes = false, strict = false } = {}) {
  const ids = [...new Set(trackIds)];
  const out = [];
  for (let i = 0; i < ids.length; i += 400) {
    const part = ids.slice(i, i + 400);
    out.push(...q(`SELECT d.track_id id FROM download d WHERE d.track_id IN (${placeholders(part.length)})
      AND NOT EXISTS(SELECT 1 FROM playlist_entry e JOIN playlist p ON p.id=e.playlist_id WHERE e.track_id=d.track_id AND p.id<>? AND (p.offline=1 OR ?=1))
      AND NOT (?=1 AND EXISTS(SELECT 1 FROM likes l WHERE l.track_id=d.track_id))
      AND NOT (?=1 AND EXISTS(SELECT 1 FROM user_album_entry a WHERE a.track_id=d.track_id))`,
    [...part, exceptPlaylistId, strict ? 1 : 0, likes || strict ? 1 : 0, strict ? 1 : 0]).map((r) => r.id));
  }
  return out;
}

/** {n, done} for an offline playlist header ("12 of 40 downloaded"). */
export function playlistOfflineState(id) {
  return one(`SELECT COUNT(DISTINCT e.track_id) n, COUNT(DISTINCT CASE WHEN d.state='DONE' OR s.id IS NOT NULL THEN e.track_id END) done
    FROM playlist_entry e LEFT JOIN download d ON d.track_id=e.track_id
    LEFT JOIN track_source s ON s.track_id=e.track_id AND s.kind='LOCAL_FILE' AND s.broken=0 WHERE e.playlist_id=?`, [id]) || { n: 0, done: 0 };
}

export function likesOfflineState() {
  return one(`SELECT COUNT(*) n, SUM(CASE WHEN EXISTS(SELECT 1 FROM download d WHERE d.track_id=l.track_id AND d.state='DONE')
      OR EXISTS(SELECT 1 FROM track_source s WHERE s.track_id=l.track_id AND s.kind='LOCAL_FILE' AND s.broken=0) THEN 1 ELSE 0 END) done FROM likes l`) || { n: 0, done: 0 };
}

// ------------------------------------------------------------------ weekly discovery mix (a playlist with origin 'MIX')

export const MIX_NAME = 'Weekly Discovery';

export function mixPlaylist() { return one("SELECT * FROM playlist WHERE origin='MIX' ORDER BY id LIMIT 1"); }

/** Replaces the mix contents. Returns {id, oldTrackIds}. `offline` = keep the whole mix downloaded (setting mixOffline). */
export function replaceMix(trackIds, { offline = true, description = '' } = {}) {
  const t = now();
  let pl = mixPlaylist();
  if (!pl) {
    const id = run("INSERT INTO playlist(name,description,origin,position,offline,created_at,updated_at) VALUES(?,?,'MIX',-1,?,?,?)", [MIX_NAME, description, offline ? 1 : 0, t, t]).lastId;
    pl = { id };
  }
  const oldTrackIds = q('SELECT track_id FROM playlist_entry WHERE playlist_id=?', [pl.id]).map((r) => r.track_id);
  batch([
    { sql: 'DELETE FROM playlist_entry WHERE playlist_id=?', args: [pl.id] },
    ...trackIds.map((tid, i) => ({ sql: 'INSERT INTO playlist_entry(playlist_id,track_id,position,added_at) VALUES(?,?,?,?)', args: [pl.id, tid, i + 1, t] })),
    { sql: 'UPDATE playlist SET description=?, offline=?, updated_at=? WHERE id=?', args: [description, offline ? 1 : 0, t, pl.id] },
  ]);
  return { id: pl.id, oldTrackIds };
}

// ------------------------------------------------------------------ smart playlists

export function listSmart() { return q('SELECT * FROM smart_playlist ORDER BY position, name COLLATE NOCASE'); }
export function getSmart(id) {
  const r = one('SELECT * FROM smart_playlist WHERE id=?', [id]);
  if (!r) return null;
  try { r.spec = JSON.parse(r.rules); } catch { r.spec = { rules: [], sort: 'random', limit: 100 }; }
  return r;
}
export function createSmart(name, spec) {
  const t = now();
  return run('INSERT INTO smart_playlist(name,rules,position,created_at,updated_at) VALUES(?,?,?,?,?)', [name, JSON.stringify(spec), (scalar('SELECT COALESCE(MAX(position),0) FROM smart_playlist') || 0) + 1, t, t]).lastId;
}
export function updateSmart(id, { name, spec }) {
  const cur = getSmart(id);
  if (!cur) return;
  run('UPDATE smart_playlist SET name=?, rules=?, updated_at=? WHERE id=?', [name ?? cur.name, JSON.stringify(spec ?? cur.spec), now(), id]);
}
export function deleteSmart(id) { run('DELETE FROM smart_playlist WHERE id=?', [id]); }

/** Runs a smart playlist spec (see lib/smart.js). */
export function smartTracks(spec, { filter = '', offline = false, nowMs = now() } = {}) {
  const { sql, args } = compileSmart(spec, { now: nowMs, cols: TRACK_COLS + EXTRA });
  let rows = q(sql, args);
  if (filter) { const f = fold(filter); rows = rows.filter((t) => fold(`${t.title} ${t.artists} ${t.album}`).includes(f)); }
  if (offline) rows = rows.filter((t) => t.best_source === 'LOCAL_FILE' || t.best_source === 'DOWNLOADED');
  return rows;
}

// ------------------------------------------------------------------ new releases of followed artists

export function listReleases({ limit = 30, sinceMs = now() - 90 * 86400000, year = new Date().getUTCFullYear() } = {}) {
  return q(`SELECT * FROM artist_release WHERE dismissed=0 AND ((baseline=0 AND first_seen>=?) OR (baseline=1 AND year>=?))
    ORDER BY baseline ASC, first_seen DESC, year DESC, title LIMIT ?`, [sinceMs, year, limit]);
}
export function dismissRelease(browseId) { run('UPDATE artist_release SET dismissed=1 WHERE browse_id=?', [browseId]); }

// ------------------------------------------------------------------ artists you have / follow (0.10)

/** primaryArtist keys of every artist in the library (liked, in a playlist or album, played ≥ 30 s) or followed. */
export function knownArtistKeys() {
  const keys = new Set();
  const rows = q(`SELECT DISTINCT t.artists FROM track t WHERE EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id)
    OR EXISTS(SELECT 1 FROM playlist_entry e WHERE e.track_id=t.id) OR EXISTS(SELECT 1 FROM user_album_entry u WHERE u.track_id=t.id)
    OR EXISTS(SELECT 1 FROM play_event p WHERE p.track_id=t.id AND p.ms_played>=30000)`);
  for (const r of rows) { const k = primaryArtist(r.artists); if (k) keys.add(k); }
  for (const r of q('SELECT key FROM artist_follow WHERE manual=1')) keys.add(r.key);
  return keys;
}

export function isFollowed(name) {
  return !!one('SELECT 1 x FROM artist_follow WHERE key=? AND manual=1', [primaryArtist(name)]);
}

/** Follow an artist (their new releases show up in New releases). */
export function followArtist({ name, browseId = null, thumb = null }) {
  const key = primaryArtist(name);
  if (!key) return;
  run(`INSERT INTO artist_follow(key,name,browse_id,thumb,score,manual,followed_at) VALUES(?,?,?,?,0,1,?)
    ON CONFLICT(key) DO UPDATE SET manual=1, muted=0, followed_at=excluded.followed_at,
      browse_id=COALESCE(excluded.browse_id, browse_id), thumb=COALESCE(excluded.thumb, thumb)`, [key, name, browseId, thumb, Date.now()]);
}

export function unfollowArtist(name) { run('UPDATE artist_follow SET manual=0 WHERE key=?', [primaryArtist(name)]); }

export function listFollowed() {
  return q('SELECT key,name,browse_id,thumb,followed_at FROM artist_follow WHERE manual=1 ORDER BY followed_at DESC');
}

// ------------------------------------------------------------------ genres (per primary artist)

/** Map(artistKey -> ['Rock', …]). */
export function genreMap() {
  const m = new Map();
  for (const r of q("SELECT key, genres FROM artist_genre WHERE genres<>''")) m.set(r.key, r.genres.split('|'));
  return m;
}

/** Genres of one track row (uses `map` from genreMap()). */
export const genresOf = (t, map) => map.get(artistKey(t.artists)) || [];

/** Library artists that have no genre lookup yet (or a failed one that is due again). */
export function genresTodo(limit = 150) {
  const rows = q(`SELECT DISTINCT t.artists FROM track t WHERE t.artists<>'' AND (EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id)
      OR EXISTS(SELECT 1 FROM playlist_entry e WHERE e.track_id=t.id) OR EXISTS(SELECT 1 FROM user_album_entry a WHERE a.track_id=t.id)
      OR EXISTS(SELECT 1 FROM play_event p WHERE p.track_id=t.id))`);
  const known = new Map(q('SELECT key, checked_at FROM artist_genre').map((r) => [r.key, r.checked_at]));
  const due = now() - 120 * 86400000;
  const out = [], seen = new Set();
  for (const r of rows) {
    const key = artistKey(r.artists);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    if (known.has(key) && known.get(key) > due) continue;
    out.push({ key, name: firstArtistName(r.artists) });
    if (out.length >= limit) break;
  }
  return out;
}

export function setArtistGenre(key, name, genres, tags, mbid, checkedAt = now()) {
  run('INSERT OR REPLACE INTO artist_genre(key,name,genres,tags,mbid,checked_at) VALUES(?,?,?,?,?,?)',
    [key, name, (genres || []).join('|'), tags ? JSON.stringify(tags) : null, mbid || null, checkedAt]);
}

/** All library songs (liked, in a playlist / My Album, or played), for genre views and counts. */
export function librarySongs() { return smartTracks({ rules: [], sort: 'artist', limit: 5000 }); }

/** [{genre, n}] over the library, most songs first. */
export function libraryGenres() {
  const map = genreMap();
  const c = new Map();
  for (const t of librarySongs()) for (const g of genresOf(t, map)) c.set(g, (c.get(g) || 0) + 1);
  return [...c.entries()].map(([genre, n]) => ({ genre, n })).sort((a, b) => b.n - a.n);
}

// ------------------------------------------------------------------ downloads

export function listDownloads() {
  return q(`SELECT ${TRACK_COLS}, d.state, d.progress, d.size, d.error, d.requested_at added_at, EXISTS(SELECT 1 FROM likes l WHERE l.track_id=t.id) liked ${EXTRA}
      FROM download d JOIN track t ON t.id=d.track_id ORDER BY CASE d.state WHEN 'RUNNING' THEN 0 WHEN 'QUEUED' THEN 1 WHEN 'FAILED' THEN 2 ELSE 3 END, d.done_at DESC, d.requested_at`);
}
