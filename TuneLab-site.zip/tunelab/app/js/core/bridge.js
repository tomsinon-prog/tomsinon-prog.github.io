// JS side of the native bridge (window.TLNative, see Bridge.java). Works in both WebViews.
// In tests a mock TLNative is injected before this module loads.

const N = globalThis.TLNative;
let seq = 0;
const pending = new Map();
const listeners = new Map();

export class BridgeError extends Error {}

globalThis.__tlDone = (id) => {
  const p = pending.get(id);
  if (!p) return;
  pending.delete(id);
  let r;
  try { r = JSON.parse(N.take(id)); } catch (e) { p.reject(e); return; }
  if (r.ok) p.resolve(r.v); else p.reject(new BridgeError(r.error));
};

globalThis.__tlEvent = (name, data) => {
  for (const fn of listeners.get(name) || []) {
    try { fn(data); } catch (e) { console.error('event handler', name, e); }
  }
};

export const native = !!N;

/** Synchronous native call. Throws BridgeError on failure. */
export function call(method, args = {}) {
  if (!N) throw new BridgeError('native bridge missing');
  const r = JSON.parse(N.call(method, JSON.stringify(args)));
  if (!r.ok) throw new BridgeError(r.error);
  return r.v;
}

/** Asynchronous native call (network, files, engine). */
export function callAsync(method, args = {}) {
  if (!N) return Promise.reject(new BridgeError('native bridge missing'));
  return new Promise((resolve, reject) => {
    const id = 'c' + (++seq) + '_' + Date.now().toString(36);
    pending.set(id, { resolve, reject });
    try { N.callAsync(method, JSON.stringify(args), id); } catch (e) { pending.delete(id); reject(e); }
  });
}

export function on(name, fn) {
  if (!listeners.has(name)) listeners.set(name, new Set());
  listeners.get(name).add(fn);
  return () => listeners.get(name).delete(fn);
}

export function emitLocal(name, data) { globalThis.__tlEvent(name, data); }

export function log(level, tag, msg) {
  try { call('log', { level, tag, msg: String(msg) }); } catch { /* ignore */ }
}
