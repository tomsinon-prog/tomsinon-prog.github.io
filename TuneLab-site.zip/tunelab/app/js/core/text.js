// Text normalization. MUST stay identical to android/.../Text.java (checked by tools/dev/tests/unit/text-parity.test.mjs).

const NOISE = /\b(feat|ft|featuring|with|remaster|remastered|version|edit|mono|stereo|deluxe|bonus|explicit|clean|single|radio|bonus track|anniversary)\b/i;
const ARTIST_SPLIT = /\s*(,|;|&|\bfeat\.?|\bft\.?|\bfeaturing\b|\bx\b|\band\b|\bwith\b|\/)\s*/i;

/** Lowercase, strip accents, '&' -> 'and', remove apostrophes, collapse non-alphanumerics. */
export function fold(s) {
  if (s == null) return '';
  let t = String(s).toLowerCase().replaceAll('&', ' and ');
  t = t.replaceAll("'", '').replaceAll('’', '').replaceAll('`', '');
  t = t.normalize('NFKD').replace(/\p{M}+/gu, '');
  return t.replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

/** Title without "(feat. X)", "[Remastered]", " - 2011 Remaster" style noise. */
export function coreTitle(title) {
  if (title == null) return '';
  let t = String(title).replace(/\s*[(\[]([^)\]]*)[)\]]/g, (m, inner) => (NOISE.test(inner) ? '' : m));
  const d = /\s+-\s+(.*)$/.exec(t);
  if (d && NOISE.test(d[1])) t = t.slice(0, d.index);
  return t.trim();
}

export function primaryArtist(artists) {
  if (artists == null) return '';
  const s = Array.isArray(artists) ? (artists[0] || '') : String(artists);
  const parts = s.trim().split(ARTIST_SPLIT);
  return fold(parts.length > 0 ? parts[0] : s);
}

export function matchKey(artists, title) {
  return primaryArtist(artists) + '|' + fold(coreTitle(title));
}

export function sortKey(s) {
  let f = fold(s);
  if (f.startsWith('the ')) f = f.slice(4);
  return f;
}

/** Splits "A, B & C feat. D" into names (display strings, not folded). */
export function splitArtists(s) {
  if (Array.isArray(s)) return s.filter(Boolean);
  if (!s) return [];
  return String(s).split(/\s*(?:,|;|&|\bfeat\.?|\bft\.?|\bfeaturing\b|\s+x\s+)\s*/i).map((x) => x.trim()).filter(Boolean);
}
