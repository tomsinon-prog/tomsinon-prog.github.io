// Where the UI runs: 'android' (the app), 'desktop' (TuneLab for Windows, desktop/) or 'web' (the browser version on
// GitHub Pages, webapp/). The UI leaves out what the host can't do:
//   isDesktop(): not the phone -> no downloads, karaoke, car, local files, Spotify login, Last.fm, EQ, backup folders
//   hasEngine(): YouTube access (search, explore, radio, Weekly Discovery, new releases) -> not in the browser version
import * as bridge from './bridge.js';

let info = null;

export function platform() {
  if (info === null) {
    try { info = bridge.call('app.info') || {}; } catch { info = {}; }
  }
  return info.platform || 'android';
}

export const isDesktop = () => platform() !== 'android';
export const isWeb = () => platform() === 'web';
export const hasEngine = () => platform() !== 'web';
