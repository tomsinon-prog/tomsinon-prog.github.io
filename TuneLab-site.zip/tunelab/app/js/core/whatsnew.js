// "What's new" entries shown in Settings. Add one per release (newest first).
export const WHATS_NEW = [
  {
    version: '0.10',
    date: '2026-11-20',
    items: [
      'Search: browse all of YouTube Music\'s genres and moods, artists for you (like the ones you play, but new to you) and the top artists of the Netherlands and the world.',
      'A genre opens its playlists, its artists (NEW = not in your library yet), your own songs in that genre and Genre radio. YouTube Music playlists open, play and can be saved.',
      'Follow artists: their new albums and singles show up on Home, also when you never played them (Library → Following). Artist pages show "Fans also like".',
      'TuneLab in the browser (for the work laptop): tomsinon-prog.github.io/tunelab/app. Your library from a backup file, played through YouTube\'s own player.',
    ],
  },
  {
    version: '0.9',
    date: '2026-11-20',
    items: [
      'Like while driving: press play/pause twice quickly on the steering wheel (or your headphones) to like the song that plays; a short tick confirms. Liked songs get a ♥ before the title on the car screen (Settings → Play in the car).',
      'TuneLab for Windows: one .exe, nothing to install. Get your library from the phone with the code (Settings → Backup → Move library → Send), or open a backup file.',
    ],
  },
  {
    version: '0.8',
    date: '2026-11-20',
    items: [
      'YouTube playback holds up better: a source that stops sending after the first seconds is noticed before the song starts and set aside for a while, so the app no longer gets stuck on it.',
      'When YouTube refuses streams for a while, TuneLab plays your downloaded songs instead of skipping through the whole queue.',
      'Skipping quickly through songs no longer downloads the next songs right away (fewer requests to YouTube).',
    ],
  },
  {
    version: '0.7',
    date: '2026-11-20',
    items: [
      'Move library to another phone (Settings → Backup): the old phone shows a code, you type it on the new phone. Likes, playlists, albums, history and settings go straight over your Wi-Fi, nothing through the internet.',
      'Play in the car (Settings → Playback): choose your car; when it connects over Bluetooth, TuneLab starts playing where you left off (or shuffles your liked songs). Only when the sound really goes to the car.',
    ],
  },
  {
    version: '0.6',
    date: '2026-11-20',
    items: [
      'Share songs, albums, artists and playlists: the link opens TuneLab on a friend\'s phone and plays or opens the page (people without TuneLab get YouTube Music links).',
      'Links from YouTube / YouTube Music can be shared to TuneLab to play them here.',
      'Now Playing: drag down to close, swipe the artwork left for the next song and right for the previous one.',
      'Choose your accent colour (Settings → Appearance).',
      'Downloads: the options are folded away; tap “Download options” to see them.',
    ],
  },
  {
    version: '0.5',
    date: '2026-11-20',
    items: [
      'Playback fixes itself: a network hiccup is retried quietly (a few seconds), a YouTube version that can\'t be played is swapped for the next best one automatically (and remembered), and only if nothing works it skips to the next song with a short message.',
      'Without internet it jumps to the next song that is downloaded or cached.',
      'Songs without any playable version end up in Library → Needs review.',
      'Calm error message (one sentence; details in the log) and the artwork no longer covers the top bar when a message shows.',
    ],
  },
  {
    version: '0.4',
    date: '2026-11-20',
    items: [
      'Karaoke: a clean “getting ready” screen; skip and rewind while you sing (−10 s / +10 s or the position bar; singing a part again replaces it).',
      'Karaoke review: play / pause and scrub through your take (only the part you sang), voice effects Natural, Studio, Pop, Warm, Concert hall, Echo, Club and Radio, and Fine-tune.',
      'Karaoke recordings: play, pause and scrub in the list.',
      'Genres: your genres in Search, type a genre to find it, and ready-made filters in every list (Downloaded, Liked, Not played yet, Live, genres). Genres come from MusicBrainz.',
      'All dropdowns are now in-app menus instead of Android pickers.',
      'Settings cleaned up (Advanced page for technical options). “Keep offline” moved to Settings and the ⋮ menu.',
      'Weekly Discovery is no longer downloaded as a whole: only songs you like are (with “Keep liked songs offline”).',
      'Fix: searching for a song that is already in your library broke the results.',
    ],
  },
  {
    version: '0.3',
    date: '2026-11-19',
    items: [
      'Weekly Discovery: about 30 songs you don’t know yet, new every Monday, downloaded automatically. Songs you like stay.',
      'New releases: albums and singles from the artists you play most (Home and Library).',
      'Smart playlists that fill themselves: Forgotten favourites, On repeat, Top of a year, or your own rules.',
      '“Keep offline” on any playlist and on Liked songs: new songs download by themselves.',
      'The shuffle button has three modes: off, shuffle, smart shuffle. Radio is now a clear action with Undo.',
      'Karaoke: works again the second time, lyrics fill word by word, Stop & review always on screen, Back stops singing, score and pitch guide now follow the real singer in full songs, quiet mics are levelled. Karaoke tile on Home.',
      'Fixes: tapping a search result after visiting an album played an album song; album buttons on one line; the × in the search box; tidier Downloads; fewer stacked messages.',
    ],
  },
  {
    version: '0.2',
    date: '2026-11-19',
    items: [
      'Karaoke (⋮ → Sing karaoke): finds a YouTube karaoke/instrumental version, or removes the vocals from the song itself.',
      'Lyrics sync automatically to the backing track; nudge them ±0.5 s if needed. Change the key in semitones.',
      'Sing with headphones: live pitch lane and score against the original melody, countdown, optional "hear myself".',
      'Review your take: voice/music balance, reverb, echo, voice timing; save as .m4a in Music/TuneLab Karaoke and share.',
      'Duet with yourself: add a second voice over your first take. All takes in Library → Karaoke recordings.',
      'Like button in the mini player; liked and downloaded badges in search results.',
      'Now Playing fills the whole screen; lyrics and queue open in the same space as the artwork.',
    ],
  },
  {
    version: '0.1',
    date: '2026-11-19',
    items: [
      'First build: search YouTube Music + YouTube and play instantly, with background playback, lock screen and headset controls.',
      'Gapless playback, optional crossfade (0–12 s), prefetch of the next tracks and a 2 GB audio cache.',
      'Library: likes, playlists (drag to reorder), My Albums, queue editing, history, sorting and filtering.',
      'Spotify import (your own Client ID, PKCE) with resumable, throttled YouTube matching and a "Needs review" list.',
      'CSV import (Exportify, TuneMyMusic), JSON + M3U8 backup with daily/weekly automatic backups, restore.',
      'Downloads for offline listening, offline mode, local music files (MediaStore + folders).',
      '10-band equalizer, bass boost, loudness normalization, sleep timer.',
      'Song radio, smart shuffle, Last.fm scrobbling, synced lyrics (LRCLIB), Android Auto, home screen widget.',
      'Spotify data package import: streaming history, stats and "possibly lost likes".',
      'Diagnostics: in-app log, YouTube test, background test.',
    ],
  },
];
