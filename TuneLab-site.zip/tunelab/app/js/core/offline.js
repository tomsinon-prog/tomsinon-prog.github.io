// Keeps "offline" sets downloaded: playlists with offline=1 and (setting likesOffline) the liked songs.
// Runs in the UI and in the engine (after Spotify sync / weekly mix). Never deletes anything by itself.
import { call } from './bridge.js';
import * as db from './db.js';
import * as settings from './settings.js';

/** Queues downloads for every song an offline set needs. Returns the number queued. */
export function syncOffline(nativeCall = call) {
  const ids = db.offlineMissing({ likes: !!settings.get('likesOffline') });
  if (!ids.length) return 0;
  let queued = 0;
  for (let i = 0; i < ids.length; i += 500) {
    const r = nativeCall('downloads.enqueue', { trackIds: ids.slice(i, i + 500) });
    queued += (r && r.queued) || 0;
  }
  return queued;
}
