// Engine WebView entry (headless, owned by the app process; see Engine.java).
// Java calls __tlEngine.handle(id, method, args); we answer through the bridge ("engine.reply").
import * as bridge from '../core/bridge.js';
import * as settings from '../core/settings.js';
import * as db from '../core/db.js';
import { StreamResolver } from '../yt/resolver.js';
import { nativeFetch, stats as fetchStats } from '../yt/fetch-shim.js';
import { createJobs } from './jobs.js';

const log = (level, msg) => bridge.log(level, 'engine', msg);
const emit = (name, data) => { try { bridge.call('engine.emit', { name, data }); } catch { /* ignore */ } };

const resolver = new StreamResolver({
  fetchFn: nativeFetch,
  log,
  getSetting: (k) => settings.get(k),
  kv: { get: (k) => db.kvGet(k), set: (k, v) => db.kvSet(k, v) },
});

const jobs = createJobs({
  resolver, settings, emit, log, fetchFn: nativeFetch,
  startJob: (job) => { try { bridge.call('jobs.start', { job }); } catch (e) { log('W', 'cannot start ' + job + ': ' + e.message); } },
  nativeCall: (m, a) => bridge.call(m, a),
});

const handlers = {
  ping: async () => ({ pong: Date.now(), stats: resolver.stats, fetch: fetchStats }),
  search: async ({ q, limit }) => resolver.search(q, { limit }),
  searchSongs: async ({ q }) => resolver.searchSongs(q),
  // `avoid`: the client whose URL just failed while streaming (HTTP 403 mid-song) is tried last for a while.
  resolve: async ({ videoId, quality, avoid }) => {
    if (avoid) resolver.cool(avoid, 30 * 60e3, 'stream refused mid-song');
    return resolver.resolve(videoId, { quality: quality || 'high' });
  },
  upNext: async ({ videoId }) => resolver.upNext(videoId),
  album: async ({ browseId }) => resolver.album(browseId),
  artist: async ({ browseId }) => resolver.artist(browseId),
  details: async ({ videoId }) => resolver.details(videoId),
  matchOne: async (a) => jobs.matchOne(a),
  karaokeFind: async (a) => jobs.karaokeFind(a),
  alternatives: async (a) => jobs.alternatives(a),
  radioStart: async (a) => jobs.radioStart(a),
  radioMore: async (a) => jobs.radioMore(a),
  smartRecs: async (a) => jobs.smartRecs(a),
  weeklyMix: async (a) => jobs.weeklyMix(a),
  newReleases: async (a) => jobs.newReleases(a),
  genres: async (a) => jobs.genres(a),
  searchPlay: async (a) => jobs.searchPlay(a),
  exploreGenres: async () => jobs.exploreGenres(),
  genrePage: async (a) => jobs.genrePage(a),
  ytPlaylist: async (a) => jobs.ytPlaylist(a),
  charts: async (a) => jobs.charts(a),
  artistsForYou: async (a) => jobs.artistsForYou(a),
  spotifySync: async (a) => jobs.spotifySync(a),
  resetClient: async () => { resolver.reset(); await resolver.client(); return { ok: true }; },
  diagSearch: async ({ q }) => {
    const t0 = Date.now();
    await resolver.client();
    const t1 = Date.now();
    const r = await resolver.search(q, { limit: 5 });
    return { initMs: t1 - t0, searchMs: Date.now() - t1, songs: r.songs, videos: r.videos, errors: r.errors, stats: resolver.stats };
  },
};

globalThis.__tlEngine = {
  async handle(id, method, args) {
    settings.invalidate();
    const fn = handlers[method];
    try {
      if (!fn) throw new Error('unknown engine method ' + method);
      const v = await fn(args || {});
      bridge.call('engine.reply', { id, ok: true, v: v === undefined ? null : v });
    } catch (e) {
      log('W', `${method} failed: ${e?.message || e}`);
      try { bridge.call('engine.reply', { id, ok: false, error: String(e?.message || e) }); } catch { /* ignore */ }
    }
  },
};

window.addEventListener('unhandledrejection', (e) => log('E', 'unhandled: ' + (e.reason?.stack || e.reason)));
bridge.call('engine.ready', {});
log('I', 'engine loaded');
// Warm up the InnerTube session (and the player script used for deciphering) right away.
setTimeout(() => resolver.client().catch((e) => log('W', 'warm-up failed: ' + e.message)), 10);
