// Engine-side jobs: matching, alternatives, radio, voice search, smart-shuffle recommendations, Spotify sync.
// Dependencies are injected so the logic runs in Node tests with a fake resolver.
import * as db from '../core/db.js';
import { rankCandidates, classify, queryFor } from '../lib/match.js';
import { filterRadio, shuffled } from '../lib/radio.js';
import { SpotifyClient } from '../lib/spotify.js';
import { syncSpotify } from '../lib/spotify-sync.js';
import { matchKey, primaryArtist } from '../core/text.js';
import { rankKaraoke } from '../lib/karaoke-match.js';
import { pickMixSeeds, buildMix, scoreArtists, pickArtist, diffReleases, mixDue, aggregateArtists } from '../lib/discover.js';
import { syncOffline } from '../core/offline.js';
import { mainGenres, pickMbArtist } from '../lib/genres.js';
import { APP } from '../core/app-info.js';

const DAY = 86400000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function createJobs({ resolver, settings, emit = () => {}, log = () => {}, fetchFn, startJob = () => {}, nativeCall = () => null }) {
  const trackInput = (t) => ({ title: t.title, artists: t.artists, album: t.album, durationMs: t.duration_ms });

  function storeCandidates(trackId, ranked) {
    const ops = [{ sql: 'DELETE FROM match_candidate WHERE track_id=?', args: [trackId] }];
    for (const c of ranked.slice(0, 8)) {
      ops.push({ sql: 'INSERT OR REPLACE INTO match_candidate(track_id,video_id,title,channel,duration_ms,thumb,score,is_topic,kind) VALUES(?,?,?,?,?,?,?,?,?)',
        args: [trackId, c.videoId, c.title, c.channel || (c.artists || []).join(', '), c.durationMs || 0, c.thumb || null, c.score, c.official ? 1 : 0, c.kind] });
    }
    db.batch(ops);
  }

  async function matchOne({ trackId, onDemand = false, force = false }) {
    const t = db.getTrack(trackId);
    if (!t) throw new Error('track not found');
    const has = db.one("SELECT 1 x FROM track_source WHERE track_id=? AND broken=0 LIMIT 1", [trackId]);
    if (has && !force) return { state: t.match_state, already: true };
    const track = trackInput(t);
    const query = queryFor(track);
    // versions that failed to play are never picked again (PlaybackService marks them broken)
    const broken = new Set(db.q("SELECT ref FROM track_source WHERE track_id=? AND kind='YOUTUBE' AND broken=1", [trackId]).map((r) => r.ref));
    const usable = (list) => list.filter((c) => !broken.has(c.videoId));
    const songs = usable(await resolver.searchSongs(query));
    let ranked = rankCandidates(track, songs);
    let cls = classify(ranked[0]);
    if (cls !== 'MATCHED' && t.isrc) {
      const byIsrc = usable(await resolver.searchSongs(t.isrc).catch(() => []));
      ranked = rankCandidates(track, [...byIsrc, ...songs]);
      cls = classify(ranked[0]);
    }
    if (cls !== 'MATCHED') {
      const vids = usable(await resolver.searchVideos(query).catch(() => []));
      ranked = rankCandidates(track, [...songs, ...vids]);
      cls = classify(ranked[0]);
    }
    const best = ranked[0] || null;
    storeCandidates(trackId, ranked);
    let state = cls;
    if (best && (cls === 'MATCHED' || cls === 'REVIEW' || (onDemand && best.score >= 0.3))) {
      db.addYoutubeSource(trackId, best, { score: best.score });
      if (cls === 'FAILED') state = 'REVIEW';
    }
    db.run('UPDATE track SET match_state=?, match_score=?, match_tried_at=?, updated_at=? WHERE id=?', [state, best ? best.score : 0, Date.now(), Date.now(), trackId]);
    return { state, score: best ? best.score : 0, videoId: best ? best.videoId : null, title: best ? best.title : null, candidates: ranked.length };
  }

  async function alternatives({ trackId, query }) {
    const t = db.getTrack(trackId);
    if (!t) throw new Error('track not found');
    const track = trackInput(t);
    const qy = query || queryFor(track);
    const [songs, vids] = await Promise.all([resolver.searchSongs(qy).catch(() => []), resolver.searchVideos(qy).catch(() => [])]);
    const ranked = rankCandidates(track, [...songs, ...vids]);
    const current = db.getSources(trackId).filter((s) => s.kind === 'YOUTUBE');
    return { query: qy, candidates: ranked.slice(0, 25), current };
  }

  // ---------------------------------------------------------------- radio

  async function seedVideoForTrack(trackId) {
    let s = db.one("SELECT ref FROM track_source WHERE track_id=? AND kind='YOUTUBE' AND broken=0 ORDER BY chosen DESC, score DESC LIMIT 1", [trackId]);
    if (!s) {
      await matchOne({ trackId, onDemand: true });
      s = db.one("SELECT ref FROM track_source WHERE track_id=? AND kind='YOUTUBE' AND broken=0 ORDER BY chosen DESC, score DESC LIMIT 1", [trackId]);
    }
    return s ? s.ref : null;
  }

  async function lastfmSimilar(artist, title) {
    const key = settings.get('lastfmApiKey');
    if (!key || !settings.get('radioLastfm') || !fetchFn) return [];
    try {
      const u = `https://ws.audioscrobbler.com/2.0/?method=track.getsimilar&artist=${encodeURIComponent(artist)}&track=${encodeURIComponent(title)}&api_key=${encodeURIComponent(key)}&format=json&limit=30&autocorrect=1`;
      const j = await (await fetchFn(u)).json();
      return (j.similartracks?.track || []).map((x) => ({ title: x.name, artists: [x.artist?.name].filter(Boolean) }));
    } catch (e) {
      log('W', 'Last.fm similar failed: ' + e.message);
      return [];
    }
  }

  async function lastfmBlend(seedTrack) {
    if (!seedTrack) return [];
    const sim = await lastfmSimilar((seedTrack.artists || '').split(', ')[0], seedTrack.title);
    const out = [];
    for (const s of shuffled(sim).slice(0, 4)) {
      const found = await resolver.searchSongs(`${s.artists[0] || ''} ${s.title}`).catch(() => []);
      const r = rankCandidates({ title: s.title, artists: s.artists, durationMs: 0 }, found)[0];
      if (r && r.score >= 0.5) out.push(r);
    }
    return out;
  }

  function queueExclusions(queueTrackIds) {
    const ids = (queueTrackIds || []).filter(Boolean);
    const excludeVideoIds = new Set();
    const excludeKeys = new Set();
    for (let i = 0; i < ids.length; i += 400) {
      const part = ids.slice(i, i + 400);
      const ph = part.map(() => '?').join(',');
      for (const r of db.q(`SELECT ref FROM track_source WHERE kind='YOUTUBE' AND track_id IN (${ph})`, part)) excludeVideoIds.add(r.ref);
      for (const r of db.q(`SELECT match_key FROM track WHERE id IN (${ph})`, part)) excludeKeys.add(r.match_key);
    }
    return { excludeVideoIds, excludeKeys };
  }

  function toTracks(items) { return items.map((it) => db.ensureYoutubeTrack(it)); }

  async function radioStart({ seedTrackId, mode = 'track', playlistId, artist, params, name: genreName }) {
    let seeds = [];
    let name = 'Radio';
    let first = [];
    let seedTrack = null;
    if (mode === 'genre' && params) {
      // Genre radio: the genre's own playlists, shuffled; it continues like any radio from the last song.
      const pls = (await resolver.genreCategory(params)).flatMap((sh) => sh.items).filter((x) => x.kind === 'playlist');
      if (!pls.length) throw new Error('no playlists for this genre');
      let songs = [];
      for (const p of shuffled(pls.slice(0, 6)).slice(0, 2)) songs.push(...((await resolver.playlist(p.browseId).catch(() => null))?.tracks || []));
      const seen = new Set();
      songs = shuffled(songs.filter((x) => !seen.has(x.videoId) && seen.add(x.videoId))).slice(0, 60);
      if (!songs.length) throw new Error('the genre playlists were empty');
      const label = `${genreName || 'Genre'} radio`;
      return { trackIds: toTracks(songs), name: label, radio: { mode: 'genre', seeds: songs.slice(0, 6).map((x) => x.videoId), lastVideoId: songs[songs.length - 1].videoId, name: label } };
    }
    if (mode === 'playlist' && playlistId) {
      const pl = db.getPlaylist(playlistId);
      name = `${pl ? pl.name : 'Playlist'} radio`;
      const entries = shuffled(db.playlistEntries(playlistId)).slice(0, 3);
      for (const e of entries) { const v = await seedVideoForTrack(e.id); if (v) seeds.push(v); }
      seedTrack = entries[0] ? db.getTrack(entries[0].id) : null;
    } else if (mode === 'artist' && artist) {
      name = `${artist} radio`;
      const songs = await resolver.searchSongs(artist);
      if (songs[0]) { seeds.push(songs[0].videoId); first = [songs[0]]; }
    } else {
      seedTrack = db.getTrack(seedTrackId);
      if (!seedTrack) throw new Error('seed track not found');
      name = `${seedTrack.title} radio`;
      const v = await seedVideoForTrack(seedTrackId);
      if (v) seeds.push(v);
    }
    if (!seeds.length) throw new Error('no YouTube match for the radio seed');
    let pool = [];
    for (const v of seeds) pool.push(...(await resolver.upNext(v).catch((e) => { log('W', 'upNext failed: ' + e.message); return []; })));
    const blend = await lastfmBlend(seedTrack);
    pool = interleaveBlend(shuffleTail(pool, seeds.length > 1), blend);
    const filterLibrary = !!settings.get('radioFilterLibrary');
    const ex = seedTrackId ? queueExclusions([seedTrackId]) : { excludeVideoIds: new Set(), excludeKeys: new Set() };
    for (const v of seeds) ex.excludeVideoIds.add(v);
    const kept = filterRadio(pool, { ...ex, libraryKeys: filterLibrary ? db.libraryKeys() : new Set(), filterLibrary, lastArtist: seedTrack ? seedTrack.artists : null });
    const ids = [];
    if (mode === 'track' && seedTrackId) ids.push(seedTrackId);
    ids.push(...toTracks([...first, ...kept]));
    const last = kept.length ? kept[kept.length - 1].videoId : seeds[seeds.length - 1];
    return { trackIds: ids, name, radio: { mode, seeds, lastVideoId: last, name, playlistId: playlistId || null } };
  }

  async function radioMore({ radio = {}, queueTrackIds = [], seedTrackId }) {
    let from = radio.lastVideoId;
    if (!from && seedTrackId) from = await seedVideoForTrack(seedTrackId);
    if (!from) throw new Error('radio has no seed');
    let pool = await resolver.upNext(from);
    const ex = queueExclusions(queueTrackIds);
    const filterLibrary = !!settings.get('radioFilterLibrary');
    let kept = filterRadio(pool, { ...ex, libraryKeys: filterLibrary ? db.libraryKeys() : new Set(), filterLibrary });
    if (kept.length < 3 && radio.seeds && radio.seeds.length) {
      // dried up: branch out from a random earlier seed
      const alt = radio.seeds[Math.floor(Math.random() * radio.seeds.length)];
      pool = await resolver.upNext(alt).catch(() => []);
      kept = filterRadio(pool, { ...ex, libraryKeys: filterLibrary ? db.libraryKeys() : new Set(), filterLibrary });
    }
    if (kept.length < 3 && filterLibrary) {
      kept = filterRadio(pool, { ...ex, filterLibrary: false });
    }
    const ids = toTracks(kept.slice(0, 20));
    const last = kept.length ? kept[Math.min(kept.length, 20) - 1].videoId : from;
    const seeds = [...(radio.seeds || []), ...kept.slice(0, 3).map((k) => k.videoId)].slice(-12);
    return { trackIds: ids, radio: { ...radio, lastVideoId: last, seeds } };
  }

  function shuffleTail(pool, mix) { return mix ? shuffled(pool) : pool; }

  function interleaveBlend(pool, blend) {
    if (!blend.length) return pool;
    const out = [];
    let b = 0;
    pool.forEach((x, i) => { out.push(x); if (i % 3 === 2 && b < blend.length) out.push(blend[b++]); });
    while (b < blend.length) out.push(blend[b++]);
    return out;
  }

  /** Recommendations for smart shuffle: tracks the user does not know yet, seeded from random playlist tracks. */
  async function smartRecs({ trackIds = [], count = 10, excludeTrackIds = [] }) {
    const lib = db.libraryKeys();
    const picks = shuffled(trackIds).slice(0, 3);
    const pool = [];
    for (const id of picks) {
      const v = await seedVideoForTrack(id).catch(() => null);
      if (v) pool.push(...(await resolver.upNext(v).catch(() => [])));
    }
    const ex = queueExclusions([...trackIds, ...excludeTrackIds]);
    const kept = filterRadio(shuffled(pool), { ...ex, libraryKeys: lib, filterLibrary: true }).slice(0, count);
    return { trackIds: toTracks(kept) };
  }

  // ---------------------------------------------------------------- weekly discovery mix

  /** ~30 songs you don't have yet, from YouTube Music up-next of songs you play and like. Replaces last week's mix. */
  async function weeklyMix({ force = false } = {}) {
    if (!settings.get('mixEnabled')) return { skipped: true, message: 'Weekly Discovery is off' };
    const st = db.kvGetJson('mix.state', {}) || {};
    if (!force && db.mixPlaylist() && !mixDue(st.builtAt)) return { skipped: true, message: 'Weekly Discovery is up to date' };
    const top = db.q(`SELECT t.id, t.artists, COUNT(*) n FROM play_event e JOIN track t ON t.id=e.track_id
        WHERE e.ms_played>=30000 AND e.ts>=? GROUP BY t.id ORDER BY n DESC LIMIT 60`, [Date.now() - 60 * DAY]);
    const likes = db.q('SELECT t.id, t.artists FROM likes l JOIN track t ON t.id=l.track_id ORDER BY l.liked_at DESC LIMIT 2000');
    const seeds = pickMixSeeds(top, likes, { n: 8 });
    if (seeds.length < 2) throw new Error('Like or play a few more songs first');
    const pools = [];
    for (const s of seeds) {
      const v = await seedVideoForTrack(s.id).catch(() => null);
      if (v) pools.push(await resolver.upNext(v).catch((e) => { log('W', 'mix upNext failed: ' + e.message); return []; }));
      emit('job', { job: 'weeklyMix', state: 'running', done: pools.length, total: seeds.length, message: 'Finding new music…' });
    }
    const recent = new Set(st.keys || []);
    const picked = buildMix(pools, { libraryKeys: db.libraryKeys(), excludeKeys: recent, size: 30 });
    if (picked.length < 8) throw new Error('YouTube returned too few recommendations; try again later');
    const ids = toTracks(picked);
    const seedNames = [...new Set(seeds.map((s) => (s.artists || '').split(', ')[0]).filter(Boolean))].slice(0, 3);
    const { id, oldTrackIds } = db.replaceMix(ids, { offline: !!settings.get('mixOffline'), description: `Based on ${seedNames.join(', ')} and more` });
    // Last week's songs you didn't keep (like / add to a playlist) give their download space back.
    const keep = new Set(ids);
    const orphans = db.offlineOrphans(oldTrackIds.filter((t) => !keep.has(t)), { exceptPlaylistId: id, strict: true });
    if (orphans.length) { try { nativeCall('downloads.delete', { trackIds: orphans }); } catch (e) { log('W', 'mix cleanup: ' + e.message); } }
    const keys = [...picked.map((c) => matchKey(c.artists?.length ? c.artists : [c.channel || ''], c.title)), ...(st.keys || [])].slice(0, 150);
    db.kvSetJson('mix.state', { builtAt: Date.now(), keys, seeds: seedNames });
    if (settings.get('genresEnabled')) startJob('genres');
    let queued = 0;
    try { queued = syncOffline(nativeCall); } catch (e) { log('W', 'offline sync after mix: ' + e.message); }
    return { playlistId: id, count: ids.length, removedDownloads: orphans.length, queued, done: ids.length, total: ids.length, message: `${ids.length} new songs` };
  }

  // ---------------------------------------------------------------- genres (MusicBrainz)

  /**
   * Looks up library artists on MusicBrainz (free, no account; at most 1 request per second as they ask) and
   * stores their main genres. Only artist names are sent, with an app User-Agent (no personal data).
   */
  async function genres({ max = 150, delayMs = 1100 } = {}) {
    if (!settings.get('genresEnabled')) return { skipped: true, message: 'Genres are off' };
    const todo = db.genresTodo(max);
    const ua = `TuneLab/${APP.versionName || '0'} ( https://github.com/tomsinon-prog/TuneLab )`;
    let done = 0, found = 0, errors = 0;
    for (const a of todo) {
      emit('job', { job: 'genres', state: 'running', done, total: todo.length, message: a.name });
      try {
        const q = `artist:"${a.name.replace(/["\\]/g, ' ')}"`;
        const res = await fetchFn(`https://musicbrainz.org/ws/2/artist/?query=${encodeURIComponent(q)}&limit=5&fmt=json`, { headers: { 'User-Agent': ua, Accept: 'application/json' } });
        if (res.status === 503 || res.status === 429) { await sleep(delayMs * 5); errors++; if (errors > 10) break; continue; }
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const best = pickMbArtist(await res.json(), a.name);
        const g = best ? mainGenres(best.tags) : [];
        db.setArtistGenre(a.key, a.name, g, best ? (best.tags || []).slice(0, 12) : null, best ? best.id : null);
        if (g.length) found++;
      } catch (e) {
        errors++;
        log('W', `genres for ${a.name}: ${e.message}`);
        db.setArtistGenre(a.key, a.name, [], null, null, Date.now() - 113 * DAY); // retry in about a week
        if (errors > 10) break;
      }
      done++;
      await sleep(delayMs);
    }
    return { done, total: todo.length, found, message: `${found} of ${done} artists got a genre` };
  }

  // ---------------------------------------------------------------- new releases

  /** Checks the most-listened artists' YouTube Music pages (a few per run) for albums/singles not seen before. */
  async function newReleases({ maxArtists = 8, force = false } = {}) {
    if (!settings.get('releasesEnabled')) return { skipped: true, message: 'New releases are off' };
    const now = Date.now();
    const plays = db.q(`SELECT COALESCE(t.artists, e.artist_name) artist, COUNT(*) plays FROM play_event e LEFT JOIN track t ON t.id=e.track_id
        WHERE e.ts>=? AND e.ms_played>=30000 GROUP BY LOWER(COALESCE(t.artists, e.artist_name))`, [now - 365 * DAY]);
    const likes = db.q('SELECT t.artists artist, COUNT(*) likes FROM likes l JOIN track t ON t.id=l.track_id GROUP BY t.artists');
    const top = scoreArtists(plays, likes, { limit: 40 });
    db.batch([{ sql: 'UPDATE artist_follow SET score=0', args: [] },
      ...top.map((a) => ({ sql: 'INSERT INTO artist_follow(key,name,score) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET score=excluded.score', args: [a.key, a.name, a.score] }))]);
    const due = db.q(`SELECT * FROM artist_follow WHERE muted=0 AND (score>0 OR manual=1) AND (checked_at IS NULL OR checked_at<?)
        ORDER BY checked_at IS NOT NULL, manual DESC, checked_at, score DESC LIMIT ?`, [force ? now + 1 : now - 3 * DAY, maxArtists]);
    let checked = 0, found = 0;
    for (const a of due) {
      emit('job', { job: 'newReleases', state: 'running', done: checked, total: due.length, message: a.name });
      try {
        let bid = a.browse_id;
        if (!bid) {
          const best = pickArtist(await resolver.searchArtists(a.name), a.name);
          if (!best) { db.run('UPDATE artist_follow SET checked_at=? WHERE key=?', [now, a.key]); continue; }
          bid = best.browseId;
          db.run('UPDATE artist_follow SET browse_id=?, thumb=? WHERE key=?', [bid, best.thumb || null, a.key]);
        }
        const r = await resolver.artistReleases(bid);
        const known = new Set(db.q('SELECT browse_id FROM artist_release WHERE artist_key=?', [a.key]).map((x) => x.browse_id));
        const fresh = diffReleases(known, r.releases, { firstScan: a.checked_at == null, now });
        db.batch(fresh.map((x) => ({ sql: 'INSERT OR IGNORE INTO artist_release(browse_id,artist_key,artist,title,kind,year,thumb,first_seen,baseline) VALUES(?,?,?,?,?,?,?,?,?)',
          args: [x.browseId, a.key, r.name || a.name, x.title, x.kind, x.year, x.thumb, x.firstSeen, x.baseline] })));
        found += fresh.filter((x) => !x.baseline).length;
        db.run('UPDATE artist_follow SET checked_at=? WHERE key=?', [now, a.key]);
        checked++;
      } catch (e) {
        log('W', `releases for ${a.name}: ${e.message}`);
        db.run('UPDATE artist_follow SET checked_at=? WHERE key=?', [now - 2 * DAY, a.key]); // retry in a day
      }
    }
    db.kvSetJson('releases.state', { checkedAt: now });
    return { checked, found, done: checked, total: due.length, message: `${checked} artists checked · ${found} new releases` };
  }

  // ---------------------------------------------------------------- explore (Search: genres, charts, artists for you)

  /** YouTube Music's own genres and moods (cached by the UI for a week). */
  async function exploreGenres() {
    const sections = await resolver.moodsAndGenres();
    db.kvSetJson('explore.genres', { at: Date.now(), sections });
    return { sections };
  }

  /** A genre page: playlists by shelf, and artists (from the page, or the most frequent artists in its playlists). */
  async function genrePage({ params }) {
    const shelves = await resolver.genreCategory(params);
    const seen = new Set();
    const playlistShelves = shelves.map((sh) => ({ title: sh.title, items: sh.items.filter((x) => (x.kind === 'playlist' || x.kind === 'album') && !seen.has(x.browseId) && seen.add(x.browseId)) })).filter((sh) => sh.items.length);
    let artists = shelves.flatMap((sh) => sh.items).filter((x) => x.kind === 'artist' && x.browseId);
    if (artists.length < 8) {
      const songs = [];
      for (const p of playlistShelves.flatMap((sh) => sh.items).filter((x) => x.kind === 'playlist').slice(0, 2)) {
        songs.push(...((await resolver.playlist(p.browseId).catch(() => null))?.tracks || []));
      }
      artists = aggregateArtists(artists, songs, 16);
    }
    const known = db.knownArtistKeys();
    return { shelves: playlistShelves, artists: artists.map((a) => ({ ...a, isNew: !known.has(primaryArtist(a.title)) })) };
  }

  async function ytPlaylist({ id }) { return resolver.playlist(id); }

  /** Top artists of the charts ('NL' or 'ZZ' = world), cached a day. */
  async function charts({ country = 'NL' } = {}) {
    const shelves = await resolver.charts(country);
    const artists = (shelves.find((sh) => sh.items.some((x) => x.kind === 'artist'))?.items || []).filter((x) => x.kind === 'artist').slice(0, 20);
    const known = db.knownArtistKeys();
    const out = { at: Date.now(), country, artists: artists.map((a) => ({ ...a, isNew: !known.has(primaryArtist(a.title)) })) };
    db.kvSetJson('explore.charts.' + country, out);
    return out;
  }

  /** Artists like the ones you listen to most ("Fans might also like" on their pages), minus the ones you have. */
  async function artistsForYou({ seeds = 6, limit = 18 } = {}) {
    const now = Date.now();
    const plays = db.q(`SELECT COALESCE(t.artists, e.artist_name) artist, COUNT(*) plays FROM play_event e LEFT JOIN track t ON t.id=e.track_id
        WHERE e.ts>=? AND e.ms_played>=30000 GROUP BY LOWER(COALESCE(t.artists, e.artist_name))`, [now - 365 * DAY]);
    const likes = db.q('SELECT t.artists artist, COUNT(*) likes FROM likes l JOIN track t ON t.id=l.track_id GROUP BY t.artists');
    const top = scoreArtists(plays, likes, { limit: seeds });
    const known = db.knownArtistKeys();
    const found = new Map();
    for (const a of top) {
      try {
        let bid = db.one('SELECT browse_id FROM artist_follow WHERE key=?', [a.key])?.browse_id;
        if (!bid) bid = pickArtist(await resolver.searchArtists(a.name), a.name)?.browseId;
        if (!bid) continue;
        const page = await resolver.artist(bid);
        for (const r of page.related || []) {
          const key = primaryArtist(r.title);
          if (!key || known.has(key)) continue;
          const e = found.get(key) || { ...r, because: [], n: 0 };
          e.n++;
          if (!e.because.includes(a.name)) e.because.push(a.name);
          found.set(key, e);
        }
      } catch (e) { log('W', `artists like ${a.name}: ${e.message}`); }
    }
    const artists = [...found.values()].sort((x, y) => y.n - x.n).slice(0, limit).map(({ n, ...x }) => ({ ...x, isNew: true }));
    const out = { at: now, artists };
    db.kvSetJson('explore.forYou', out);
    return out;
  }

  async function searchPlay({ q }) {
    const lib = db.searchLibrary(q, 5);
    if (lib.tracks.length) return { trackIds: lib.tracks.map((t) => t.id) };
    const songs = await resolver.searchSongs(q);
    if (!songs.length) throw new Error('nothing found');
    return { trackIds: [db.ensureYoutubeTrack(songs[0])] };
  }

  async function spotifySync() {
    const clientId = settings.get('spotifyClientId');
    if (!clientId) throw new Error('Enter your Spotify Client ID in Settings first');
    const tokens = { get: () => db.kvGetJson('spotify.tokens'), save: (t) => db.kvSetJson('spotify.tokens', t) };
    const api = new SpotifyClient({
      fetchFn, clientId, tokens,
      onRateLimit: (ms) => emit('job', { job: 'spotifySync', state: 'running', done: -1, total: -1, message: `Spotify rate limit, waiting ${Math.round(ms / 1000)} s` }),
    });
    const summary = await syncSpotify(api, {
      progress: (message, done, total) => emit('job', { job: 'spotifySync', state: 'running', done, total, message }),
    });
    log('I', 'Spotify sync: ' + JSON.stringify(summary));
    if (settings.get('autoMatch')) startJob('match');
    try { syncOffline(nativeCall); } catch (e) { log('W', 'offline sync after Spotify: ' + e.message); }
    const message = `${summary.liked} liked songs (${summary.newLikes} new), ${summary.importable} playlists imported`
      + (summary.notImportable ? `, ${summary.notImportable} followed playlists not importable` : '')
      + (summary.missingLikes ? `, ${summary.missingLikes} missing on Spotify (kept here)` : '');
    return { ...summary, message, done: summary.liked, total: summary.liked };
  }

  /** Karaoke / instrumental versions of a track on YouTube (best first). */
  async function karaokeFind({ trackId }) {
    const t = db.getTrack(trackId);
    if (!t) throw new Error('track not found');
    const artist = (t.artists || '').split(', ')[0];
    const [k1, k2, s1] = await Promise.all([
      resolver.searchVideos(`${artist} ${t.title} karaoke`).catch(() => []),
      resolver.searchVideos(`${artist} ${t.title} instrumental`).catch(() => []),
      resolver.searchSongs(`${artist} ${t.title} instrumental`).catch(() => []),
    ]);
    return { candidates: rankKaraoke(trackInput(t), [...k1, ...k2, ...s1]).slice(0, 12) };
  }

  return { karaokeFind, matchOne, alternatives, radioStart, radioMore, smartRecs, weeklyMix, newReleases, genres, searchPlay, spotifySync, lastfmSimilar, exploreGenres, genrePage, ytPlaylist, charts, artistsForYou, _matchKey: matchKey };
}
