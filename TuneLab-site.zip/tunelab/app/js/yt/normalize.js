// Normalizes youtubei.js nodes into plain objects the app uses everywhere:
// {kind, videoId, browseId, title, artists[], channel, album, durationMs, thumb, isTopic, views}
import { parseDurationText } from '../core/util.js';

export const txt = (x) => (x == null ? '' : typeof x === 'string' ? x : (x.text ?? (typeof x.toString === 'function' ? x.toString() : '')) || '');

export function bestThumb(t, want = 226) {
  let arr = t;
  if (!arr) return null;
  if (!Array.isArray(arr)) arr = arr.contents || arr.thumbnails || arr.image?.sources || arr.sources || [];
  if (!Array.isArray(arr) || !arr.length) return null;
  const sorted = [...arr].filter((x) => x && x.url).sort((a, b) => (a.width || 0) - (b.width || 0));
  if (!sorted.length) return null;
  const pick = sorted.find((x) => (x.width || 0) >= want) || sorted[sorted.length - 1];
  let url = pick.url;
  if (url.startsWith('//')) url = 'https:' + url;
  return url;
}

const isTopicChannel = (name) => /\s-\sTopic$/i.test(name || '');

export function normMusicItem(it) {
  if (!it) return null;
  const type = it.item_type;
  let artists = (it.artists || it.authors || []).map((a) => a.name).filter(Boolean);
  if (!artists.length && (type === 'song' || type === 'video')) {
    // Unlinked artists only appear in the subtitle column: "A & B • Album • 2:15"
    const sub = txt(it.flex_columns?.[1]?.title).split(' • ')[0];
    if (sub && !/^\d/.test(sub)) artists = sub.split(/\s*(?:,|&)\s*/).filter(Boolean);
  }
  const base = {
    title: txt(it.title) || it.name || txt(it.flex_columns?.[0]?.title) || '',
    artists,
    channel: artists[0] || it.author?.name || '',
    album: it.album?.name || '',
    durationMs: it.duration?.seconds ? it.duration.seconds * 1000 : 0,
    thumb: bestThumb(it.thumbnail?.contents || it.thumbnails || it.thumbnail),
  };
  if (type === 'song' || type === 'video' || type === 'non_music_track') {
    if (!it.id) return null;
    const artistRefs = (it.artists || []).filter((a) => a.name && a.channel_id).map((a) => ({ name: a.name, id: a.channel_id }));
    return { ...base, kind: type === 'song' ? 'song' : 'video', videoId: it.id, isTopic: type === 'song', ...(artistRefs.length ? { artistRefs } : {}) };
  }
  if (type === 'album') return { ...base, kind: 'album', browseId: it.id, year: it.year || '', artists: artists.length ? artists : [it.author?.name].filter(Boolean) };
  if (type === 'artist' || type === 'library_artist') return { ...base, kind: 'artist', browseId: it.id, title: it.name || base.title, subscribers: it.subscribers || '' };
  if (type === 'playlist') return { ...base, kind: 'playlist', browseId: it.id };
  return null;
}

export function normVideo(v) {
  if (!v) return null;
  const type = v.type;
  if (type === 'LockupView') {
    const id = v.content_id;
    if (!id || (v.content_type && v.content_type !== 'VIDEO')) return null;
    const md = v.metadata;
    const rows = md?.metadata?.metadata_rows || [];
    const channel = txt(rows[0]?.metadata_parts?.[0]?.text);
    let durationMs = 0;
    for (const o of v.content_image?.overlays || []) {
      for (const b of o.badges || []) { const d = parseDurationText(b.text); if (d) durationMs = d; }
    }
    return { kind: 'video', videoId: id, title: txt(md?.title), channel, artists: [], durationMs, thumb: bestThumb(v.content_image?.image), isTopic: isTopicChannel(channel) };
  }
  const id = v.video_id || v.id;
  if (!id) return null;
  const channel = v.author?.name || txt(v.short_byline_text) || txt(v.author) || '';
  let durationMs = 0;
  if (v.duration?.seconds) durationMs = v.duration.seconds * 1000;
  else if (v.length_text) durationMs = parseDurationText(txt(v.length_text));
  return {
    kind: 'video', videoId: id, title: txt(v.title), channel, artists: [], durationMs,
    thumb: bestThumb(v.thumbnails || v.thumbnail), isTopic: isTopicChannel(channel), views: txt(v.short_view_count || v.view_count),
  };
}

export function normPanelVideo(p) {
  if (!p) return null;
  const node = p.type === 'PlaylistPanelVideoWrapper' ? p.primary : p;
  if (!node || !node.video_id) return null;
  const artists = (node.artists || []).map((a) => a.name).filter(Boolean);
  return {
    kind: 'song', videoId: node.video_id, title: txt(node.title), artists: artists.length ? artists : [txt(node.author)].filter(Boolean),
    channel: artists[0] || txt(node.author), album: node.album?.name || '', durationMs: (node.duration?.seconds || 0) * 1000,
    thumb: bestThumb(node.thumbnail), isTopic: true,
  };
}

export function collect(arr, fn) {
  const out = [];
  for (const x of arr || []) { const n = fn(x); if (n) out.push(n); }
  return out;
}
