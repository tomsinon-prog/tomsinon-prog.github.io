// StreamResolver: the ONE place that talks to YouTube (youtubei.js). Search, details, up next/radio
// and audio stream URLs (incl. signature / n-parameter deciphering and optional PO tokens).
// When YouTube breaks something: update youtubei.js (package.json), rebuild. Client order is a setting.
import { Innertube, UniversalCache, Platform, Constants, Log, YTNodes } from '../../vendor/yt.js';
import { nativeFetch } from './fetch-shim.js';
import { normMusicItem, normVideo, normPanelVideo, collect, txt, bestThumb } from './normalize.js';
import { parseArtistReleases } from '../lib/discover.js';
import { PoTokens } from './potoken.js';

const QUALITY = { high: 'high', normal: 'normal', low: 'low' };
/** Default client order. IOS (PO-token gated: serves the start, then 403) and ANDROID (only its progressive itag 18
 *  is usable without a PO token) are last resorts. */
export const DEFAULT_CLIENTS = 'VISIONOS,ANDROID_VR,TV,WEB_EMBEDDED,MWEB,WEB,IOS,ANDROID';
const OLD_DEFAULTS = ['VISIONOS,ANDROID_VR,TV,IOS,WEB_EMBEDDED,MWEB,WEB'];
const SESSION_MAX_AGE = 12 * 3600 * 1000;

export class StreamResolver {
  constructor({ fetchFn = nativeFetch, log = () => {}, getSetting = () => undefined, kv = null, createOptions = {} } = {}) {
    this.createOptions = createOptions;
    this.fetchFn = fetchFn;
    this.log = log;
    this.getSetting = getSetting;
    this.kv = kv; // {get(key), set(key, value)} for remembering the last good client
    this.yt = null;
    this.creating = null;
    this.po = new PoTokens({ fetchFn, log });
    this.cooldown = new Map(); // client -> {until, reason}: clients that just failed are tried last for a while
    this.stats = { resolves: 0, resolveFails: 0, searches: 0, lastClient: null, lastError: '', createdAt: 0, createMs: 0 };
  }

  async client() {
    if (this.yt) return this.yt;
    if (!this.creating) {
      this.creating = (async () => {
        const t0 = Date.now();
        // The player script needs a JS evaluator for signature/n deciphering. The WebView is a real browser.
        Platform.shim.eval = (data) => new Function(data.output)();
        try { Log.setLevel(Log.Level.WARNING); } catch { /* older API */ }
        const cache = typeof indexedDB !== 'undefined' ? new UniversalCache(true) : undefined;
        // The cached session holds the visitor id. A fresh one after a reset or every 12 h: YouTube can start refusing
        // streams for one visitor id after a while.
        const at = Number(this.kv?.get('yt.sessionAt') || 0);
        if (cache && (this.freshSession || Date.now() - at > SESSION_MAX_AGE)) {
          await cache.remove('innertube_session_data').catch(() => {});
          this.kv?.set('yt.sessionAt', String(Date.now()));
        }
        this.freshSession = false;
        const yt = await Innertube.create({
          fetch: this.fetchFn,
          cache,
          retrieve_player: true,
          lang: 'en',
          location: this.getSetting('ytLocation') || 'NL',
          enable_session_cache: true,
          ...this.createOptions,
        });
        this.stats.createdAt = Date.now();
        this.stats.createMs = Date.now() - t0;
        this.log('I', `Innertube ready in ${this.stats.createMs} ms (player ${yt.session.player?.player_id || 'none'})`);
        this.yt = yt;
        return yt;
      })().finally(() => { this.creating = null; });
    }
    return this.creating;
  }

  /** Next client() starts a new InnerTube session with a new visitor id. */
  reset() { this.yt = null; this.freshSession = true; }

  /** A client's streams stopped working: try it last for `ms`. */
  cool(client, ms, reason) {
    if (!client) return;
    this.cooldown.set(client, { until: Date.now() + ms, reason });
    this.log('I', `client ${client} tried last for ${Math.round(ms / 60000)} min (${reason})`);
  }

  // ---------------------------------------------------------------- search

  /** Library-independent search: songs, videos, albums, artists (sections may be empty on failure). */
  async search(query, { limit = 20 } = {}) {
    const yt = await this.client();
    this.stats.searches++;
    const [songs, videos, albums, artists] = await Promise.allSettled([
      yt.music.search(query, { type: 'song' }),
      yt.search(query, { type: 'video' }),
      yt.music.search(query, { type: 'album' }),
      yt.music.search(query, { type: 'artist' }),
    ]);
    const shelf = (r, getter) => (r.status === 'fulfilled' ? (r.value[getter]?.contents || r.value.contents?.[0]?.contents || []) : []);
    const errors = [songs, videos, albums, artists].filter((r) => r.status === 'rejected').map((r) => String(r.reason?.message || r.reason));
    if (errors.length === 4) throw new Error('YouTube search failed: ' + errors[0]);
    return {
      songs: collect(shelf(songs, 'songs'), normMusicItem).filter((x) => x.videoId).slice(0, limit),
      videos: videos.status === 'fulfilled' ? collect(videos.value.videos || videos.value.results, normVideo).slice(0, limit) : [],
      albums: collect(shelf(albums, 'albums'), normMusicItem).filter((x) => x.kind === 'album').slice(0, 8),
      artists: collect(shelf(artists, 'artists'), normMusicItem).filter((x) => x.kind === 'artist').slice(0, 6),
      errors,
    };
  }

  /** Song results only (used by matching). */
  async searchSongs(query) {
    const yt = await this.client();
    this.stats.searches++;
    const r = await yt.music.search(query, { type: 'song' });
    return collect(r.songs?.contents || r.contents?.[0]?.contents || [], normMusicItem).filter((x) => x.videoId);
  }

  async searchVideos(query) {
    const yt = await this.client();
    this.stats.searches++;
    const r = await yt.search(query, { type: 'video' });
    return collect(r.videos || r.results, normVideo);
  }

  async album(browseId) {
    const yt = await this.client();
    const a = await yt.music.getAlbum(browseId);
    const hdr = a.header || {};
    const artists = (hdr.strapline_text_one ? [txt(hdr.strapline_text_one)] : (hdr.author ? [hdr.author.name] : [])).filter(Boolean);
    const title = txt(hdr.title);
    const thumb = normMusicItem({ item_type: 'album', id: browseId, title, thumbnail: hdr.thumbnail })?.thumb;
    const tracks = collect(a.contents, (it) => {
      const n = normMusicItem({ ...it, item_type: it.item_type || 'song' });
      if (!n || !n.videoId) return null;
      return { ...n, kind: 'song', album: n.album || title, artists: n.artists.length ? n.artists : artists, thumb: n.thumb || thumb };
    });
    return { title, artists, thumb, tracks };
  }

  async artist(channelId) {
    const yt = await this.client();
    const a = await yt.music.getArtist(channelId);
    const name = txt(a.header?.title);
    let songs = [];
    for (const sec of a.sections || []) {
      const items = collect(sec.contents, normMusicItem).filter((x) => x.videoId);
      if (items.length) { songs = items.map((x) => ({ ...x, artists: x.artists.length ? x.artists : [name] })); break; }
    }
    return { name, songs, related: relatedArtists(a.sections, channelId), thumb: bestThumb(a.header?.thumbnail?.contents || a.header?.thumbnail, 300) };
  }

  /** Artist search results (YouTube Music). */
  async searchArtists(query) {
    const yt = await this.client();
    this.stats.searches++;
    const r = await yt.music.search(query, { type: 'artist' });
    return collect(r.artists?.contents || r.contents?.[0]?.contents || [], normMusicItem).filter((x) => x.kind === 'artist' && x.browseId);
  }

  /** Albums / singles / EPs on an artist page: {name, thumb, releases: [{browseId, title, kind, year, thumb}]}. */
  async artistReleases(channelId) {
    const yt = await this.client();
    const a = await yt.music.getArtist(channelId);
    return { name: txt(a.header?.title), thumb: bestThumb(a.header?.thumbnail?.contents || a.header?.thumbnail, 300), releases: parseArtistReleases(a.sections) };
  }

  // ---------------------------------------------------------------- explore (genres, charts, playlists)

  /** A YouTube Music browse page as plain shelves (see shelvesOf). */
  async browseShelves(browseId, params, extra = {}) {
    const yt = await this.client();
    const page = await yt.actions.execute('/browse', { browseId, ...(params ? { params } : {}), ...extra, client: 'YTMUSIC', parse: true });
    return shelvesOf(page);
  }

  /** "Moods & genres": [{title: 'Genres', buttons: [{title, params}]}, {title: 'Moods & moments', …}]. */
  async moodsAndGenres() {
    const shelves = await this.browseShelves('FEmusic_moods_and_genres');
    return shelves.filter((s) => s.buttons.length).map((s) => ({ title: s.title, buttons: s.buttons }));
  }

  /** One genre/mood page: shelves of playlists (and sometimes artists/albums). */
  async genreCategory(params) {
    return (await this.browseShelves('FEmusic_moods_and_genres_category', params)).filter((s) => s.items.length);
  }

  /** Charts for a country ('NL', 'ZZ' = world): shelves; the artist shelf is "Top artists". */
  async charts(country = 'ZZ') {
    return (await this.browseShelves('FEmusic_charts', null, country && country !== 'ZZ' ? { formData: { selectedValues: [country] } } : {})).filter((s) => s.items.length);
  }

  /** A YouTube Music playlist: {title, author, thumb, tracks[]} (first page, up to ~100 songs). */
  async playlist(id) {
    const yt = await this.client();
    const pl = await yt.music.getPlaylist(id);
    const h = pl.header || {};
    const tracks = collect(pl.contents || pl.items || [], normMusicItem).filter((x) => x.videoId);
    return {
      id, title: txt(h.title) || '', author: txt(h.strapline_text_one) || txt(h.author?.name) || txt(h.subtitle) || '',
      thumb: bestThumb(h.thumbnail?.contents || h.thumbnails || h.thumbnail, 300) || tracks[0]?.thumb || null, tracks,
    };
  }

  /** YouTube Music "up next" / automix radio for a video. */
  async upNext(videoId) {
    const yt = await this.client();
    const panel = await yt.music.getUpNext(videoId, true);
    return collect(panel.contents, normPanelVideo);
  }

  async details(videoId) {
    const yt = await this.client();
    const info = await yt.music.getInfo(videoId);
    const b = info.basic_info || {};
    return { videoId, title: b.title, channel: b.author, durationMs: (b.duration || 0) * 1000, thumb: b.thumbnail?.[0]?.url || null };
  }

  // ---------------------------------------------------------------- stream URLs

  /** Configured order; clients in cooldown move to the end (never removed: something may still work). */
  clientOrder() {
    let raw = String(this.getSetting('ytClients') || DEFAULT_CLIENTS).replace(/\s+/g, '').toUpperCase();
    if (OLD_DEFAULTS.includes(raw)) raw = DEFAULT_CLIENTS;
    const list = raw.split(',').filter(Boolean);
    const now = Date.now();
    const cooling = (c) => (this.cooldown.get(c)?.until || 0) > now;
    return [...list.filter((c) => !cooling(c)), ...list.filter(cooling)];
  }

  /**
   * Resolves the best audio-only stream. Tries clients in order until one yields a URL that answers a 1-byte
   * range probe (catches PO-token / 403 problems before playback starts).
   */
  async resolve(videoId, { quality = 'high', probe = true } = {}) {
    const yt = await this.client();
    this.stats.resolves++;
    const errors = [];
    for (const client of this.clientOrder()) {
      const t0 = Date.now();
      try {
        const opts = { client };
        if (/^(WEB|MWEB|WEB_EMBEDDED)$/.test(client) && this.getSetting('poToken') !== 'off') {
          const pot = await this.po.forVideo(yt, videoId).catch((e) => { this.log('W', `PO token unavailable: ${e.message}`); return null; });
          if (pot) { opts.po_token = pot; if (yt.session.player) yt.session.player.po_token = pot; }
        }
        const info = await yt.getBasicInfo(videoId, opts).catch((e) => {
          if (/decipher/i.test(String(e?.message))) this.cool(client, 30 * 60e3, 'no direct URLs');
          throw e;
        });
        const ps = info.playability_status;
        if (ps && ps.status && ps.status !== 'OK') {
          const e = new Error(`${ps.status}${ps.reason ? ': ' + ps.reason : ''}`);
          // Not about this video but about the client/session: try this client last for a while.
          if (ps.status === 'LOGIN_REQUIRED' || /reload/i.test(ps.reason || '')) this.cool(client, 10 * 60e3, ps.status);
          throw e;
        }
        const ua = Constants.CLIENTS?.[client]?.USER_AGENT;
        const headers = ua ? { 'User-Agent': ua } : {};
        if (/^(WEB|MWEB|WEB_EMBEDDED|TV)$/.test(client)) { headers.Origin = 'https://www.youtube.com'; headers.Referer = 'https://www.youtube.com/'; }
        // Audio-only first; the combined 360p MP4 (itag 18) when the audio-only stream is blocked for this client.
        const candidates = [pickAudioFormat(info.streaming_data?.adaptive_formats || [], QUALITY[quality] || 'high'),
          (info.streaming_data?.formats || []).find((f) => f && f.itag === 18)].filter(Boolean);
        if (!candidates.length) throw new Error('no audio-only formats');
        let chosen = null, lastErr = null;
        for (const fmt of candidates) {
          try {
            const url = await fmt.decipher(yt.session.player);
            if (!url || !url.startsWith('http')) throw new Error('deciphering produced no URL');
            const contentLength = Number(fmt.content_length || new URL(url).searchParams.get('clen') || 0);
            if (probe) await this.probe(url, headers, contentLength);
            chosen = { fmt, url, contentLength };
            break;
          } catch (e) { lastErr = e; }
        }
        if (!chosen) {
          const m = String(lastErr?.message || '');
          if (/stream blocked/.test(m)) this.cool(client, 30 * 60e3, 'streams stop after the start');
          else if (/stream probe HTTP 503/.test(m)) this.cool(client, 2 * 60e3, 'HTTP 503');
          else if (/stream probe HTTP/.test(m)) this.cool(client, 10 * 60e3, m);
          else if (/decipher/i.test(m)) this.cool(client, 30 * 60e3, 'no direct URLs');
          throw lastErr;
        }
        const { fmt, url, contentLength } = chosen;
        const expire = Number(new URL(url).searchParams.get('expire') || 0);
        const result = {
          videoId, url, client, itag: fmt.itag, mime: String(fmt.mime_type || '').split(';')[0], codecs: fmt.mime_type,
          bitrate: fmt.average_bitrate || fmt.bitrate || 0, contentLength,
          loudnessDb: firstNumber(info.player_config?.audio_config?.loudness_db, fmt.loudness_db),
          expiresAt: expire ? expire * 1000 : Date.now() + 3 * 3600 * 1000,
          durationMs: Number(fmt.approx_duration_ms || 0) || (info.basic_info?.duration || 0) * 1000,
          title: info.basic_info?.title || '', headers, ms: Date.now() - t0, tried: errors.map((e) => e.client),
        };
        this.stats.lastClient = client;
        if (this.cooldown.has(client)) this.cooldown.delete(client);
        return result;
      } catch (e) {
        const msg = String(e?.message || e).slice(0, 200);
        errors.push({ client, error: msg, ms: Date.now() - t0 });
        this.log('W', `resolve ${videoId} via ${client} failed: ${msg}`);
      }
    }
    this.stats.resolveFails++;
    this.stats.lastError = errors.map((e) => `${e.client}: ${e.error}`).join(' | ');
    const err = new Error('No working stream: ' + this.stats.lastError);
    err.attempts = errors;
    throw err;
  }

  /**
   * Checks the start AND the end of the stream: some clients' URLs (without a PO token) answer the first bytes and
   * then refuse the rest, which a probe of the start alone doesn't see. A 503 gets one more try.
   */
  async probe(url, headers, length = 0) {
    const get = async (range) => {
      let res = await this.fetchFn(url, { headers: { ...headers, Range: `bytes=${range}` }, timeoutMs: 15000 });
      if (res.status === 503) {
        await new Promise((r) => setTimeout(r, 600));
        res = await this.fetchFn(url, { headers: { ...headers, Range: `bytes=${range}` }, timeoutMs: 15000 });
      }
      return res.status;
    };
    const head = await get('0-1');
    if (head !== 206 && head !== 200) throw new Error(`stream probe HTTP ${head}`);
    if (length > 4096) {
      const tail = await get(`${length - 2}-${length - 1}`);
      if (tail !== 206 && tail !== 200) throw new Error(`stream blocked after the start (HTTP ${tail})`);
    }
  }
}

/** Artists in an artist page's carousels ("Fans might also like"), without the artist itself. */
export function relatedArtists(sections, selfId) {
  const out = [];
  const seen = new Set([selfId]);
  for (const sec of sections || []) {
    for (const x of collect(sec.contents, normMusicItem)) {
      if (x.kind === 'artist' && x.browseId && !seen.has(x.browseId)) { seen.add(x.browseId); out.push(x); }
    }
  }
  return out;
}

/**
 * Any parsed YouTube Music browse page -> [{title, buttons: [{title, browseId, params}], items: [normMusicItem…]}] in
 * page order. Covers Grid (genre buttons, playlists), carousels and list shelves.
 */
export function shelvesOf(page) {
  const out = [];
  const lists = page?.contents_memo?.getType(YTNodes.SectionList) || [];
  const sections = lists.length ? lists.flatMap((l) => l.contents || []) : [];
  for (const sec of sections) {
    const title = txt(sec.header?.title) || txt(sec.title) || txt(sec.header?.strapline) || '';
    const raw = sec.items || sec.contents || [];
    const buttons = [];
    const items = [];
    for (const it of raw) {
      if (it?.type === 'MusicNavigationButton') {
        const pl = it.endpoint?.payload || {};
        if (pl.browseId) buttons.push({ title: it.button_text, browseId: pl.browseId, params: pl.params || null });
      } else {
        const n = normMusicItem(it);
        if (n) items.push(n);
      }
    }
    if (buttons.length || items.length) out.push({ title, buttons, items });
  }
  return out;
}

function firstNumber(...xs) {
  for (const x of xs) if (typeof x === 'number' && Number.isFinite(x)) return x;
  return null;
}

/** Audio-only, non-DRC, original-language track; quality picks by bitrate. Prefers Opus (WebM) then AAC. */
export function pickAudioFormat(formats, quality = 'high') {
  let audio = formats.filter((f) => f && f.has_audio && !f.has_video && (f.url || f.signature_cipher || f.cipher));
  if (!audio.length) audio = formats.filter((f) => f && String(f.mime_type || '').startsWith('audio/'));
  if (!audio.length) return null;
  const nonDrc = audio.filter((f) => !f.is_drc);
  if (nonDrc.length) audio = nonDrc;
  const orig = audio.filter((f) => !f.audio_track || f.audio_track.audio_is_default);
  if (orig.length) audio = orig;
  const br = (f) => f.average_bitrate || f.bitrate || 0;
  const opus = audio.filter((f) => /opus/.test(f.mime_type || ''));
  const aac = audio.filter((f) => /mp4a|audio\/mp4/.test(f.mime_type || ''));
  const pool = opus.length ? opus : aac.length ? aac : audio;
  const sorted = [...pool].sort((a, b) => br(b) - br(a));
  if (quality === 'low') return sorted[sorted.length - 1];
  if (quality === 'normal') {
    // Opus ~96 kbps sounds like AAC ~128 kbps
    const target = pool === opus ? 96000 : 128000;
    return [...sorted].sort((a, b) => Math.abs(br(a) - target) - Math.abs(br(b) - target))[0];
  }
  return sorted[0];
}
