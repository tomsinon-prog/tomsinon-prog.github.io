// PO (proof of origin) tokens via BotGuard, generated inside the WebView (a real browser environment).
// Only used for WEB-family clients when the other clients fail. Best effort: every error is non-fatal.
import { BG, BGWebPo } from '../../vendor/yt.js';

const REQUEST_KEY = 'O43z0dpjhgX20SCx4KAo';
const GOOG_API_KEY = 'AIzaSyDyT5W0Jh49F30Pqqtyfdf7pDLFKLJoAnw';

export class PoTokens {
  constructor({ fetchFn, log }) {
    this.fetchFn = fetchFn;
    this.log = log;
    this.minter = null;
    this.expiresAt = 0;
    this.creating = null;
  }

  async getMinter() {
    if (this.minter && Date.now() < this.expiresAt) return this.minter;
    if (!this.creating) {
      this.creating = (async () => {
        const t0 = Date.now();
        const challenge = await BG.getChallenge({ requestKey: REQUEST_KEY, fetchFunction: this.fetchFn, useYouTubeAPI: true });
        if (!challenge) throw new Error('no BotGuard challenge');
        let js = challenge.interpreterJavascript?.privateDoNotAccessOrElseSafeScriptWrappedValue;
        if (!js && challenge.interpreterUrl?.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue) {
          let u = challenge.interpreterUrl.privateDoNotAccessOrElseTrustedResourceUrlWrappedValue;
          if (u.startsWith('//')) u = 'https:' + u;
          js = await (await this.fetchFn(u)).text();
        }
        if (!js) throw new Error('challenge without interpreter');
        new Function(js)();
        const bg = await BG.BotGuardClient.create({ program: challenge.program, globalName: challenge.globalName, globalObject: globalThis });
        const signals = [];
        const response = await bg.snapshot({ webPoSignalOutput: signals });
        const res = await this.fetchFn('https://jnn-pa.googleapis.com/$rpc/google.internal.waa.v1.Waa/GenerateIT', {
          method: 'POST',
          headers: { 'content-type': 'application/json+protobuf', 'x-goog-api-key': GOOG_API_KEY, 'x-user-agent': 'grpc-web-javascript/0.1' },
          body: JSON.stringify([REQUEST_KEY, response]),
        });
        const j = await res.json();
        const [integrityToken, estimatedTtlSecs, mintRefreshThreshold, websafeFallbackToken] = j;
        this.minter = await BGWebPo.WebPoMinter.create({ integrityToken, estimatedTtlSecs, mintRefreshThreshold, websafeFallbackToken }, signals);
        this.expiresAt = Date.now() + Math.max(300, (estimatedTtlSecs || 3600) - (mintRefreshThreshold || 300)) * 1000;
        this.log('I', `PO token minter ready in ${Date.now() - t0} ms`);
        return this.minter;
      })().finally(() => { this.creating = null; });
    }
    return this.creating;
  }

  /** Content-bound token for a video id. */
  async forVideo(yt, videoId) {
    const minter = await this.getMinter();
    return minter.mintAsWebsafeString(videoId);
  }
}
