// fetch() replacement that runs every HTTP request through the native Java bridge (no CORS, own headers).
import { callAsync } from '../core/bridge.js';

const NULL_BODY = new Set([101, 103, 204, 205, 304]);

export function bytesToB64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

export function b64ToBytes(b64) {
  const bin = atob(b64 || '');
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function headersToPairs(h) {
  if (!h) return [];
  if (h instanceof Headers) return [...h.entries()];
  if (Array.isArray(h)) return h.map(([k, v]) => [k, String(v)]);
  return Object.entries(h).map(([k, v]) => [k, String(v)]);
}

async function bodyToPayload(body) {
  if (body == null) return {};
  if (typeof body === 'string') return { bodyText: body };
  if (body instanceof URLSearchParams) return { bodyText: body.toString() };
  if (body instanceof ArrayBuffer) return { bodyB64: bytesToB64(new Uint8Array(body)) };
  if (ArrayBuffer.isView(body)) return { bodyB64: bytesToB64(new Uint8Array(body.buffer, body.byteOffset, body.byteLength)) };
  if (typeof Blob !== 'undefined' && body instanceof Blob) return { bodyB64: bytesToB64(new Uint8Array(await body.arrayBuffer())) };
  throw new Error('nativeFetch: unsupported body type');
}

export const stats = { requests: 0, failures: 0, lastError: '' };

export async function nativeFetch(input, init = {}) {
  let url, method = 'GET', headers = [], payload = {};
  if (typeof Request !== 'undefined' && input instanceof Request) {
    url = input.url;
    method = input.method;
    headers = headersToPairs(input.headers);
    if (!['GET', 'HEAD'].includes(method)) {
      const buf = new Uint8Array(await input.clone().arrayBuffer());
      if (buf.length) payload = { bodyB64: bytesToB64(buf) };
    }
  } else {
    url = String(input instanceof URL ? input.href : input);
  }
  if (init.method) method = init.method;
  if (init.headers) headers = headersToPairs(init.headers);
  if (init.body != null) payload = await bodyToPayload(init.body);
  if (init.signal?.aborted) throw new DOMException('Aborted', 'AbortError');
  stats.requests++;
  let r;
  try {
    r = await callAsync('fetch', { url, method: method.toUpperCase(), headers, redirect: init.redirect, timeoutMs: init.timeoutMs || 30000, ...payload });
  } catch (e) {
    stats.failures++;
    stats.lastError = String(e.message || e);
    throw new TypeError('Network request failed: ' + (e.message || e));
  }
  if (init.signal?.aborted) throw new DOMException('Aborted', 'AbortError');
  const h = new Headers();
  for (const [k, v] of r.headers || []) { try { h.append(k, v); } catch { /* invalid header from server */ } }
  const status = r.status < 200 || r.status > 599 ? 502 : r.status;
  const res = new Response(NULL_BODY.has(status) ? null : b64ToBytes(r.bodyB64), { status, statusText: r.statusText || '', headers: h });
  Object.defineProperty(res, 'url', { value: r.url || url });
  return res;
}

export async function fetchJson(url, init) {
  const res = await nativeFetch(url, init);
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url.split('?')[0]}`);
  return res.json();
}
