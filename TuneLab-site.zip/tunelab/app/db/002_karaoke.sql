-- 0.2: karaoke recordings (the audio files live in Music/TuneLab Karaoke via MediaStore).
CREATE TABLE recording (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id INTEGER,
  title TEXT NOT NULL,
  artists TEXT NOT NULL DEFAULT '',
  uri TEXT,
  path TEXT,
  duration_ms INTEGER NOT NULL DEFAULT 0,
  score INTEGER,
  key_shift INTEGER NOT NULL DEFAULT 0,
  backing TEXT,
  voices INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_recording_created ON recording(created_at);
