-- 0.3: playlists kept offline, smart playlists, new releases of followed artists.
-- The weekly discovery mix is a normal playlist with origin 'MIX'.
ALTER TABLE playlist ADD COLUMN offline INTEGER NOT NULL DEFAULT 0;

CREATE TABLE smart_playlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  rules TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

-- Artists checked for new releases (derived from history and likes; refreshed automatically).
CREATE TABLE artist_follow (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  browse_id TEXT,
  thumb TEXT,
  score REAL NOT NULL DEFAULT 0,
  checked_at INTEGER,
  muted INTEGER NOT NULL DEFAULT 0
);

-- Albums / singles / EPs seen on those artists' YouTube Music pages.
CREATE TABLE artist_release (
  browse_id TEXT PRIMARY KEY,
  artist_key TEXT NOT NULL,
  artist TEXT NOT NULL,
  title TEXT NOT NULL,
  kind TEXT NOT NULL,
  year INTEGER,
  thumb TEXT,
  first_seen INTEGER NOT NULL,
  baseline INTEGER NOT NULL DEFAULT 0,
  dismissed INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_release_seen ON artist_release(first_seen);
