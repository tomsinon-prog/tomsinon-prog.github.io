-- 0.10: artists you follow yourself (Follow button on an artist page). Their new releases are checked even if you
-- never played them; `manual` survives the automatic re-scoring of artist_follow.
ALTER TABLE artist_follow ADD COLUMN manual INTEGER NOT NULL DEFAULT 0;
ALTER TABLE artist_follow ADD COLUMN followed_at INTEGER;
