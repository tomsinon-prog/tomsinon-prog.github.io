-- 0.4: genres per artist (from MusicBrainz tags), used for genre filters and genre search.
CREATE TABLE artist_genre (
  key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  genres TEXT NOT NULL DEFAULT '',
  tags TEXT,
  mbid TEXT,
  checked_at INTEGER NOT NULL
);
-- Weekly Discovery is no longer downloaded by default (only songs you like are, with "Keep liked songs offline").
UPDATE playlist SET offline=0 WHERE origin='MIX';
