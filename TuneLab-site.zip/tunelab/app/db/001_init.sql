-- TuneLab schema v1. Migrations are append-only: never edit a released file, add 00N_*.sql instead.
-- Statements are separated by a semicolon at the end of a line.

CREATE TABLE track (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  artists TEXT NOT NULL DEFAULT '',
  artists_json TEXT,
  album TEXT NOT NULL DEFAULT '',
  duration_ms INTEGER NOT NULL DEFAULT 0,
  isrc TEXT,
  spotify_uri TEXT UNIQUE,
  artwork_url TEXT,
  match_key TEXT NOT NULL DEFAULT '',
  sort_title TEXT NOT NULL DEFAULT '',
  sort_artist TEXT NOT NULL DEFAULT '',
  match_state TEXT NOT NULL DEFAULT 'NONE',
  match_score REAL,
  match_tried_at INTEGER,
  missing_on_spotify INTEGER NOT NULL DEFAULT 0,
  spotify_seen_at INTEGER,
  origin TEXT NOT NULL DEFAULT 'APP',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX idx_track_match_key ON track(match_key);
CREATE INDEX idx_track_match_state ON track(match_state);
CREATE INDEX idx_track_isrc ON track(isrc);

CREATE TABLE track_source (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id INTEGER NOT NULL,
  kind TEXT NOT NULL,
  ref TEXT NOT NULL,
  title TEXT,
  channel TEXT,
  duration_ms INTEGER,
  thumb TEXT,
  score REAL,
  is_topic INTEGER NOT NULL DEFAULT 0,
  chosen INTEGER NOT NULL DEFAULT 0,
  broken INTEGER NOT NULL DEFAULT 0,
  loudness_db REAL,
  created_at INTEGER NOT NULL,
  UNIQUE(track_id, kind, ref)
);
CREATE INDEX idx_source_track ON track_source(track_id);
CREATE INDEX idx_source_ref ON track_source(kind, ref);

CREATE TABLE likes (
  track_id INTEGER PRIMARY KEY,
  liked_at INTEGER NOT NULL,
  origin TEXT NOT NULL DEFAULT 'APP',
  spotify_added_at INTEGER
);
CREATE INDEX idx_likes_liked_at ON likes(liked_at);

CREATE TABLE playlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  origin TEXT NOT NULL DEFAULT 'APP',
  spotify_id TEXT UNIQUE,
  spotify_owner TEXT,
  spotify_snapshot TEXT,
  importable INTEGER NOT NULL DEFAULT 1,
  missing_on_spotify INTEGER NOT NULL DEFAULT 0,
  artwork_url TEXT,
  position INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE playlist_entry (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  playlist_id INTEGER NOT NULL,
  track_id INTEGER NOT NULL,
  position REAL NOT NULL,
  added_at INTEGER NOT NULL,
  spotify_added_at INTEGER,
  missing_on_spotify INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_entry_playlist ON playlist_entry(playlist_id, position);
CREATE INDEX idx_entry_track ON playlist_entry(track_id);

CREATE TABLE user_album (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  artwork_url TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE user_album_entry (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  album_id INTEGER NOT NULL,
  track_id INTEGER NOT NULL,
  position REAL NOT NULL,
  added_at INTEGER NOT NULL
);
CREATE INDEX idx_album_entry ON user_album_entry(album_id, position);

CREATE TABLE play_event (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id INTEGER,
  ts INTEGER NOT NULL,
  ms_played INTEGER NOT NULL DEFAULT 0,
  skipped INTEGER NOT NULL DEFAULT 0,
  origin TEXT NOT NULL,
  spotify_track_uri TEXT,
  track_name TEXT,
  artist_name TEXT,
  album_name TEXT,
  reason_end TEXT,
  shuffle INTEGER,
  dedupe_key TEXT NOT NULL UNIQUE
);
CREATE INDEX idx_play_ts ON play_event(ts);
CREATE INDEX idx_play_track ON play_event(track_id);
CREATE INDEX idx_play_uri ON play_event(spotify_track_uri);

CREATE TABLE download (
  track_id INTEGER PRIMARY KEY,
  state TEXT NOT NULL,
  path TEXT,
  size INTEGER NOT NULL DEFAULT 0,
  mime TEXT,
  progress REAL NOT NULL DEFAULT 0,
  error TEXT,
  requested_at INTEGER NOT NULL,
  done_at INTEGER
);

CREATE TABLE audio_cache (
  key TEXT PRIMARY KEY,
  path TEXT NOT NULL,
  size INTEGER NOT NULL,
  mime TEXT,
  last_access INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE resolved_url (
  video_id TEXT NOT NULL,
  quality TEXT NOT NULL,
  url TEXT NOT NULL,
  itag INTEGER,
  mime TEXT,
  content_length INTEGER,
  bitrate INTEGER,
  loudness_db REAL,
  client TEXT,
  headers TEXT,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (video_id, quality)
);

CREATE TABLE match_candidate (
  track_id INTEGER NOT NULL,
  video_id TEXT NOT NULL,
  title TEXT,
  channel TEXT,
  duration_ms INTEGER,
  thumb TEXT,
  score REAL,
  is_topic INTEGER NOT NULL DEFAULT 0,
  kind TEXT,
  PRIMARY KEY (track_id, video_id)
);

CREATE TABLE lyrics (
  track_id INTEGER PRIMARY KEY,
  synced TEXT,
  plain TEXT,
  source TEXT,
  not_found INTEGER NOT NULL DEFAULT 0,
  fetched_at INTEGER NOT NULL
);

CREATE TABLE scrobble_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  artist TEXT NOT NULL,
  track TEXT NOT NULL,
  album TEXT,
  ts INTEGER NOT NULL,
  duration_s INTEGER,
  tries INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE kv (
  key TEXT PRIMARY KEY,
  value TEXT
);
