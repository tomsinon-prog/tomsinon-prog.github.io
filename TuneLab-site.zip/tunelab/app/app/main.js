// TuneLab in the browser (GitHub Pages, …/tunelab/app/): your library from a backup file, kept in this browser
// (IndexedDB), played through YouTube's embedded player. No server, no YouTube search (browsers may not talk to
// YouTube directly). Reuses the Windows bridge (desktop/web/desktop/*.js) with other options.
import { boot } from '../desktop/native.js';
import { createYtMedia } from './ytmedia.js';

const DB_NAME = 'tunelab', STORE = 'files', KEEP_DAYS = 7;

function idb() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function tx(mode, fn) {
  const d = await idb();
  return new Promise((resolve, reject) => {
    const t = d.transaction(STORE, mode);
    const out = fn(t.objectStore(STORE));
    t.oncomplete = () => resolve(out && 'result' in out ? out.result : undefined);
    t.onerror = () => reject(t.error);
  });
}

/** The library file in IndexedDB, with a copy per day (last 7) and one before every restore. */
export const browserStore = {
  async load() {
    const v = await tx('readonly', (s) => s.get('library'));
    return v ? new Uint8Array(v) : null;
  },
  async save(bytes, reason) {
    const day = 'backup-' + new Date().toISOString().slice(0, 10);
    const keys = await tx('readonly', (s) => s.getAllKeys());
    const current = keys.includes('library') ? await tx('readonly', (s) => s.get('library')) : null;
    await tx('readwrite', (s) => {
      if (current && !keys.includes(day)) s.put(current, day);
      if (current && reason) s.put(current, 'pre-restore');
      s.put(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), 'library');
      keys.filter((k) => k.startsWith('backup-')).sort().slice(0, -KEEP_DAYS).forEach((k) => s.delete(k));
    });
  },
};

/** Plain browser fetch in the bridge's JSON shape (works where the other site allows it, e.g. lyrics). */
async function fetchImpl(a) {
  const headers = Array.isArray(a.headers) ? a.headers : Object.entries(a.headers || {});
  const res = await fetch(a.url, { method: a.method || 'GET', headers: headers.filter(([k]) => !/^(user-agent|origin|referer|cookie)$/i.test(k)), body: a.bodyText ?? (a.bodyB64 ? Uint8Array.from(atob(a.bodyB64), (c) => c.charCodeAt(0)) : undefined) });
  const buf = new Uint8Array(await res.arrayBuffer());
  let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return { status: res.status, statusText: res.statusText, url: res.url, headers: [...res.headers.entries()], bodyB64: btoa(bin) };
}

/**
 * A queue item -> one of the song's YouTube versions. Versions the embedded player refused ("not allowed in
 * embedded players") are remembered and skipped, so the next stored version gets its turn.
 */
function makeResolve() {
  let noEmbed = null;
  return async (it, { avoid, db, current }) => {
    if (!noEmbed) {
      try { noEmbed = new Set(JSON.parse(db.rows("SELECT value FROM kv WHERE key='web.noEmbed'")[0]?.value || '[]')); } catch { noEmbed = new Set(); }
    }
    if (avoid && current?.videoId) {
      noEmbed.add(current.videoId);
      db.run("INSERT OR REPLACE INTO kv(key,value) VALUES('web.noEmbed',?)", [JSON.stringify([...noEmbed].slice(-2000))]);
    }
    const refs = db.rows("SELECT ref FROM track_source WHERE track_id=? AND kind='YOUTUBE' AND broken=0 ORDER BY chosen DESC, score DESC, id ASC", [it.trackId]).map((r) => r.ref);
    const extra = db.rows('SELECT video_id ref FROM match_candidate WHERE track_id=? ORDER BY score DESC', [it.trackId]).map((r) => r.ref);
    const videoId = [...refs, ...extra].find((v) => v && !noEmbed.has(v));
    if (!videoId) throw new Error('No playable source found for this track in the browser.');
    return { kind: 'YOUTUBE', trackId: it.trackId, videoId, client: 'embed', itag: 0, bitrate: 0, mime: 'video/youtube' };
  };
}

/** Stands in for the YouTube player when it could not be loaded: every song fails with a clear reason. */
function unavailableMedia() {
  const t = new EventTarget();
  let src = null;
  const m = {
    error: null, preload: 'auto', volume: 1, currentTime: 0, duration: NaN, paused: true,
    addEventListener: (...a) => t.addEventListener(...a), removeEventListener: (...a) => t.removeEventListener(...a),
    get src() { return src || ''; },
    set src(v) { src = v; m.error = { code: 0, message: 'The YouTube player could not be loaded (offline or blocked by this network)' }; setTimeout(() => t.dispatchEvent(new Event('error')), 0); },
    getAttribute: (k) => (k === 'src' ? src : null), removeAttribute: () => { src = null; },
    play: () => Promise.resolve(), pause: () => {},
  };
  return m;
}

export async function start() {
  try { await navigator.storage?.persist?.(); } catch { /* the browser decides */ }
  const box = document.getElementById('ytbox');
  // Offline or YouTube blocked: the library still opens; playing then says why.
  const media = await Promise.race([createYtMedia(box), new Promise((_, no) => setTimeout(() => no(new Error('timeout')), 10000))])
    .catch((e) => { console.warn('YouTube player unavailable:', e.message); return unavailableMedia(); });
  // show the player box only while a song is loaded
  const show = () => document.body.classList.toggle('has-video', !!media.getAttribute('src'));
  for (const ev of ['playing', 'pause', 'loadedmetadata', 'ended', 'error']) media.addEventListener(ev, show);
  return boot({ platform: 'web', store: browserStore, engine: false, server: false, media, resolve: makeResolve(), srcFor: (s) => s.videoId, fetchImpl });
}
