// The official YouTube embedded player behind the <audio> interface the player logic (desktop/web/desktop/player.js)
// expects: src = videoId, play()/pause(), currentTime, duration, volume, and the events playing / pause / waiting /
// ended / error / durationchange / loadedmetadata. Browsers may only talk to YouTube through this player, and it
// must be visible (YouTube's rules: at least 200 x 200 px), so it sits in its own box on the page.
/* global YT */

const STATE = { ENDED: 0, PLAYING: 1, PAUSED: 2, BUFFERING: 3, CUED: 5 };
const ERRORS = { 2: 'invalid video id', 5: 'HTML5 player error', 100: 'video not found or private', 101: 'not allowed in embedded players', 150: 'not allowed in embedded players', 153: 'player configuration (referrer)' };

function loadApi() {
  if (window.YT && window.YT.Player) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => { prev?.(); resolve(); };
    const s = document.createElement('script');
    s.src = 'https://www.youtube.com/iframe_api';
    s.onerror = () => reject(new Error('The YouTube player could not be loaded (offline or blocked)'));
    document.head.append(s);
  });
}

export async function createYtMedia(container) {
  await loadApi();
  const target = new EventTarget();
  let player = null, ready = null, src = null, wantPlay = false, startAt = 0, vol = 1, lastState = -1, metaFired = false;
  const fire = (name) => target.dispatchEvent(new Event(name));
  ready = new Promise((resolve) => {
    const host = document.createElement('div');
    container.append(host);
    player = new YT.Player(host, {
      width: '100%', height: '100%',
      playerVars: { autoplay: 0, controls: 1, disablekb: 1, fs: 0, modestbranding: 1, playsinline: 1, rel: 0, iv_load_policy: 3, origin: location.origin },
      events: {
        onReady: () => resolve(),
        onStateChange: (e) => {
          lastState = e.data;
          if (!metaFired && (e.data === STATE.PLAYING || e.data === STATE.BUFFERING || e.data === STATE.CUED)) { metaFired = true; if (e.data !== STATE.CUED) fire('loadedmetadata'); }
          if (e.data === STATE.PLAYING) { fire('durationchange'); fire('playing'); }
          else if (e.data === STATE.PAUSED) fire('pause');
          else if (e.data === STATE.BUFFERING) fire('waiting');
          else if (e.data === STATE.ENDED) fire('ended');
          else if (e.data === STATE.CUED) { fire('loadedmetadata'); fire('durationchange'); }
        },
        onError: (e) => {
          media.error = { code: e.data, message: ERRORS[e.data] || 'error ' + e.data };
          fire('error');
        },
      },
    });
  });
  await ready;

  const media = {
    error: null,
    preload: 'auto',
    addEventListener: (...a) => target.addEventListener(...a),
    removeEventListener: (...a) => target.removeEventListener(...a),
    get src() { return src || ''; },
    set src(id) {
      src = id || null;
      media.error = null;
      metaFired = false;
      if (!src) return;
      const opts = { videoId: src, startSeconds: startAt || 0 };
      startAt = 0;
      if (wantPlay) player.loadVideoById(opts); else player.cueVideoById(opts);
    },
    getAttribute: (k) => (k === 'src' ? src : null),
    removeAttribute: (k) => { if (k === 'src') { src = null; try { player.stopVideo(); } catch { /* */ } } },
    play() { wantPlay = true; if (src) player.playVideo(); return Promise.resolve(); },
    pause() { wantPlay = false; try { player.pauseVideo(); } catch { /* */ } },
    get currentTime() { try { return player.getCurrentTime() || 0; } catch { return 0; } },
    set currentTime(t) { if (src) player.seekTo(t, true); else startAt = t; },
    get duration() { try { return player.getDuration() || NaN; } catch { return NaN; } },
    get volume() { return vol; },
    set volume(v) { vol = v; try { player.setVolume(Math.round(v * 100)); } catch { /* */ } },
    get paused() { return lastState !== STATE.PLAYING; },
  };
  return media;
}
